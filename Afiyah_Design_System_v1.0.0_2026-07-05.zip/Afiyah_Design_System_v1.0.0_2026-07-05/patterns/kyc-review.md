# Identity and KYC pattern

- State why verification is required before upload.
- Show accepted documents, maximum file size, retention period and deletion policy.
- Provide upload progress and an explicit success state.
- Never place real identity documents in staging.
- Reviewer views are watermarked and time-limited.
- Every reviewer access is logged before a signed URL is generated.
- Status language: `Under review`, `More information required`, `Approved`, `Not approved`.
- Avoid accusatory language; describe the missing evidence precisely.
