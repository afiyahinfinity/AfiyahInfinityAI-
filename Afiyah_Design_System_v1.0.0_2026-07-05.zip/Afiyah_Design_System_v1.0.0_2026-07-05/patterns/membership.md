# Membership pattern

- Present price, billing interval, benefits, exclusions and cancellation before payment.
- Do not imply financial return, guaranteed impact or religious merit.
- Use a comparable benefit matrix with one recommended tier at most.
- Partner-provided regulated services must be explicitly attributed to the licensed provider.
- Confirmation screen includes receipt, renewal date and support route.
