# Partner and Shariah-governance pattern

- Separate AI pre-screening from human scholarly or compliance decisions.
- Display evidence, source, version and reviewer identity.
- Require reason codes and free-text rationale for decisions.
- Changes to approved content create a new version rather than silently overwriting history.
- User-facing labels must distinguish `Shariah reviewed`, `Partner supplied`, `Educational only` and `Regulated service`.
