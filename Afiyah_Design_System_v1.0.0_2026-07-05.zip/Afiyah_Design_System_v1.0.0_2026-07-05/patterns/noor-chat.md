# Noor chat pattern

## Objective

Create a calm conversation surface where AI suggestions are clearly separated from executable actions.

## Required zones

1. Header: Noor identity, privacy and approval statement.
2. Conversation stream: assistant and sister messages with distinct alignment and treatment.
3. Proposal cards: action type, reason, payload summary, consequences and explicit controls.
4. Composer: accessible label, send control and connection state.
5. Trust footer: AI limitations, human escalation and audit statement.

## Non-negotiable interaction rules

- Never hide action payloads behind vague labels.
- Approval must name the action: “Approve reminder”, not “Continue”.
- Decline must explain that nothing will change.
- Repeated clicks are blocked while the transaction is pending.
- A failed action says that no change occurred.
- Religious answers sourced from an approved knowledge base must be labelled differently from model-generated reflection.
- Crisis flows replace AI output with verified human-authored safety content.
