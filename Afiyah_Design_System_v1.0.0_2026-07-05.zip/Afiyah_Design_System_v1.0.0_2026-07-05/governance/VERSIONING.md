# Versioning

- Patch: documentation, non-breaking token correction or visual bug fix.
- Minor: new token, component or backward-compatible variant.
- Major: removed or renamed token/component, changed behaviour or migration requirement.

Deprecated items remain available for one minor release and move to Figma page `99 Deprecated` with replacement guidance.
