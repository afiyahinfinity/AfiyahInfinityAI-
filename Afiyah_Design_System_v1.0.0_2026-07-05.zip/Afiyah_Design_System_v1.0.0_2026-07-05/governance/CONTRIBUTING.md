# Contributing

1. Open a design-system issue describing the user problem and affected products.
2. Reuse existing semantic tokens before adding new core values.
3. Document accessibility and RTL behaviour.
4. Add or update examples and component states.
5. Obtain product, engineering and governance review for high-trust flows.
6. Increment the version according to semantic versioning.

Do not add a one-off colour or spacing value directly to a component when a semantic token can express the intent.
