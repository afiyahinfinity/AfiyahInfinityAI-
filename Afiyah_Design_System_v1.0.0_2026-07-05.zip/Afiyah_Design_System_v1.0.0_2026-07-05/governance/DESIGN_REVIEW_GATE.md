# Design review gate

A release requires:

- Product owner approval.
- Engineering implementation review.
- Accessibility review.
- Shariah/content governance review where religious language or guidance is involved.
- Privacy/security review for consent, identity, health, finance or AI action flows.
- Updated changelog and migration notes.
