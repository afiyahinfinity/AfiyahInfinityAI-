# File manifest

Files: 43

| Path | Bytes | SHA-256 |
|---|---:|---|
| `CHANGELOG.md` | 466 | `f590566ed6869ef74b5fbae9b044fdf71ed247b3a68e7d50101e08f946c17b84` |
| `README.md` | 3020 | `4bb65ad2ee9f533357a2cdeec16206dd2fd417fc466bffd40df54e8224a96ff0` |
| `accessibility/CONTRAST_REPORT.md` | 820 | `50131d4fdeb2febede390dfacee08f894ada803877b1d40b0488902aaf949f42` |
| `accessibility/WCAG.md` | 940 | `06459d85e2857c8bbef165300c8e143d554ba5e9905e7946869f1fdd396fce79` |
| `components/README.md` | 1339 | `eef219f1e643f19c98311aaad5398831ddb497c379b95bb3dd7a1515024c6a96` |
| `components/web/ApprovalCard.tsx` | 868 | `6de2259058f6e882d40bb8acee4171cd9964b7de67075d258bc26373f0e7fc70` |
| `components/web/Badge.tsx` | 381 | `6b6b5f83d21b2de65f40e3f68a7ad566145e22260198911c272a156752430df1` |
| `components/web/Button.tsx` | 556 | `44098b5de6cb3c8480c4716610dd5411f6bdea477aeef1af2a268774ee1c832b` |
| `components/web/Card.tsx` | 233 | `c68fe9c5d1279fbce8c4ae89da708dd8d61d1b73df41538d23ced481b2ed01be` |
| `components/web/Field.tsx` | 1223 | `084041471a412021857141ca0ffa65fd9d0b1d8e8be9f684e8556f8c6e2a237b` |
| `components/web/TrustNotice.tsx` | 403 | `dfb793c40139e3d0144f9960a4bfea46f546ffff5ad9e8caaa075e18591bd484` |
| `components/web/afiyah-components.css` | 3434 | `0612f5a63e6f83a7dacbbf052b6355430a953f5ea4bc7970c64e786e23ca1679` |
| `components/web/index.ts` | 163 | `250812e630b011faffb46a0d8bdd075ada47628ebd23a52ae55c8883962de781` |
| `components/web/utils.ts` | 129 | `4041cd25989afeb12ddd44d8cc086dd50a8c762c5b3971ca8f173504e1ad5b51` |
| `examples/mobile/README.md` | 256 | `3f471937b17a883a5685bc38395a0c5faa06b8f988db26eb751498a9276aae37` |
| `examples/web/README.md` | 98 | `7a18a5b1ef009eed85809cf7cbb7bbc53b45b65c54010939a0d60d09ca18c737` |
| `examples/web/index.html` | 3636 | `98a34b9d361941a068657c0447d2b1e79e397dd01c0b07d2891145292587ed1f` |
| `figma/COMPONENT_INVENTORY.csv` | 1041 | `55a6f7e1a7fed34eb4245e522bfefa7c4f539d19dbf0baa66a2b12b427740552` |
| `figma/HANDOFF_CHECKLIST.md` | 555 | `7a6c40660078e15a1763aed596905e7ba22a274905b7b6f92b0dd305cc3d5916` |
| `figma/PAGE_STRUCTURE.md` | 788 | `3ddf9fe2049f82a70ab8d05a531aad360ec7f992169c4aff1ec7e0fdb0a8ebca` |
| `figma/README_FIGMA.md` | 1460 | `f97570fe9b6b9213465de4ff3026f45c8911c81f1fd3bab714f2aef11d252d08` |
| `figma/TYPOGRAPHY_STYLES.csv` | 554 | `a102453f5b978107a0b21178ce62d74f9a19784fa20f75c7f8ef560f126d3353` |
| `fonts/README.md` | 684 | `2fa680e9d0bb6753b40fc49e957237a2ee143427c35629985d1ec2fba3ac9aa7` |
| `governance/CONTRIBUTING.md` | 505 | `dae8e67d0467657f9f0b55c42699e9d53c289b265d153acfea554b0ae6472fe1` |
| `governance/DESIGN_REVIEW_GATE.md` | 342 | `bc65b86d60cee465e6f8de1a59798d3b40e5605cd9271afeb758d582f0a2c123` |
| `governance/VERSIONING.md` | 361 | `d08eacda6b75a49d4c2947cdf399dae6a0f9eea2d65aa29a177851a272888626` |
| `icons/README.md` | 241 | `b81692c2deec9673ca6faad10a755909c78a66bdc4b074164c46eadc4afb7e68` |
| `icons/alert-triangle.svg` | 302 | `9366bae249d6fa8691ce0fdeabd73100e08209bbdfe9d7f97825d99a74c9011e` |
| `icons/check-circle.svg` | 228 | `95bc4d151869757d81120606ad647474870ea3ead07c33f29639229abe31ddd7` |
| `icons/heart.svg` | 285 | `a9263e7d0a1f274423a01936e51034afdb05a87ec3e89fedc8af23e90f569efa` |
| `icons/moon.svg` | 230 | `cafa2de603fe0d8e952f8ca4530893b1ea5c2353bf48b2cdfd1ceda4c508b26d` |
| `icons/shield-check.svg` | 256 | `7289b43dfd8d2f69de757435547b8f24850d5231d66b44c86e5753bb1d23ee2c` |
| `icons/sparkle.svg` | 311 | `7fffd46b13b1327029b88b4450bf8cab1147f4b0140878707564a3259b54d1fe` |
| `patterns/governance.md` | 452 | `8b381e6f540228af9b803b162225f47e54744624ebfd07724dd2b7e92a89170c` |
| `patterns/kyc-review.md` | 552 | `abd1dce0e47a7d7bdca66b5e1f3e81ce3ab4dbe37f89aa0efbe80d155a83ae13` |
| `patterns/membership.md` | 417 | `edf166606ecad78cbaa1a062d5f847b5b3e1a2ab5142eb2b4e3661a87dc68959` |
| `patterns/noor-chat.md` | 1065 | `0a263ba11bb9f6f508598a7df24bae17d89e57c9a251a4e37c5a7d8a3e62dcbd` |
| `tokens/afiyah-core.tokens.json` | 7832 | `dcc43b8732d1a5bbb0e1eb93ec267812183968ab89e7a1be11af40eb04f1142c` |
| `tokens/afiyah-semantic.tokens.json` | 5106 | `49df269b752db879a3a22543d29818f37040857a169d00b64736290d74f9b8f2` |
| `tokens/afiyah.css` | 2128 | `731a8d91bc9cbe50e52b15f517451100fc191f38d076e971132a57126424170e` |
| `tokens/react-native.ts` | 642 | `6ce20c1c8e62fba41cdead36d1cc0f8bb40594fcb5526849c10784b92db50b9b` |
| `tokens/tailwind.preset.ts` | 878 | `d5439ac34f9c01b937062d901a9ec415c5859400b4d9952f12eacfe51ccc578f` |
| `tokens/tokens-studio.json` | 2103 | `eefb092cd8fcc924f5b401b3a4de276fc7952a565b2b72865267d125be447a6c` |
