# Typography assets

Recommended families:

- Display: **Playfair Display**
- UI and body: **Montserrat**
- Alternative long-form body: **Lato**
- Arabic: **Amiri** or **Noto Naskh Arabic**

Font binaries are not included. Use licensed or open-source distribution channels and self-host only when permitted. Configure `font-display: swap` and provide system fallbacks.

## Usage

- Playfair Display: hero titles, section headings and high-emphasis editorial moments.
- Montserrat: navigation, controls, labels, body text and data-heavy screens.
- Lato: optional long-form learning content.
- Amiri: Qur'anic/Arabic passages where appropriate; never simulate Arabic with a Latin font.
