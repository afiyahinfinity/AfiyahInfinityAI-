# Component library

The library separates neutral primitives from high-trust product patterns.

## Core primitives

- Button: primary, secondary, outline, ghost, destructive.
- Card: default, elevated and interactive.
- Input and textarea: label, description, validation and disabled states.
- Badge: neutral, success, warning, danger, info and gold.
- Alert: inline feedback with title and action.
- Tabs: keyboard-operable tab list and panels.
- Dialog: focus-trapped confirmation surface.

## Afiyah-specific components

- Approval card: displays a proposed action with explicit approve/decline controls.
- Trust notice: explains AI limitations, audit and human control.
- Verification status: pending, approved, more-information and declined states.
- Barakah score card: deterministic score plus explanation; never implies religious judgement.
- Consent panel: plain-language purpose, data use, retention and withdrawal.

## Behavioural rules

1. No irreversible action occurs through a single ambiguous control.
2. Approve and decline actions use explicit verbs.
3. Destructive controls cannot rely on colour alone.
4. Loading states disable repeated submission.
5. Error messages say what happened, what was not changed, and what to do next.
6. AI-generated content must be visually distinguished from verified religious guidance.
