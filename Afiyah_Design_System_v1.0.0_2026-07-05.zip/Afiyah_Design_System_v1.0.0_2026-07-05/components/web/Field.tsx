import type { InputHTMLAttributes, TextareaHTMLAttributes } from "react";
interface Base { label:string; description?:string; error?:string; id:string; }
export function AfInput({label,description,error,id,...props}:Base & InputHTMLAttributes<HTMLInputElement>) {
  const hint=error?`${id}-error`:description?`${id}-help`:undefined;
  return <label className="af-field" htmlFor={id}><span className="af-label">{label}</span><input id={id} className="af-input" aria-invalid={!!error} aria-describedby={hint} {...props}/>{error?<span id={`${id}-error`} className="af-error">{error}</span>:description?<span id={`${id}-help`} className="af-help">{description}</span>:null}</label>;
}
export function AfTextarea({label,description,error,id,...props}:Base & TextareaHTMLAttributes<HTMLTextAreaElement>) {
  const hint=error?`${id}-error`:description?`${id}-help`:undefined;
  return <label className="af-field" htmlFor={id}><span className="af-label">{label}</span><textarea id={id} className="af-textarea" aria-invalid={!!error} aria-describedby={hint} {...props}/>{error?<span id={`${id}-error`} className="af-error">{error}</span>:description?<span id={`${id}-help`} className="af-help">{description}</span>:null}</label>;
}
