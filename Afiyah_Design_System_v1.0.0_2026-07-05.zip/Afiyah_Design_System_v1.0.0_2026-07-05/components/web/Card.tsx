import type { HTMLAttributes } from "react";
import { afCx } from "./utils";
export function AfCard({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <section className={afCx("af-card", className)} {...props} />;
}
