import { AfButton } from "./Button";
export interface ApprovalCardProps { title:string; reason?:string; details?:unknown; busy?:boolean; onApprove():void; onDecline():void; }
export function ApprovalCard({title,reason,details,busy,onApprove,onDecline}:ApprovalCardProps) {
  return <section className="af-approval" aria-labelledby={`approval-${title}`}>
    <div className="af-approval__eyebrow">Approval required</div>
    <h3 id={`approval-${title}`}>{title}</h3>
    {reason && <p>{reason}</p>}
    {details !== undefined && <pre>{JSON.stringify(details,null,2)}</pre>}
    <div className="af-approval__actions">
      <AfButton variant="accent" disabled={busy} onClick={onApprove}>{busy?"Processing…":"Approve action"}</AfButton>
      <AfButton variant="outline" disabled={busy} onClick={onDecline}>Decline; change nothing</AfButton>
    </div>
  </section>;
}
