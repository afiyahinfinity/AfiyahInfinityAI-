import type { ReactNode } from "react";
export function TrustNotice({title="Your control comes first",children}:{title?:string;children?:ReactNode}) {
  return <aside className="af-alert" role="note"><span aria-hidden="true">◈</span><div><strong>{title}</strong><div>{children ?? "AI may suggest, but it cannot approve or execute an action without your explicit confirmation."}</div></div></aside>;
}
