import type { ButtonHTMLAttributes, ReactNode } from "react";
import { afCx } from "./utils";

type Variant = "primary" | "accent" | "outline" | "ghost" | "danger";
export interface AfButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  leadingIcon?: ReactNode;
}
export function AfButton({ variant="primary", leadingIcon, className, children, type="button", ...props }: AfButtonProps) {
  return <button type={type} className={afCx("af-btn", `af-btn--${variant}`, className)} {...props}>{leadingIcon}{children}</button>;
}
