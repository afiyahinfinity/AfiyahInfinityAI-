import type { HTMLAttributes } from "react";
import { afCx } from "./utils";
type Tone = "neutral" | "success" | "warning" | "danger" | "info" | "gold";
export function AfBadge({ tone="neutral", className, ...props }: HTMLAttributes<HTMLSpanElement> & {tone?:Tone}) {
  return <span className={afCx("af-badge", tone!=="neutral" && `af-badge--${tone}`, className)} {...props} />;
}
