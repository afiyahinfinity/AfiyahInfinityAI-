# Figma handoff checklist

- [ ] Approved logo source linked.
- [ ] Variable collections created and modes assigned.
- [ ] Text styles use approved fonts and fallbacks.
- [ ] Components use Auto Layout.
- [ ] Interactive states: hover, focus, pressed, disabled, loading and error.
- [ ] Responsive constraints documented.
- [ ] RTL examples reviewed.
- [ ] Accessibility annotations complete.
- [ ] Content sources and governance labels included.
- [ ] Code component names mapped to Figma components.
- [ ] Final library URL placed in repository README.
