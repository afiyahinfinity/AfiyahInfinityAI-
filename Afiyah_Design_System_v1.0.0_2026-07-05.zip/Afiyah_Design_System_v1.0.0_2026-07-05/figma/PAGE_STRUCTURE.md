# Figma page structure

Each page starts with a status banner containing owner, reviewer, version and publication state.

- Foundations: colour, semantic roles, typography, grid, spacing, elevation, radius, motion and iconography.
- Components: anatomy, variants, states, responsive rules and accessibility notes.
- Noor Patterns: conversation, proposal, approval, rejection, failure and crisis substitution.
- Sister App: onboarding, dashboard, check-in, learning, health, wealth and community flows.
- Partners: application, evidence submission, decision and onboarding.
- Admin & Review: identity queue, audit log, content governance and system health.
- Mobile: phone-specific variants and safe-area behaviour.
- Accessibility: keyboard flows, focus order, contrast and RTL examples.
