# Figma setup

This folder is designed to bootstrap a real editable Figma library.

## Import sequence

1. Create a Figma design file named `Afiyah Infinity AI — Design System`.
2. Install Tokens Studio or use an approved variable-import workflow.
3. Import `../tokens/tokens-studio.json`.
4. Create variable collections: `Core`, `Semantic Light`, `Semantic Dark`, `Spacing`, `Radius`, `Motion`.
5. Create text styles from `TYPOGRAPHY_STYLES.csv`.
6. Build components in the order listed in `COMPONENT_INVENTORY.csv`.
7. Add variants and component properties exactly as specified.
8. Run contrast and keyboard reviews before publishing the library.
9. Link the final Figma `/design/` URL in this README and in the engineering repository.

## Required Figma pages

1. `00 Cover & Status`
2. `01 Foundations`
3. `02 Components`
4. `03 Noor Patterns`
5. `04 Sister App`
6. `05 Partners`
7. `06 Admin & Review`
8. `07 Mobile`
9. `08 Accessibility`
10. `99 Deprecated`

## Library publication gate

A Figma library is publishable only when:

- tokens match the repository;
- all components have keyboard/focus annotations;
- RTL behaviour is documented;
- destructive and approval flows have reviewed copy;
- components are named consistently;
- developer handoff includes states and responsive rules.

**Important:** no native `.fig` file is included in this ZIP. The import assets are real, but they are not a substitute for an editable reviewed Figma library.
