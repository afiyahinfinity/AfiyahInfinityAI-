# Changelog

## 1.0.0 — 5 July 2026

- Established core, semantic, typography, spacing, radius, shadow, motion and breakpoint tokens.
- Added CSS, Tailwind, React Native and Tokens Studio exports.
- Added accessible web primitives and product-specific approval components.
- Added Noor, KYC, membership and partner-governance patterns.
- Added WCAG contrast review and RTL guidance.
- Added Figma import and handoff documentation.
- Added standalone HTML preview.
