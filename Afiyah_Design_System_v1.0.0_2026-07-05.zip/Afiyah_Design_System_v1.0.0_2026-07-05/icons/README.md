# Interface icons

These are simple stroke icons for product interfaces. They inherit `currentColor`, use a 24 × 24 viewBox and should normally render at 20–24 px.

They are not the official Afiyah logo or a substitute for brand artwork.
