# Contrast report

Ratios are calculated using WCAG relative luminance.

| Foreground | Background | Ratio | Result |
|---|---|---:|---|
| Ivory `#F8F3E9` | Deep Green `#003629` | 12.17:1 | AAA |
| White `#FFFFFF` | Deep Green `#003629` | 13.46:1 | AAA |
| Charcoal `#181715` | Ivory `#F8F3E9` | 16.20:1 | AAA |
| Deep Green `#003629` | Ivory `#F8F3E9` | 12.17:1 | AAA |
| Noor Gold `#C9A84C` | Noor Background `#0A1F14` | 7.54:1 | AAA |
| Noor Green `#2E9E80` | Noor Background `#0A1F14` | 5.18:1 | AA |
| Brand Gold `#AD8633` | Deep Green `#003629` | 4.00:1 | Large text/UI only |
| Brand Gold `#AD8633` | Ivory `#F8F3E9` | 3.05:1 | Large text/UI only |

Do not use brand gold for normal-size body text on ivory. Use deep green or charcoal for text and reserve gold for accents, large display text, borders and icons.
