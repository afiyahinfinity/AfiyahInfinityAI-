# Accessibility baseline

Target **WCAG 2.2 AA** for all user-facing experiences.

## Requirements

- Body text contrast: at least 4.5:1.
- Large text and essential non-text UI: at least 3:1.
- Minimum interactive target: 44 × 44 CSS pixels.
- Visible keyboard focus with at least 3:1 contrast against adjacent colours.
- No meaning conveyed by colour alone.
- Form errors linked through `aria-describedby`.
- Dialogs trap focus and return it to the invoking control.
- Motion respects `prefers-reduced-motion`.
- Text supports 200% zoom without loss of content or function.
- RTL layouts use logical properties (`margin-inline`, `border-inline-start`).
- Arabic text is not artificially letter-spaced.
- Qur'anic quotations include source and translation attribution approved by governance.

## Language

Use direct, respectful language. Avoid infantilising terms, guilt-driven prompts or religious judgement in scores and notifications.
