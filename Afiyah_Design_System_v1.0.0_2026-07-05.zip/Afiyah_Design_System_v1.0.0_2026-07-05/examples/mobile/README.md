# Mobile integration

Use `tokens/react-native.ts` with React Native or Expo. Maintain 44-point minimum controls, safe-area padding and platform-native accessibility labels. The web component source is not intended to be copied directly into React Native.
