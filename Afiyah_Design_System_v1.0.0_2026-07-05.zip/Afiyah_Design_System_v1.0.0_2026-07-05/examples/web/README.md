Open `index.html` in a browser. It uses only local CSS and has no network or secret dependencies.
