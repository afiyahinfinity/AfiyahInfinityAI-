export const afiyah = {
  color: {
    deepGreen: "#003629", gold: "#AD8633", ivory: "#F8F3E9",
    charcoal: "#181715", deepTeal: "#0C383F", noorGold: "#C9A84C",
    noorGreen: "#2E9E80", success: "#147A55", warning: "#9A6412",
    danger: "#B42318", info: "#175CD3",
  },
  space: { 1: 4, 2: 8, 3: 12, 4: 16, 5: 20, 6: 24, 8: 32, 10: 40, 12: 48 },
  radius: { sm: 6, md: 10, lg: 14, xl: 20, full: 9999 },
  type: {
    family: { display: "PlayfairDisplay", sans: "Montserrat", arabic: "Amiri" },
    size: { xs: 12, sm: 14, md: 16, lg: 18, xl: 20, xxl: 24, display: 36 },
  },
  motion: { fast: 120, standard: 200, slow: 320 },
} as const;
