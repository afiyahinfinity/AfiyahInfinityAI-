import type { Config } from "tailwindcss";

const preset: Partial<Config> = {
  theme: {
    extend: {
      colors: {
        afiyah: {
          green: "#003629",
          gold: "#AD8633",
          ivory: "#F8F3E9",
          charcoal: "#181715",
          teal: "#0C383F",
          noorGold: "#C9A84C",
          noorGreen: "#2E9E80",
        },
      },
      fontFamily: {
        display: ['"Playfair Display"', "Georgia", "serif"],
        sans: ["Montserrat", "Inter", "Arial", "sans-serif"],
        arabic: ["Amiri", '"Noto Naskh Arabic"', "serif"],
      },
      borderRadius: { af: ".625rem", "af-lg": ".875rem", "af-xl": "1.25rem" },
      boxShadow: {
        "af-sm": "0 1px 3px rgba(24,23,21,.08)",
        "af-md": "0 6px 18px -4px rgba(24,23,21,.12)",
        "af-lg": "0 16px 36px -8px rgba(24,23,21,.16)",
      },
    },
  },
};

export default preset;
