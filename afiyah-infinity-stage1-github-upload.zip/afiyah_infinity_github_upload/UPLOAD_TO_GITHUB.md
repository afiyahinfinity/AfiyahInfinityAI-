# Upload instructions

Target repository: `afiyahinfinity/mtbdiaries1-afiyah-infinity`

1. Extract this ZIP locally.
2. Open the target repository on GitHub.
3. Initialise the empty repository with a README if GitHub requests it.
4. Upload the extracted files, preserving the directory structure.
5. Commit with: `security: add Noor Stage 1 remediation pack`.
6. Do not deploy directly to production. Integrate and validate against staging first.
