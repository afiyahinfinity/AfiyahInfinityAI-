# Afiyah Infinity AI

Official engineering repository for Afiyah Infinity AI.

## Stage 1 security remediation

This repository bundle contains the first independently reviewed remediation release for Noor:

- authenticated session-ownership enforcement;
- atomic approval and execution;
- hardened PostgreSQL `SECURITY DEFINER` functions;
- immutable proposals and idempotent execution;
- security tests and deployment instructions.

The readable source is under `security-remediation/stage1/`.
The complete reviewed release archive is under `releases/`.

## Deployment warning

This is a remediation package, not a complete standalone Next.js application. Integrate it into the production application, apply the migration in staging, run the security tests, and complete the deployment checklist before promoting to `afiyahinfinityai.com`.
