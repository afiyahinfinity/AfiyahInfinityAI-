# Icons

The scaffold uses Material Symbols through Flutter's built-in `Icons` set. Add only licensed, optimized SVG or PNG assets here. Every custom icon requires a semantic label, dark-mode review and RTL behavior review where directional meaning is involved.
