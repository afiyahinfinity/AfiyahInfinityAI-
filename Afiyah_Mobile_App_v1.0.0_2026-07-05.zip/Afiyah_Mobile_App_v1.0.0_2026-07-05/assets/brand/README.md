# Brand assets

`afiyah_infinity_mark.svg` is an engineering placeholder built from the approved color palette. Replace it with the legally approved master logo before store submission. No font files are included; the app uses platform/system typography until licensed brand-font delivery is approved.
