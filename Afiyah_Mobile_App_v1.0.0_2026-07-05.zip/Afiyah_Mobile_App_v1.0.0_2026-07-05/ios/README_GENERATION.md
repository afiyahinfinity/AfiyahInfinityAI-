# iOS platform shell

Run `../scripts/bootstrap_platforms.sh` from the package root on a supported development environment. Signing, entitlements, associated domains and privacy usage strings require project-specific approval.
