#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter is not installed or not on PATH." >&2
  exit 1
fi

if [[ -d android || -d ios ]]; then
  echo "android/ or ios/ already exists; refusing to overwrite." >&2
  exit 1
fi

tmp_dir="$(mktemp -d)"
trap 'rm -rf "$tmp_dir"' EXIT

flutter create \
  --platforms=android,ios \
  --org=com.afiyahinfinity \
  --project-name=afiyah_mobile_app \
  "$tmp_dir/afiyah_mobile_app"

cp -R "$tmp_dir/afiyah_mobile_app/android" ./android
cp -R "$tmp_dir/afiyah_mobile_app/ios" ./ios

cat <<'EOF'
Platform shells created.
Next:
1. Review Android applicationId and iOS bundle identifier.
2. Add signing outside source control.
3. Apply platform setup from flutter_secure_storage and local_auth.
4. Configure deep links and privacy strings.
5. Run flutter pub get, flutter analyze and flutter test.
EOF
