#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    'README.md',
    'pubspec.yaml',
    'analysis_options.yaml',
    'lib/main.dart',
    'lib/app.dart',
    'lib/core/security/noor_guard.dart',
    'docs/SECURITY.md',
    'test/noor_guard_test.dart',
]

errors: list[str] = []
for rel in REQUIRED:
    if not (ROOT / rel).is_file():
        errors.append(f'missing required file: {rel}')

for path in ROOT.rglob('*'):
    if path.resolve() == Path(__file__).resolve():
        continue
    if not path.is_file() or path.suffix.lower() in {'.zip', '.png', '.jpg', '.jpeg', '.webp'}:
        continue
    try:
        text = path.read_text(encoding='utf-8')
    except UnicodeDecodeError:
        continue
    if re.search(r'(?i)(service[_-]?role|anthropic|openai|resend)[_-]?(key|token)\s*[:=]\s*["\'][^"\']{12,}', text):
        errors.append(f'possible privileged secret in {path.relative_to(ROOT)}')
    if 'BEGIN PRIVATE KEY' in text:
        errors.append(f'private key material in {path.relative_to(ROOT)}')

try:
    json.loads((ROOT / 'assets/config/tokens.mobile.json').read_text(encoding='utf-8'))
except Exception as exc:  # noqa: BLE001
    errors.append(f'invalid tokens JSON: {exc}')

if errors:
    print('VALIDATION FAILED')
    for error in errors:
        print(f'- {error}')
    sys.exit(1)

print('VALIDATION PASSED')
print(f'Root: {ROOT}')
print(f'Files: {sum(1 for p in ROOT.rglob("*") if p.is_file())}')
