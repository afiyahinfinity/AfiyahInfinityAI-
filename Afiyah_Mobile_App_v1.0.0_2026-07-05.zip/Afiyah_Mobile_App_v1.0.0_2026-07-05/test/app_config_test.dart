import 'package:afiyah_mobile_app/core/config/app_config.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('configuration identifies production exactly', () {
    final config = AppConfig(
      environment: 'production',
      apiBaseUrl: Uri.parse('https://api.afiyahinfinityai.com'),
      webBaseUrl: Uri.parse('https://afiyahinfinityai.com'),
      mockMode: false,
      enableBiometrics: true,
      enableScreenProtection: false,
      sentryDsn: null,
    );
    expect(config.isProduction, isTrue);
  });
}
