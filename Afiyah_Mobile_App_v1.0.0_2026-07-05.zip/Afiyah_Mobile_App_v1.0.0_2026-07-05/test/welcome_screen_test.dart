import 'package:afiyah_mobile_app/features/onboarding/presentation/welcome_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('welcome screen states the product promise', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(home: WelcomeScreen()),
    );
    expect(find.text('Wholeness across faith, health and wealth.'), findsOneWidget);
    expect(find.text('Begin with niyyah'), findsOneWidget);
  });
}
