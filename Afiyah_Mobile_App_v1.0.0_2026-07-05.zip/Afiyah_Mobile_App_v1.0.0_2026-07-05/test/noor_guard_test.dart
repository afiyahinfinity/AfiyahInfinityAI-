import 'package:afiyah_mobile_app/core/security/noor_guard.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const guard = NoorGuard();

  test('allows a normal educational question', () {
    final result = guard.evaluate('Explain diversification simply.');
    expect(result.decision, NoorGuardDecision.allow);
    expect(result.allowed, isTrue);
  });

  test('blocks card-like number', () {
    final result = guard.evaluate('My card is 4242424242424242');
    expect(result.decision, NoorGuardDecision.blockSensitiveData);
    expect(result.allowed, isFalse);
  });

  test('routes crisis language away from the model', () {
    final result = guard.evaluate('I want to kill myself');
    expect(result.decision, NoorGuardDecision.blockCrisis);
    expect(result.allowed, isFalse);
  });

  test('routes personalized execution request to licensed support', () {
    final result = guard.evaluate('Tell me exactly what to buy');
    expect(result.decision, NoorGuardDecision.requireLicensedPartner);
    expect(result.allowed, isFalse);
  });
}
