# Android platform shell

Run `../scripts/bootstrap_platforms.sh` from the package root to generate Android and iOS shells using the approved Flutter SDK. This placeholder prevents an unreviewed, stale Gradle project from being mistaken for production configuration.
