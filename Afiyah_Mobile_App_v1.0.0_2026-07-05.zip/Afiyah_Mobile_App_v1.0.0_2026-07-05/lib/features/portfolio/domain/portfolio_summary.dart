class PortfolioSummary {
  const PortfolioSummary({
    required this.currency,
    required this.totalValue,
    required this.cashValue,
    required this.investedValue,
    required this.lastUpdated,
  });

  final String currency;
  final double totalValue;
  final double cashValue;
  final double investedValue;
  final DateTime lastUpdated;

  factory PortfolioSummary.fromJson(Map<String, Object?> json) {
    return PortfolioSummary(
      currency: json['currency'] as String? ?? 'USD',
      totalValue: (json['total_value'] as num?)?.toDouble() ?? 0,
      cashValue: (json['cash_value'] as num?)?.toDouble() ?? 0,
      investedValue: (json['invested_value'] as num?)?.toDouble() ?? 0,
      lastUpdated: DateTime.tryParse(json['last_updated'] as String? ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0, isUtc: true),
    );
  }
}
