import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/config/app_config.dart';
import '../../../core/network/api_client.dart';
import '../domain/portfolio_summary.dart';

final portfolioRepositoryProvider = Provider<PortfolioRepository>((ref) {
  return PortfolioRepository(
    apiClient: ref.watch(apiClientProvider),
    config: ref.watch(appConfigProvider),
  );
});

final portfolioSummaryProvider = FutureProvider<PortfolioSummary>((ref) {
  return ref.watch(portfolioRepositoryProvider).fetchSummary();
});

class PortfolioRepository {
  PortfolioRepository({
    required ApiClient apiClient,
    required AppConfig config,
  })  : _apiClient = apiClient,
        _config = config;

  final ApiClient _apiClient;
  final AppConfig _config;

  Future<PortfolioSummary> fetchSummary() async {
    if (_config.mockMode) {
      return PortfolioSummary(
        currency: 'USD',
        totalValue: 12500,
        cashValue: 3200,
        investedValue: 9300,
        lastUpdated: DateTime.now().toUtc(),
      );
    }
    final response = await _apiClient.getJson('/v1/portfolio/summary');
    return PortfolioSummary.fromJson(response);
  }
}
