import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/afiyah_spacing.dart';
import '../../../core/widgets/afiyah_page.dart';
import '../../../core/widgets/trust_banner.dart';
import '../data/portfolio_repository.dart';

class PortfolioScreen extends ConsumerWidget {
  const PortfolioScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final portfolio = ref.watch(portfolioSummaryProvider);
    return AfiyahPage(
      title: 'Portfolio overview',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const TrustBanner(
            message:
                'View-only educational summary. Assets remain with your licensed provider or institution.',
          ),
          const SizedBox(height: AfiyahSpacing.lg),
          portfolio.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, stackTrace) => const Text(
              'Portfolio information is unavailable. Please try again later.',
            ),
            data: (summary) => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${summary.currency} ${summary.totalValue.toStringAsFixed(2)}',
                  style: Theme.of(context).textTheme.headlineLarge,
                ),
                const Text('Connected account value'),
                const SizedBox(height: AfiyahSpacing.lg),
                _Row(
                  label: 'Cash and reserves',
                  value:
                      '${summary.currency} ${summary.cashValue.toStringAsFixed(2)}',
                ),
                _Row(
                  label: 'Invested through partners',
                  value:
                      '${summary.currency} ${summary.investedValue.toStringAsFixed(2)}',
                ),
              ],
            ),
          ),
          const SizedBox(height: AfiyahSpacing.lg),
          Text(
            'Shariah review status',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: AfiyahSpacing.sm),
          const Card(
            child: ListTile(
              leading: Icon(Icons.fact_check_outlined),
              title: Text('Partner data pending verification'),
              subtitle: Text(
                'Only approved partner classifications should appear here in production.',
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AfiyahSpacing.sm),
      child: Row(
        children: [
          Expanded(child: Text(label)),
          Text(value, style: Theme.of(context).textTheme.titleMedium),
        ],
      ),
    );
  }
}
