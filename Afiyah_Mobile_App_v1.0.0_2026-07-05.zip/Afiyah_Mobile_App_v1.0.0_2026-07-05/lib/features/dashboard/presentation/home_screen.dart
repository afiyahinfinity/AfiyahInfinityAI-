import 'package:flutter/material.dart';

import '../../../core/theme/afiyah_spacing.dart';
import '../../../core/widgets/afiyah_page.dart';
import '../../../core/widgets/trust_banner.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AfiyahPage(
      title: 'Assalamu alaikum',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Your Afiyah today',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          const SizedBox(height: AfiyahSpacing.md),
          const _MetricCard(
            title: 'Barakah baseline',
            value: 'Growing',
            detail: 'Reflective check-in due today',
            icon: Icons.auto_awesome_outlined,
          ),
          const SizedBox(height: AfiyahSpacing.md),
          const _MetricCard(
            title: 'Learning path',
            value: '3 of 8',
            detail: 'Money foundations · Module 1',
            icon: Icons.menu_book_outlined,
          ),
          const SizedBox(height: AfiyahSpacing.md),
          const TrustBanner(
            message:
                'Portfolio values are informational. Afiyah does not hold assets or execute transactions.',
            icon: Icons.account_balance_wallet_outlined,
          ),
          const SizedBox(height: AfiyahSpacing.lg),
          Text(
            'Today’s gentle action',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: AfiyahSpacing.sm),
          const Card(
            child: ListTile(
              leading: Icon(Icons.check_circle_outline),
              title: Text('Name one financial intention for this week'),
              subtitle: Text('Private reflection · about 2 minutes'),
            ),
          ),
        ],
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.title,
    required this.value,
    required this.detail,
    required this.icon,
  });

  final String title;
  final String value;
  final String detail;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(AfiyahSpacing.md),
        child: Row(
          children: [
            Icon(icon, size: 32),
            const SizedBox(width: AfiyahSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.labelLarge),
                  Text(value, style: Theme.of(context).textTheme.titleLarge),
                  Text(detail),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
