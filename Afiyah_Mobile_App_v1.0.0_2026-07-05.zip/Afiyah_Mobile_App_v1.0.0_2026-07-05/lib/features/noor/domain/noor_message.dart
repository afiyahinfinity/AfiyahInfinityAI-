enum NoorMessageRole { user, assistant, system }

class NoorMessage {
  const NoorMessage({
    required this.role,
    required this.content,
    required this.createdAt,
    this.requiresHumanReview = false,
  });

  final NoorMessageRole role;
  final String content;
  final DateTime createdAt;
  final bool requiresHumanReview;
}

class NoorReply {
  const NoorReply({
    required this.message,
    required this.requiresHumanReview,
    this.proposalId,
  });

  final String message;
  final bool requiresHumanReview;
  final String? proposalId;

  factory NoorReply.fromJson(Map<String, Object?> json) {
    return NoorReply(
      message: json['message'] as String? ??
          'Noor could not prepare a response at this time.',
      requiresHumanReview: json['requires_human_review'] as bool? ?? false,
      proposalId: json['proposal_id'] as String?,
    );
  }
}
