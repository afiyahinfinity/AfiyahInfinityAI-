import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/afiyah_spacing.dart';
import '../../../core/widgets/trust_banner.dart';
import '../application/noor_controller.dart';
import '../domain/noor_message.dart';

class NoorScreen extends ConsumerStatefulWidget {
  const NoorScreen({super.key});

  @override
  ConsumerState<NoorScreen> createState() => _NoorScreenState();
}

class _NoorScreenState extends ConsumerState<NoorScreen> {
  final _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final messages = ref.watch(noorControllerProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Noor AI guide')),
      body: SafeArea(
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: TrustBanner(
                message:
                    'Do not share passwords, card details, identity numbers or one-time codes.',
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(AfiyahSpacing.md),
                itemCount: messages.length,
                itemBuilder: (context, index) {
                  final message = messages[index];
                  return _MessageBubble(message: message);
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(AfiyahSpacing.md),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      maxLines: 4,
                      minLines: 1,
                      decoration: const InputDecoration(
                        hintText: 'Ask a learning or reflection question',
                      ),
                    ),
                  ),
                  const SizedBox(width: AfiyahSpacing.sm),
                  IconButton.filled(
                    tooltip: 'Send message',
                    onPressed: _send,
                    icon: const Icon(Icons.send_outlined),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _send() async {
    final text = _controller.text;
    _controller.clear();
    await ref.read(noorControllerProvider.notifier).send(text);
  }
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({required this.message});

  final NoorMessage message;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final isUser = message.role == NoorMessageRole.user;
    final isSystem = message.role == NoorMessageRole.system;
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 340),
        margin: const EdgeInsets.only(bottom: AfiyahSpacing.sm),
        padding: const EdgeInsets.all(AfiyahSpacing.md),
        decoration: BoxDecoration(
          color: isSystem
              ? colors.errorContainer
              : isUser
                  ? colors.primaryContainer
                  : colors.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(message.content),
            if (message.requiresHumanReview) ...[
              const SizedBox(height: AfiyahSpacing.xs),
              const Text(
                'Human or licensed support recommended',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
