import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/security/noor_guard.dart';
import '../data/noor_repository.dart';
import '../domain/noor_message.dart';

final noorControllerProvider =
    NotifierProvider<NoorController, List<NoorMessage>>(NoorController.new);

class NoorController extends Notifier<List<NoorMessage>> {
  final NoorGuard _guard = const NoorGuard();
  bool _busy = false;

  bool get busy => _busy;

  @override
  List<NoorMessage> build() {
    return [
      NoorMessage(
        role: NoorMessageRole.assistant,
        content:
            'Assalamu alaikum. I can help you learn, reflect and prepare questions. I do not replace a scholar, doctor or licensed financial adviser.',
        createdAt: DateTime.now().toUtc(),
      ),
    ];
  }

  Future<void> send(String rawMessage) async {
    if (_busy) {
      return;
    }
    final guard = _guard.evaluate(rawMessage);
    if (!guard.allowed) {
      state = [
        ...state,
        NoorMessage(
          role: NoorMessageRole.system,
          content: guard.safeMessage,
          createdAt: DateTime.now().toUtc(),
          requiresHumanReview:
              guard.decision == NoorGuardDecision.blockCrisis ||
                  guard.decision == NoorGuardDecision.requireLicensedPartner,
        ),
      ];
      return;
    }

    final message = guard.safeMessage;
    if (message.isEmpty) {
      return;
    }
    _busy = true;
    state = [
      ...state,
      NoorMessage(
        role: NoorMessageRole.user,
        content: message,
        createdAt: DateTime.now().toUtc(),
      ),
    ];
    try {
      final reply = await ref.read(noorRepositoryProvider).sendMessage(
            sessionId: 'mobile-session',
            message: message,
          );
      state = [
        ...state,
        NoorMessage(
          role: NoorMessageRole.assistant,
          content: reply.message,
          createdAt: DateTime.now().toUtc(),
          requiresHumanReview: reply.requiresHumanReview,
        ),
      ];
    } on Object {
      state = [
        ...state,
        NoorMessage(
          role: NoorMessageRole.system,
          content:
              'Noor is unavailable. Your message was not used to make an autonomous decision.',
          createdAt: DateTime.now().toUtc(),
        ),
      ];
    } finally {
      _busy = false;
    }
  }
}
