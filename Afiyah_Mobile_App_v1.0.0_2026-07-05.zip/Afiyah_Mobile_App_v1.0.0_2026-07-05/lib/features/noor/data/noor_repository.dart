import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/config/app_config.dart';
import '../../../core/network/api_client.dart';
import '../domain/noor_message.dart';

final noorRepositoryProvider = Provider<NoorRepository>((ref) {
  return NoorRepository(
    apiClient: ref.watch(apiClientProvider),
    config: ref.watch(appConfigProvider),
  );
});

class NoorRepository {
  NoorRepository({
    required ApiClient apiClient,
    required AppConfig config,
  })  : _apiClient = apiClient,
        _config = config;

  final ApiClient _apiClient;
  final AppConfig _config;

  Future<NoorReply> sendMessage({
    required String sessionId,
    required String message,
  }) async {
    if (_config.mockMode) {
      return const NoorReply(
        message:
            'Let us turn that into one clear learning step. What outcome matters most to you, and what constraints should we respect?',
        requiresHumanReview: false,
      );
    }
    final idempotencyKey =
        'noor-${DateTime.now().toUtc().microsecondsSinceEpoch}';
    final response = await _apiClient.postJson(
      '/v1/noor/message',
      body: {
        'session_id': sessionId,
        'message': message,
        'channel': 'mobile',
      },
      idempotencyKey: idempotencyKey,
    );
    return NoorReply.fromJson(response);
  }
}
