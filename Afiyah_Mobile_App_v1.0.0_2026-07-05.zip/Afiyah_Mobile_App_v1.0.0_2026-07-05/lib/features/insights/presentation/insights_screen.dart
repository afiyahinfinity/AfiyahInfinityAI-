import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/afiyah_spacing.dart';
import '../../../core/widgets/afiyah_page.dart';
import '../../../core/widgets/trust_banner.dart';
import '../data/insights_repository.dart';

class InsightsScreen extends ConsumerWidget {
  const InsightsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final insights = ref.watch(insightsProvider);
    return AfiyahPage(
      title: 'Personal insights',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const TrustBanner(
            message:
                'Educational guidance only. Review your circumstances and consult an appropriately licensed professional before acting.',
            icon: Icons.lightbulb_outline,
          ),
          const SizedBox(height: AfiyahSpacing.lg),
          insights.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (error, stackTrace) => const Text(
              'Insights are unavailable. Your account remains safe.',
            ),
            data: (items) => Column(
              children: [
                for (final item in items) ...[
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.auto_awesome_outlined),
                      title: Text(item.title),
                      subtitle: Text(item.summary),
                      trailing: item.educationalOnly
                          ? const Tooltip(
                              message: 'Educational only',
                              child: Icon(Icons.school_outlined),
                            )
                          : null,
                    ),
                  ),
                  const SizedBox(height: AfiyahSpacing.sm),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
