class FinancialInsight {
  const FinancialInsight({
    required this.title,
    required this.summary,
    required this.category,
    required this.educationalOnly,
  });

  final String title;
  final String summary;
  final String category;
  final bool educationalOnly;

  factory FinancialInsight.fromJson(Map<String, Object?> json) {
    return FinancialInsight(
      title: json['title'] as String? ?? 'Insight',
      summary: json['summary'] as String? ?? '',
      category: json['category'] as String? ?? 'general',
      educationalOnly: json['educational_only'] as bool? ?? true,
    );
  }
}
