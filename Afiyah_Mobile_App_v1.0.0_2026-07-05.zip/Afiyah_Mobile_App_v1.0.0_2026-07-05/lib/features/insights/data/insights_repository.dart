import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/config/app_config.dart';
import '../../../core/network/api_client.dart';
import '../domain/financial_insight.dart';

final insightsRepositoryProvider = Provider<InsightsRepository>((ref) {
  return InsightsRepository(
    apiClient: ref.watch(apiClientProvider),
    config: ref.watch(appConfigProvider),
  );
});

final insightsProvider = FutureProvider<List<FinancialInsight>>((ref) {
  return ref.watch(insightsRepositoryProvider).fetchInsights();
});

class InsightsRepository {
  InsightsRepository({
    required ApiClient apiClient,
    required AppConfig config,
  })  : _apiClient = apiClient,
        _config = config;

  final ApiClient _apiClient;
  final AppConfig _config;

  Future<List<FinancialInsight>> fetchInsights() async {
    if (_config.mockMode) {
      return const [
        FinancialInsight(
          title: 'Build a three-month reserve gently',
          summary:
              'Explore a weekly savings target based on your own expenses and responsibilities.',
          category: 'resilience',
          educationalOnly: true,
        ),
        FinancialInsight(
          title: 'Questions to ask a halal investment provider',
          summary:
              'Ask about screening methodology, purification, fees, custody and scholar oversight.',
          category: 'learning',
          educationalOnly: true,
        ),
      ];
    }
    final response = await _apiClient.getJson('/v1/insights');
    final items = response['items'];
    if (items is! List<Object?>) {
      return const [];
    }
    return items
        .whereType<Map<String, Object?>>()
        .map(FinancialInsight.fromJson)
        .toList(growable: false);
  }
}
