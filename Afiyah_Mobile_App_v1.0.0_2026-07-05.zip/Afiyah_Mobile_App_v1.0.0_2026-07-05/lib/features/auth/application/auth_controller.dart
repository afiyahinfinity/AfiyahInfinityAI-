import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/config/app_config.dart';
import '../../../core/network/api_client.dart';
import '../../../core/security/secure_session_store.dart';
import '../data/auth_repository.dart';
import '../domain/auth_state.dart';

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  return AuthRepository(
    apiClient: ref.watch(apiClientProvider),
    sessionStore: ref.watch(secureSessionStoreProvider),
    config: ref.watch(appConfigProvider),
  );
});

final authControllerProvider = NotifierProvider<AuthController, AuthState>(
  AuthController.new,
);

class AuthController extends Notifier<AuthState> {
  @override
  AuthState build() {
    Future<void>.microtask(_restore);
    return const AuthState.unknown();
  }

  Future<void> _restore() async {
    final userId = await ref.read(authRepositoryProvider).restoreUserId();
    state = userId == null
        ? const AuthState.signedOut()
        : AuthState(status: AuthStatus.signedIn, userId: userId);
  }

  Future<bool> signIn({
    required String email,
    required String password,
  }) async {
    state = const AuthState.loading();
    try {
      final userId = await ref.read(authRepositoryProvider).signIn(
            email: email,
            password: password,
          );
      state = AuthState(status: AuthStatus.signedIn, userId: userId);
      return true;
    } on Object {
      state = const AuthState(
        status: AuthStatus.signedOut,
        errorMessage: 'Unable to sign in. Check your details and try again.',
      );
      return false;
    }
  }

  Future<void> signOut() async {
    await ref.read(authRepositoryProvider).signOut();
    state = const AuthState.signedOut();
  }
}
