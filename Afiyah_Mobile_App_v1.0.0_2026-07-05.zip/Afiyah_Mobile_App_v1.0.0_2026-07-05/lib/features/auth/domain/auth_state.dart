class AuthState {
  const AuthState({
    required this.status,
    this.userId,
    this.errorMessage,
  });

  const AuthState.unknown() : this(status: AuthStatus.unknown);
  const AuthState.signedOut() : this(status: AuthStatus.signedOut);
  const AuthState.loading() : this(status: AuthStatus.loading);

  final AuthStatus status;
  final String? userId;
  final String? errorMessage;

  bool get isSignedIn => status == AuthStatus.signedIn;
}

enum AuthStatus {
  unknown,
  loading,
  signedOut,
  signedIn,
}
