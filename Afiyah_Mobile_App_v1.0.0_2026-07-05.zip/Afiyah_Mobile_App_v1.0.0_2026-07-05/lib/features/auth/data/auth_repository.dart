import '../../../core/config/app_config.dart';
import '../../../core/network/api_client.dart';
import '../../../core/security/secure_session_store.dart';

class AuthRepository {
  AuthRepository({
    required ApiClient apiClient,
    required SecureSessionStore sessionStore,
    required AppConfig config,
  })  : _apiClient = apiClient,
        _sessionStore = sessionStore,
        _config = config;

  final ApiClient _apiClient;
  final SecureSessionStore _sessionStore;
  final AppConfig _config;

  Future<String> signIn({
    required String email,
    required String password,
  }) async {
    if (_config.mockMode) {
      await _sessionStore.saveSession(
        accessToken: 'mock-access-token',
        refreshToken: 'mock-refresh-token',
        userId: 'mock-sister-id',
      );
      return 'mock-sister-id';
    }

    final response = await _apiClient.postJson(
      '/v1/auth/login',
      body: {
        'email': email.trim(),
        'password': password,
      },
    );
    final accessToken = response['access_token'] as String?;
    final refreshToken = response['refresh_token'] as String?;
    final userId = response['user_id'] as String?;
    if (accessToken == null || refreshToken == null || userId == null) {
      throw const FormatException('Authentication response is incomplete.');
    }
    await _sessionStore.saveSession(
      accessToken: accessToken,
      refreshToken: refreshToken,
      userId: userId,
    );
    return userId;
  }

  Future<void> signOut() => _sessionStore.clear();

  Future<String?> restoreUserId() async {
    if (!await _sessionStore.hasSession()) {
      return null;
    }
    return _sessionStore.readUserId();
  }
}
