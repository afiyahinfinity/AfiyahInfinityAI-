import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/afiyah_spacing.dart';
import '../../../core/widgets/trust_banner.dart';

class ConsentScreen extends StatefulWidget {
  const ConsentScreen({super.key});

  @override
  State<ConsentScreen> createState() => _ConsentScreenState();
}

class _ConsentScreenState extends State<ConsentScreen> {
  bool privacyAccepted = false;
  bool aiAccepted = false;

  @override
  Widget build(BuildContext context) {
    final canContinue = privacyAccepted && aiAccepted;
    return Scaffold(
      appBar: AppBar(title: const Text('Your consent matters')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(AfiyahSpacing.lg),
          children: [
            Text(
              'Before we begin',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: AfiyahSpacing.md),
            const TrustBanner(
              message:
                  'AI assists with education and reflection. Humans remain responsible for approvals and regulated decisions.',
            ),
            const SizedBox(height: AfiyahSpacing.lg),
            CheckboxListTile(
              value: privacyAccepted,
              onChanged: (value) => setState(
                () => privacyAccepted = value ?? false,
              ),
              title: const Text('Privacy and account terms'),
              subtitle: const Text(
                'I understand what Afiyah collects, why it is used and how I can request deletion.',
              ),
              controlAffinity: ListTileControlAffinity.leading,
            ),
            CheckboxListTile(
              value: aiAccepted,
              onChanged: (value) => setState(
                () => aiAccepted = value ?? false,
              ),
              title: const Text('AI assistance disclosure'),
              subtitle: const Text(
                'I understand Noor is educational, may be imperfect and is not a scholar, doctor or financial adviser.',
              ),
              controlAffinity: ListTileControlAffinity.leading,
            ),
            const SizedBox(height: AfiyahSpacing.lg),
            FilledButton(
              onPressed: canContinue ? () => context.go('/login') : null,
              child: const Text('Continue securely'),
            ),
          ],
        ),
      ),
    );
  }
}
