import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/afiyah_colors.dart';
import '../../../core/theme/afiyah_spacing.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(AfiyahSpacing.lg),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Spacer(),
              Container(
                width: 72,
                height: 72,
                decoration: const BoxDecoration(
                  color: AfiyahColors.deepGreen,
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: const Text(
                  '∞',
                  style: TextStyle(
                    color: AfiyahColors.gold,
                    fontSize: 44,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(height: AfiyahSpacing.lg),
              Text(
                'Wholeness across faith, health and wealth.',
                style: Theme.of(context).textTheme.headlineLarge,
              ),
              const SizedBox(height: AfiyahSpacing.md),
              Text(
                'A private, women-first space for learning, reflection and responsible financial wellness.',
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              const Spacer(),
              FilledButton(
                onPressed: () => context.go('/consent'),
                child: const Text('Begin with niyyah'),
              ),
              const SizedBox(height: AfiyahSpacing.sm),
              TextButton(
                onPressed: () => context.go('/login'),
                child: const Text('I already have an account'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
