import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/afiyah_spacing.dart';
import '../../../core/widgets/afiyah_page.dart';
import '../../auth/application/auth_controller.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return AfiyahPage(
      title: 'Profile and privacy',
      child: Column(
        children: [
          const CircleAvatar(
            radius: 34,
            child: Icon(Icons.person_outline, size: 36),
          ),
          const SizedBox(height: AfiyahSpacing.md),
          const Text('Verified sister account'),
          const SizedBox(height: AfiyahSpacing.lg),
          const Card(
            child: Column(
              children: [
                ListTile(
                  leading: Icon(Icons.security_outlined),
                  title: Text('Security'),
                  subtitle: Text('Biometric re-entry and active sessions'),
                ),
                Divider(height: 1),
                ListTile(
                  leading: Icon(Icons.privacy_tip_outlined),
                  title: Text('Privacy choices'),
                  subtitle: Text('Consent, export and deletion requests'),
                ),
                Divider(height: 1),
                ListTile(
                  leading: Icon(Icons.gavel_outlined),
                  title: Text('Disclosures'),
                  subtitle: Text('AI, medical, Shariah and financial boundaries'),
                ),
              ],
            ),
          ),
          const SizedBox(height: AfiyahSpacing.lg),
          OutlinedButton.icon(
            onPressed: () async {
              await ref.read(authControllerProvider.notifier).signOut();
              if (context.mounted) {
                context.go('/login');
              }
            },
            icon: const Icon(Icons.logout),
            label: const Text('Sign out from this device'),
          ),
        ],
      ),
    );
  }
}
