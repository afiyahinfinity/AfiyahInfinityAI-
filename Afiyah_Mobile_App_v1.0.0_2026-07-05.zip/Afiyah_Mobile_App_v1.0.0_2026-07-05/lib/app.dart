import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/routing/app_router.dart';
import 'core/theme/afiyah_theme.dart';

class AfiyahApp extends ConsumerWidget {
  const AfiyahApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(appRouterProvider);

    return MaterialApp.router(
      title: 'Afiyah Infinity',
      debugShowCheckedModeBanner: false,
      theme: AfiyahTheme.light,
      darkTheme: AfiyahTheme.dark,
      themeMode: ThemeMode.system,
      routerConfig: router,
    );
  }
}
