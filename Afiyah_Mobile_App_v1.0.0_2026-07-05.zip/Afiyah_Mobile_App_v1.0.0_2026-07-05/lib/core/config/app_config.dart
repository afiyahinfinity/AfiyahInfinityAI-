import 'package:flutter_riverpod/flutter_riverpod.dart';

final appConfigProvider = Provider<AppConfig>(
  (ref) => throw StateError('AppConfig must be overridden during bootstrap.'),
);

class AppConfig {
  const AppConfig({
    required this.environment,
    required this.apiBaseUrl,
    required this.webBaseUrl,
    required this.mockMode,
    required this.enableBiometrics,
    required this.enableScreenProtection,
    required this.sentryDsn,
  });

  final String environment;
  final Uri apiBaseUrl;
  final Uri webBaseUrl;
  final bool mockMode;
  final bool enableBiometrics;
  final bool enableScreenProtection;
  final String? sentryDsn;

  bool get isProduction => environment == 'production';

  factory AppConfig.fromEnvironment() {
    const environment = String.fromEnvironment(
      'AFIYAH_ENV',
      defaultValue: 'staging',
    );
    const apiBaseUrl = String.fromEnvironment(
      'AFIYAH_API_BASE_URL',
      defaultValue: 'https://staging-api.afiyahinfinityai.com',
    );
    const webBaseUrl = String.fromEnvironment(
      'AFIYAH_WEB_BASE_URL',
      defaultValue: 'https://staging.afiyahinfinityai.com',
    );
    const mockMode = bool.fromEnvironment(
      'AFIYAH_MOCK_MODE',
      defaultValue: true,
    );
    const enableBiometrics = bool.fromEnvironment(
      'AFIYAH_ENABLE_BIOMETRICS',
      defaultValue: false,
    );
    const enableScreenProtection = bool.fromEnvironment(
      'AFIYAH_ENABLE_SCREEN_PROTECTION',
      defaultValue: false,
    );
    const sentryDsn = String.fromEnvironment('AFIYAH_SENTRY_DSN');

    final apiUri = Uri.tryParse(apiBaseUrl);
    final webUri = Uri.tryParse(webBaseUrl);
    if (apiUri == null || !apiUri.hasScheme || !apiUri.hasAuthority) {
      throw StateError('AFIYAH_API_BASE_URL must be an absolute URL.');
    }
    if (webUri == null || !webUri.hasScheme || !webUri.hasAuthority) {
      throw StateError('AFIYAH_WEB_BASE_URL must be an absolute URL.');
    }
    if (environment == 'production' && mockMode) {
      throw StateError('Mock mode must be disabled in production.');
    }

    return AppConfig(
      environment: environment,
      apiBaseUrl: apiUri,
      webBaseUrl: webUri,
      mockMode: mockMode,
      enableBiometrics: enableBiometrics,
      enableScreenProtection: enableScreenProtection,
      sentryDsn: sentryDsn.isEmpty ? null : sentryDsn,
    );
  }
}
