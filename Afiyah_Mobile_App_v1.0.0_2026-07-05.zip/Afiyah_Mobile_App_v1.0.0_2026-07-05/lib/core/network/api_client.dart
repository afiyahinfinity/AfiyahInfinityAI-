import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../config/app_config.dart';
import '../security/secure_session_store.dart';
import 'api_exception.dart';

final apiClientProvider = Provider<ApiClient>((ref) {
  final config = ref.watch(appConfigProvider);
  final sessionStore = ref.watch(secureSessionStoreProvider);
  return ApiClient(
    baseUrl: config.apiBaseUrl,
    sessionStore: sessionStore,
  );
});

class ApiClient {
  ApiClient({
    required Uri baseUrl,
    required SecureSessionStore sessionStore,
    Dio? dio,
  })  : _sessionStore = sessionStore,
        _dio = dio ??
            Dio(
              BaseOptions(
                baseUrl: baseUrl.toString(),
                connectTimeout: const Duration(seconds: 10),
                receiveTimeout: const Duration(seconds: 20),
                sendTimeout: const Duration(seconds: 20),
                headers: const {
                  'Accept': 'application/json',
                  'Content-Type': 'application/json',
                  'X-Afiyah-Client': 'mobile',
                },
              ),
            ) {
    _dio.interceptors.add(
      QueuedInterceptorsWrapper(
        onRequest: (options, handler) async {
          final token = await _sessionStore.readAccessToken();
          if (token != null && token.isNotEmpty) {
            options.headers['Authorization'] = 'Bearer $token';
          }
          options.headers.putIfAbsent(
            'X-Request-Id',
            () => _requestId(),
          );
          handler.next(options);
        },
      ),
    );
  }

  final Dio _dio;
  final SecureSessionStore _sessionStore;

  Future<Map<String, Object?>> getJson(String path) async {
    try {
      final response = await _dio.get<Map<String, Object?>>(path);
      return response.data ?? const {};
    } on DioException catch (error) {
      throw _mapError(error);
    }
  }

  Future<Map<String, Object?>> postJson(
    String path, {
    required Map<String, Object?> body,
    String? idempotencyKey,
  }) async {
    try {
      final response = await _dio.post<Map<String, Object?>>(
        path,
        data: body,
        options: Options(
          headers: {
            if (idempotencyKey != null) 'Idempotency-Key': idempotencyKey,
          },
        ),
      );
      return response.data ?? const {};
    } on DioException catch (error) {
      throw _mapError(error);
    }
  }

  ApiException _mapError(DioException error) {
    final data = error.response?.data;
    String? code;
    String? serverMessage;
    if (data is Map<String, Object?>) {
      code = data['code'] as String?;
      serverMessage = data['message'] as String?;
    }
    return ApiException(
      statusCode: error.response?.statusCode,
      code: code,
      message: serverMessage ?? 'The service is temporarily unavailable.',
    );
  }

  static String _requestId() {
    final now = DateTime.now().toUtc().microsecondsSinceEpoch;
    return 'mobile-$now';
  }
}
