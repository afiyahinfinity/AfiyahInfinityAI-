import 'package:local_auth/local_auth.dart';

class BiometricGate {
  BiometricGate({LocalAuthentication? authentication})
      : _authentication = authentication ?? LocalAuthentication();

  final LocalAuthentication _authentication;

  Future<bool> canAuthenticate() async {
    final supported = await _authentication.isDeviceSupported();
    final enrolled = await _authentication.getAvailableBiometrics();
    return supported && enrolled.isNotEmpty;
  }

  Future<bool> unlock() async {
    if (!await canAuthenticate()) {
      return false;
    }
    try {
      return await _authentication.authenticate(
        localizedReason: 'Unlock your Afiyah account',
        biometricOnly: false,
        persistAcrossBackgrounding: true,
      );
    } on LocalAuthException {
      return false;
    }
  }
}
