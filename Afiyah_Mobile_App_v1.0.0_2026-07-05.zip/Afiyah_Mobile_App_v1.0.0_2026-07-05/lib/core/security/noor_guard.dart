enum NoorGuardDecision {
  allow,
  blockSensitiveData,
  blockCrisis,
  requireLicensedPartner,
}

class NoorGuardResult {
  const NoorGuardResult({
    required this.decision,
    required this.safeMessage,
  });

  final NoorGuardDecision decision;
  final String safeMessage;

  bool get allowed => decision == NoorGuardDecision.allow;
}

class NoorGuard {
  const NoorGuard();

  static final _sensitivePatterns = <RegExp>[
    RegExp(r'\b\d{13,19}\b'),
    RegExp(r'\b[A-Z]{1,2}\d{6,9}\b', caseSensitive: false),
    RegExp(r'\b(?:cvv|cvc|pin)\s*[:=]?\s*\d{3,6}\b', caseSensitive: false),
    RegExp(r'\b(?:password|passcode|otp)\s*[:=]', caseSensitive: false),
  ];

  static final _crisisPatterns = <RegExp>[
    RegExp(r'\bkill myself\b', caseSensitive: false),
    RegExp(r'\bsuicide\b', caseSensitive: false),
    RegExp(r'\bself[- ]?harm\b', caseSensitive: false),
    RegExp(r'\bdo not want to live\b', caseSensitive: false),
  ];

  static final _regulatedPatterns = <RegExp>[
    RegExp(r'\btell me exactly what to buy\b', caseSensitive: false),
    RegExp(r'\bguaranteed return\b', caseSensitive: false),
    RegExp(r'\bplace the trade\b', caseSensitive: false),
    RegExp(r'\binvest all my money\b', caseSensitive: false),
  ];

  NoorGuardResult evaluate(String message) {
    final normalized = message.trim();
    if (normalized.isEmpty) {
      return const NoorGuardResult(
        decision: NoorGuardDecision.allow,
        safeMessage: '',
      );
    }

    if (_sensitivePatterns.any((pattern) => pattern.hasMatch(normalized))) {
      return const NoorGuardResult(
        decision: NoorGuardDecision.blockSensitiveData,
        safeMessage:
            'Please remove passwords, one-time codes, card numbers or identity details before continuing.',
      );
    }

    if (_crisisPatterns.any((pattern) => pattern.hasMatch(normalized))) {
      return const NoorGuardResult(
        decision: NoorGuardDecision.blockCrisis,
        safeMessage:
            'You deserve immediate human support. Contact local emergency services or a verified crisis resource now. Noor will not generate a model response to this message.',
      );
    }

    if (_regulatedPatterns.any((pattern) => pattern.hasMatch(normalized))) {
      return const NoorGuardResult(
        decision: NoorGuardDecision.requireLicensedPartner,
        safeMessage:
            'Noor can explain concepts and help you prepare questions, but cannot issue personalized investment instructions or execute a transaction. Please consult a licensed partner.',
      );
    }

    return NoorGuardResult(
      decision: NoorGuardDecision.allow,
      safeMessage: normalized,
    );
  }
}
