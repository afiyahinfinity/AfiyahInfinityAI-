import 'package:flutter/material.dart';

import '../theme/afiyah_spacing.dart';

class AfiyahPage extends StatelessWidget {
  const AfiyahPage({
    required this.title,
    required this.child,
    this.actions,
    this.bottomNavigationBar,
    super.key,
  });

  final String title;
  final Widget child;
  final List<Widget>? actions;
  final Widget? bottomNavigationBar;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: actions,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AfiyahSpacing.md),
          child: child,
        ),
      ),
      bottomNavigationBar: bottomNavigationBar,
    );
  }
}
