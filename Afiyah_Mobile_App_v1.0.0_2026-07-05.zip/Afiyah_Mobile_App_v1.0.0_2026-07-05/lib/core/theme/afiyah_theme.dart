import 'package:flutter/material.dart';

import 'afiyah_colors.dart';

abstract final class AfiyahTheme {
  static ThemeData get light {
    final scheme = ColorScheme.fromSeed(
      seedColor: AfiyahColors.deepGreen,
      brightness: Brightness.light,
      primary: AfiyahColors.deepGreen,
      secondary: AfiyahColors.gold,
      surface: AfiyahColors.ivory,
      error: AfiyahColors.danger,
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: AfiyahColors.ivory,
      textTheme: _textTheme(Brightness.light),
      cardTheme: const CardThemeData(
        margin: EdgeInsets.zero,
        elevation: 0,
      ),
      inputDecorationTheme: const InputDecorationTheme(
        border: OutlineInputBorder(),
        filled: true,
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
    );
  }

  static ThemeData get dark {
    final scheme = ColorScheme.fromSeed(
      seedColor: AfiyahColors.gold,
      brightness: Brightness.dark,
      primary: AfiyahColors.gold,
      secondary: AfiyahColors.deepGreen,
      surface: AfiyahColors.charcoal,
      error: const Color(0xFFFFB4AB),
    );

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: AfiyahColors.charcoal,
      textTheme: _textTheme(Brightness.dark),
      inputDecorationTheme: const InputDecorationTheme(
        border: OutlineInputBorder(),
        filled: true,
      ),
    );
  }

  static TextTheme _textTheme(Brightness brightness) {
    final base = brightness == Brightness.light
        ? ThemeData.light().textTheme
        : ThemeData.dark().textTheme;
    return base.copyWith(
      headlineLarge: base.headlineLarge?.copyWith(
        fontWeight: FontWeight.w700,
        letterSpacing: -0.5,
      ),
      headlineMedium: base.headlineMedium?.copyWith(
        fontWeight: FontWeight.w700,
      ),
      titleLarge: base.titleLarge?.copyWith(fontWeight: FontWeight.w700),
      bodyLarge: base.bodyLarge?.copyWith(height: 1.45),
      bodyMedium: base.bodyMedium?.copyWith(height: 1.45),
    );
  }
}
