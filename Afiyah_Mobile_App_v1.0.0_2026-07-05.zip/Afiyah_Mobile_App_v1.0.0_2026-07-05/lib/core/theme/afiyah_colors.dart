import 'package:flutter/material.dart';

abstract final class AfiyahColors {
  static const deepGreen = Color(0xFF003629);
  static const teal = Color(0xFF0C383F);
  static const gold = Color(0xFFAD8633);
  static const ivory = Color(0xFFF8F3E9);
  static const charcoal = Color(0xFF181715);
  static const white = Color(0xFFFFFFFF);
  static const success = Color(0xFF2E7D32);
  static const warning = Color(0xFF8A5A00);
  static const danger = Color(0xFFB3261E);
  static const info = Color(0xFF245C73);
  static const outline = Color(0xFFB9B5AA);
}
