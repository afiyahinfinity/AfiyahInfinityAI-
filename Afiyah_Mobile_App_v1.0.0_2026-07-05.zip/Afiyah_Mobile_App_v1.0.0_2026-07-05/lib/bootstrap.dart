import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';
import 'core/config/app_config.dart';
import 'core/security/secure_session_store.dart';

Future<void> bootstrap() async {
  final config = AppConfig.fromEnvironment();
  final sessionStore = SecureSessionStore();

  runApp(
    ProviderScope(
      overrides: [
        appConfigProvider.overrideWithValue(config),
        secureSessionStoreProvider.overrideWithValue(sessionStore),
      ],
      child: const AfiyahApp(),
    ),
  );
}
