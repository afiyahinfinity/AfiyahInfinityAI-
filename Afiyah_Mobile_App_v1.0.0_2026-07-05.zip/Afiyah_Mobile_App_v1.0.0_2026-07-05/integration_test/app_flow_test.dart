import 'package:afiyah_mobile_app/app.dart';
import 'package:afiyah_mobile_app/core/config/app_config.dart';
import 'package:afiyah_mobile_app/core/security/secure_session_store.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('launches the onboarding entry point', (tester) async {
    await tester.pumpWidget(
      ProviderScope(
        overrides: [
          appConfigProvider.overrideWithValue(
            AppConfig(
              environment: 'test',
              apiBaseUrl: Uri.parse('https://example.invalid'),
              webBaseUrl: Uri.parse('https://example.invalid'),
              mockMode: true,
              enableBiometrics: false,
              enableScreenProtection: false,
              sentryDsn: null,
            ),
          ),
          secureSessionStoreProvider.overrideWithValue(_FakeSecureSessionStore()),
        ],
        child: const AfiyahApp(),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('Begin with niyyah'), findsOneWidget);
  });
}


class _FakeSecureSessionStore extends SecureSessionStore {
  @override
  Future<bool> hasSession() async => false;

  @override
  Future<String?> readUserId() async => null;

  @override
  Future<String?> readAccessToken() async => null;
}
