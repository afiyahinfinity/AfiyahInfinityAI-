# API integration contract

## Base URL

Configured at compile time with `AFIYAH_API_BASE_URL`. Use separate staging and production domains.

## Common headers

- `Authorization: Bearer <short-lived-user-token>`
- `Content-Type: application/json`
- `X-Afiyah-Client: mobile`
- `X-Request-Id: mobile-<unique-value>`
- `Idempotency-Key` for POST requests that can create durable state

## Expected endpoints

| Method | Route | Purpose |
|---|---|---|
| POST | `/v1/auth/login` | Exchange credentials for user-scoped tokens |
| POST | `/v1/auth/refresh` | Rotate refresh and access tokens |
| GET | `/v1/portfolio/summary` | View-only portfolio summary |
| GET | `/v1/insights` | Approved educational insights |
| POST | `/v1/noor/message` | Session-owned Noor message orchestration |
| POST | `/v1/privacy/export` | Start user data export |
| POST | `/v1/privacy/delete-request` | Start deletion workflow |

These routes are integration assumptions and must be reconciled with the authoritative backend OpenAPI document before production.

## Noor request

```json
{
  "session_id": "server-issued-session-id",
  "message": "Explain diversification in simple terms",
  "channel": "mobile"
}
```

The client must never invent or reuse another user's session identifier. Production should obtain the session ID from a user-scoped server endpoint.

## Error shape

```json
{
  "code": "NOOR_SESSION_FORBIDDEN",
  "message": "The request could not be completed.",
  "request_id": "..."
}
```

Server messages shown to users must be non-sensitive. Detailed causes belong in protected logs.
