# Mobile architecture

## Layers

1. **Presentation** — Flutter widgets, routing and accessibility semantics.
2. **Application** — Riverpod controllers coordinating user intent and state.
3. **Domain** — immutable models and deterministic safety decisions.
4. **Data** — repositories and a single Dio network boundary.
5. **Platform security** — secure storage, local authentication and future device attestation.

## Trust boundaries

- The mobile app is an untrusted client.
- Authorization, RLS, Noor session ownership, model access, audit logging and consequential action approval remain on the server.
- The app never receives a Supabase service-role key, model-provider key or email-provider key.
- Local Noor Guard is defense-in-depth for immediate user feedback. The server must repeat every control.

## State management

Riverpod providers expose configuration, API clients, repositories and feature controllers. Feature code does not instantiate privileged services directly.

## Navigation

GoRouter provides public onboarding routes and an authenticated indexed shell for Home, Portfolio, Insights, Noor and Profile. Redirects are based on restored secure-session state.

## Data handling

- Short-lived access and refresh tokens: platform secure storage.
- Non-sensitive UI preferences: future local preference store.
- Portfolio and insights: fetched on demand; no persistent offline cache in v1.
- Raw ID documents, cycle records and detailed health data: never cached by this package.

## Failure model

The application fails closed for authorization and sensitive operations, but fails gracefully for optional AI and insight content. A Noor outage must not block core account access.
