# Mobile security baseline

## Mandatory controls

- TLS only; production API and web URLs must use HTTPS.
- Short-lived user tokens in platform secure storage.
- Refresh-token rotation and server-side revocation.
- No privileged API keys or database credentials in Dart defines, assets or binaries.
- Local logs must exclude tokens, prompts, portfolio values, identity data and health data.
- Noor requests pass through local pre-flight checks and authoritative server checks.
- Consequential actions require server-side human approval and atomic execution.
- Session ownership is never inferred from a client-provided identifier alone.

## Biometrics

Biometrics may unlock an existing local session after server authentication. They do not prove identity to the backend and must not bypass expiry, revocation or re-authentication requirements.

## Device attestation

Before public launch, select and document an attestation mechanism such as Play Integrity and Apple App Attest/DeviceCheck. The backend must validate attestation for risk-sensitive endpoints. Do not rely on attestation as the only fraud control.

## Rooted or jailbroken devices

Treat device-risk signals as one input. Do not silently block crisis support or account recovery. For high-risk actions, require re-authentication and server review.

## Certificate pinning

Not enabled in this scaffold. Pinning can cause widespread outages during certificate rotation. Implement only with backup pins, rotation procedures and monitored emergency disablement.

## Screen protection

Sensitive screens may use native secure-window controls, but this requires explicit UX, accessibility and support testing. Do not assume screenshot blocking is comprehensive.

## Secret scan

Run `python3 scripts/validate_package.py` and repository secret scanning before every release.
