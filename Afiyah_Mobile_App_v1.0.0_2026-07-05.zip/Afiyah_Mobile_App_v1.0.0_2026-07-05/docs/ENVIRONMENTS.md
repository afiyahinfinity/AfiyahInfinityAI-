# Environments

## Local/mock

```bash
flutter run \
  --dart-define=AFIYAH_ENV=local \
  --dart-define=AFIYAH_API_BASE_URL=http://10.0.2.2:3000 \
  --dart-define=AFIYAH_WEB_BASE_URL=http://10.0.2.2:3000 \
  --dart-define=AFIYAH_MOCK_MODE=true
```

## Staging

Use dedicated staging API, Supabase project, test email domain and dummy identities only. Never upload real ID documents to staging.

## Production

```bash
flutter build appbundle --release \
  --dart-define=AFIYAH_ENV=production \
  --dart-define=AFIYAH_API_BASE_URL=https://api.afiyahinfinityai.com \
  --dart-define=AFIYAH_WEB_BASE_URL=https://afiyahinfinityai.com \
  --dart-define=AFIYAH_MOCK_MODE=false
```

Do not pass secrets through `--dart-define`; values are recoverable from a compiled client.
