# Offline behavior

## Available offline

- Static onboarding and disclosure copy
- Previously loaded non-sensitive navigation state for the current process
- Draft text only while the app remains open

## Not available offline

- Authentication refresh
- Portfolio balances
- Personalized insights
- Noor responses
- Consent changes
- Data export or deletion requests

## Rules

- Do not persist Noor prompts, raw financial values, identity documents or health information for offline use.
- Never queue a consequential or regulated action for automatic replay.
- Idempotent, low-risk requests may be manually retried after reconnecting.
- Display the last-updated timestamp and never present cached values as live.
