# Store listing checklist

- Approved app name, subtitle and screenshots
- Accurate education/non-advisory positioning
- Privacy Policy and Terms URLs live
- Account deletion path documented and functional
- Support email and support URL monitored
- Age rating and target audience confirmed
- Data safety/App Privacy declarations reconciled with actual SDKs
- AI-generated content disclosure included where required
- No claim of guaranteed returns, regulatory approval or autonomous Shariah authority
- Review account uses synthetic data only
- Crisis resources are verified for each supported launch market
