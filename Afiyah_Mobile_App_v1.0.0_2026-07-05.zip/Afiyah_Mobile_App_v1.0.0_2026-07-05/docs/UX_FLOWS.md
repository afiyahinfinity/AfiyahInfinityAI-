# Mobile UX flows

## New sister

Welcome → consent and disclosure → account creation/sign-in → verification status → Niyyah onboarding → dashboard.

## Returning sister

Launch → secure-session restore → optional biometric re-entry → dashboard.

## Noor

Open Noor → read trust boundary → type message → local pre-flight guard → server policy and model orchestration → educational response or human-support route.

## Portfolio

Open overview → authenticate if risk threshold requires → view partner-provided values → inspect Shariah review status → follow licensed-partner link outside the transaction boundary.

## Privacy

Profile → privacy choices → view consents → request export or deletion → re-authenticate → receive server confirmation.

## Crisis

Local keyword trigger → no model call → human-written message → verified local support resources → optional protected escalation event. The mobile package does not hard-code unverified helplines.
