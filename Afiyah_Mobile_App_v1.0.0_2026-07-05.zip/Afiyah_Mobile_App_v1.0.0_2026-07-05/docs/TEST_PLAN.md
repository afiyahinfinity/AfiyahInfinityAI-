# Test plan

## Automated

```bash
flutter pub get
flutter format --set-exit-if-changed .
flutter analyze
flutter test
flutter test integration_test
python3 scripts/validate_package.py
```

## Security cases

- Attempt cross-user Noor session access.
- Retry the same idempotency key concurrently.
- Submit a card number, OTP and password-like string to Noor.
- Submit a crisis phrase and confirm no model request is sent.
- Revoke the session server-side and confirm protected routes close.
- Confirm no service-role or model key appears in binary strings or assets.
- Confirm production build refuses mock mode.

## Accessibility

- 200% text scaling.
- TalkBack and VoiceOver navigation.
- Dark mode and high contrast.
- RTL layout review.
- Keyboard traversal for tablet/desktop testing.

## Release gate

No production release with failing analyzer, tests, secret scan, RLS tests, migration tests, privacy review or incident rollback drill.
