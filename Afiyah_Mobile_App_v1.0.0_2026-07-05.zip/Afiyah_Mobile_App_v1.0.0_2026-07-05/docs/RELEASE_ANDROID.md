# Android release checklist

1. Generate the Android shell using the approved Flutter 3.44 stable SDK.
2. Set application ID, minimum SDK and target SDK according to current Play requirements.
3. Configure release signing in a protected CI secret store; never commit keystores or passwords.
4. Enable Play App Signing.
5. Configure network security, deep links and verified app links.
6. Add Play Integrity only after backend verification is available.
7. Produce an Android App Bundle with obfuscation and split debug information.
8. Upload to internal testing first.
9. Complete Data safety, financial-features and health-data declarations accurately.
10. Run staged rollout with crash, auth and Noor safety monitoring.

Example build:

```bash
flutter build appbundle --release \
  --obfuscate \
  --split-debug-info=build/debug-symbols/android \
  --dart-define=AFIYAH_ENV=production \
  --dart-define=AFIYAH_API_BASE_URL=https://api.afiyahinfinityai.com \
  --dart-define=AFIYAH_WEB_BASE_URL=https://afiyahinfinityai.com \
  --dart-define=AFIYAH_MOCK_MODE=false
```
