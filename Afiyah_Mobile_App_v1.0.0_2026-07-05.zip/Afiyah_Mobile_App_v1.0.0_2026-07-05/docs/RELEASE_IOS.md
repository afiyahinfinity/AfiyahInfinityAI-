# iOS release checklist

1. Generate the iOS shell on macOS using the approved Flutter 3.44 stable SDK.
2. Set the bundle identifier and signing team.
3. Configure universal links, associated domains and privacy usage strings.
4. Store certificates and App Store Connect keys in protected CI secrets.
5. Add App Attest/DeviceCheck only after backend verification is ready.
6. Archive with obfuscation and split debug information.
7. Distribute through TestFlight first.
8. Complete App Privacy, financial-services and health-data declarations accurately.
9. Verify account deletion access and reviewer test credentials.
10. Use phased release with monitoring and a rollback decision owner.

Example build:

```bash
flutter build ipa --release \
  --obfuscate \
  --split-debug-info=build/debug-symbols/ios \
  --dart-define=AFIYAH_ENV=production \
  --dart-define=AFIYAH_API_BASE_URL=https://api.afiyahinfinityai.com \
  --dart-define=AFIYAH_WEB_BASE_URL=https://afiyahinfinityai.com \
  --dart-define=AFIYAH_MOCK_MODE=false
```
