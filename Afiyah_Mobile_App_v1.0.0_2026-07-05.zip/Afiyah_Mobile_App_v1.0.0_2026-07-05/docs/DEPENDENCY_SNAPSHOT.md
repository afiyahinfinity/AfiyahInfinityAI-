# Dependency snapshot — 5 July 2026

- Flutter stable: 3.44
- `flutter_riverpod`: 3.3.2
- `go_router`: 17.3.0
- `dio`: 5.10.0
- `flutter_secure_storage`: 10.3.1
- `local_auth`: 3.0.1
- `flutter_lints`: 6.0.0

Re-run dependency review, changelog review and `flutter pub outdated` before each release. Do not automatically accept major-version upgrades in production.
