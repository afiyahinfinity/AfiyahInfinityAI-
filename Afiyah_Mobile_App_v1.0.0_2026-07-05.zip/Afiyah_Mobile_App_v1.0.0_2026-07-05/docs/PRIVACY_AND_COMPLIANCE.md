# Privacy and compliance boundary

## Product position

Afiyah Mobile is an education, wellness and account-access interface. It must not imply custody, execution, guaranteed returns, personalized regulated advice or scholar/medical authority.

## Data minimization

Collect only fields required for the active feature. Do not collect cycle or health data by default. Optional sensitive features require separate, specific and revocable consent.

## AI disclosure

Noor may produce incomplete or incorrect content. The UI must identify AI-generated material, state the relevant professional boundary and provide a human escalation path.

## Financial boundary

Portfolio values are view-only and supplied by licensed institutions or approved partners. Any regulated recommendation, suitability assessment, order placement, custody or payment activity must occur through an authorized service with its own disclosures and controls.

## Islamic content

Religious content must come from an approved knowledge base or a reviewed source. The model must not fabricate Qur'anic verses, hadith, fatwa or scholar attribution.

## Required approvals

Privacy Policy, Terms, AI disclosure, medical disclaimer, Shariah disclaimer, crisis-resource list, retention schedule, subprocessor register and app-store privacy declarations require formal approval before production.
