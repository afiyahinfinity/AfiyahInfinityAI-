# Figma handoff

The Flutter scaffold maps to the Afiyah Design System tokens and component inventory. A native `.fig` file is not contained in this package.

Required Figma mobile pages:

1. Foundations and tokens
2. Mobile components and states
3. Onboarding and consent
4. Authentication and verification
5. Dashboard and check-in
6. Portfolio and insights
7. Noor conversation and safety states
8. Profile, privacy and deletion
9. Dark mode and RTL
10. Developer annotations

Minimum component states include default, pressed, focused, disabled, loading, error, success, pending human review and offline.
