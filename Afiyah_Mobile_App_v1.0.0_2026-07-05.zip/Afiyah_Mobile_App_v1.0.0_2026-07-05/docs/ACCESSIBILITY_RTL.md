# Accessibility and RTL

- Minimum touch target: 48 × 48 logical pixels.
- Support dynamic text scaling without clipped critical actions.
- Provide semantic labels for icons and trust-state indicators.
- Never communicate approval, risk or error by color alone.
- Respect system contrast and reduced-motion preferences where practical.
- Test TalkBack and VoiceOver for onboarding, login, navigation, Noor and disclosures.
- Use `Directionality` and logical start/end padding; avoid hard-coded left/right behavior for directional content.
- Arabic and Bangla translations require human review, especially legal, financial, medical and Shariah terminology.
- System fonts are used in this package; no font binaries are included.
