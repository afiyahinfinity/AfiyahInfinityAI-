# Threat model summary

| Threat | Primary controls | Residual work |
|---|---|---|
| Stolen device | Secure storage, expiry, optional biometric gate | Remote session revocation UX |
| Token theft | Short lifetime, rotation, TLS, no logs | Backend anomaly detection |
| Session ID substitution | Server ownership checks, RLS | Penetration test |
| Duplicate Noor action | Idempotency, atomic server RPC | Concurrency test in staging |
| Prompt injection | Server prompt boundary, allowlisted tools | Red-team suite |
| Sensitive-data disclosure | Local/server detection, prompt minimization | DLP tuning and monitoring |
| Malicious client | Treat app as untrusted, server authorization | Device attestation |
| Supply-chain compromise | Lockfile, CI, dependency review | SBOM and signing provenance |
| Misleading financial content | Non-advisory policy, licensed referral | Compliance review sampling |
| Fabricated Islamic content | Approved KB and human governance | Scholar QA process |
