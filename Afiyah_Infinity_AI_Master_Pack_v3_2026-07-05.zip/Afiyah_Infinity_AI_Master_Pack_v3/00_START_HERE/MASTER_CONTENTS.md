# Master contents

- `00_START_HERE/` — release notes, manifest and navigation.
- `01_SOURCE_ARCHIVES/` — original source ZIPs, secured overlay ZIP and design-system ZIP.
- `02_CONSOLIDATED_CODE/` — reviewed source, baseline and Stage 1 remediation.
- `03_AUDIT_AND_REMEDIATION/` — technical audit and security instructions.
- `04_DEPLOYMENT_AND_GITHUB/` — repository and hosting runbooks.
- `05_ENVIRONMENT_KEYS/` — safe placeholder templates and secret register.
- `06_FIGMA_AND_DESIGN/` — full Afiyah Design System v1.0.0 and Figma handoff status.
- `07_CHECKSUMS/` — integrity records.
- `08_CHAT_DELIVERABLES/` — key documents produced during the review.
- `09_REPOSITORY_OVERLAY_STAGE1/` — complete extracted repository overlay package.

## 10_AI_SERVICES

Production-oriented AI architecture, API contracts, Noor safety middleware, model routing, governance migration, tests and deployment documentation.
