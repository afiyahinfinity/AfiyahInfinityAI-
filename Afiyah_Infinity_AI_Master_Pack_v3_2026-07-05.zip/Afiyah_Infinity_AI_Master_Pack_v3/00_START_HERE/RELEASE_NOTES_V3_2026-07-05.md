# Master Pack v3 Release Notes

- Added Afiyah AI Services v1.0.0.
- Added Noor Guard deterministic safety and compliance middleware.
- Added OpenAPI 3.1 and JSON Schema contracts.
- Added model and prompt governance controls.
- Added AI-services control-plane migration 013.
- Added Next.js server boundary and secure Supabase Edge Functions.
- Added unit tests, validation report and incident-response runbook.
