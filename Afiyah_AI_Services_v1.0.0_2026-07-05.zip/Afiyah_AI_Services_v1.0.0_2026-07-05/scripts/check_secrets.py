from pathlib import Path
import re, sys
ROOT = Path(__file__).resolve().parents[1]
patterns = {
    "private key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "generic bearer": re.compile(r"Bearer\s+[A-Za-z0-9._~+/=-]{24,}"),
    "OpenAI-like key": re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b"),
    "Stripe live key": re.compile(r"\b(?:sk|pk)_live_[A-Za-z0-9]{12,}\b"),
    "JWT": re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"),
}
ignore = {'.zip', '.png', '.jpg', '.jpeg', '.gif', '.webp', '.pyc'}
hits=[]
for p in ROOT.rglob('*'):
    if not p.is_file() or p.suffix.lower() in ignore or '__pycache__' in p.parts: continue
    text=p.read_text(errors='ignore')
    for name,pat in patterns.items():
        for m in pat.finditer(text):
            # Template placeholders are intentionally safe.
            if 'replace_' in m.group(0).lower() or 'your_' in m.group(0).lower(): continue
            hits.append((p.relative_to(ROOT), name, m.group(0)[:40]))
if hits:
    for hit in hits: print('SECRET_SCAN_FAIL', *hit)
    sys.exit(1)
print('Secret scan passed')
