from pathlib import Path
import json, yaml, sys, re
from jsonschema import Draft202012Validator
ROOT = Path(__file__).resolve().parents[1]
required = [
  'README.md','docs/ARCHITECTURE.md','openapi/afiyah-ai-services.openapi.yaml',
  'supabase/functions/noor-guard/index.ts','supabase/functions/noor-agent/index.ts',
  'supabase/functions/agent-execute/index.ts','supabase/migrations/013_ai_services_control_plane.sql',
  'nextjs/app/api/noor/route.ts'
]
missing=[p for p in required if not (ROOT/p).exists()]
if missing:
  print('Missing:', *missing, sep='\n- '); sys.exit(1)
for p in ROOT.rglob('*.json'):
  with p.open() as f: json.load(f)
for p in ROOT.rglob('*.yaml'):
  with p.open() as f: yaml.safe_load(f)
for p in ROOT.glob('schemas/*.json'):
  schema=json.loads(p.read_text()); Draft202012Validator.check_schema(schema)
sql=(ROOT/'supabase/migrations/013_ai_services_control_plane.sql').read_text()
for token in ['security definer','set search_path','enable row level security','revoke all']:
  if token not in sql.lower(): raise SystemExit(f'SQL control missing: {token}')
print('Package validation passed')
