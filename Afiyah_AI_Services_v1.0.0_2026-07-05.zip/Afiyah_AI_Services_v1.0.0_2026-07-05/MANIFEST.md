# Afiyah AI Services Manifest

Files: 47

| File | Bytes | SHA-256 |
|---|---:|---|
| `.env.example` | 503 | `0548e5e75b9220c59b6b7171ae88fe8c734232d572cfcc59b3fe7aadd22ffb15` |
| `.gitignore` | 95 | `280fa878774ffc501d07d43f26061d7bdc1e07a1660753a5c24b793339ac4804` |
| `CHANGELOG.md` | 570 | `ff894e0529649b59fdd198172c73008d80270b257e2125e3a6c59fb8edf5de9d` |
| `README.md` | 4215 | `196ec8845686f985dd25db1ef5eb9c649ec0417f2d295d913afea7ef7775d8d3` |
| `VALIDATION_REPORT.md` | 1253 | `8573a6ebb4c190b316a6cd223b0d6ca9ca646b5ad99e7ec5f242110b72b1ded4` |
| `deno.json` | 236 | `fabaef1fd47278f4ac9105433197ac652cb426621333bbe8d1ad41cc3ec97819` |
| `docs/API_CONTRACTS.md` | 1631 | `430e53d9f75b32aedcb47217f20489ac10496be319739bff137258b490fb9651` |
| `docs/ARCHITECTURE.md` | 3818 | `c18618b008ec48b449a899f6361b40d6a7739080c62269d608e37fee39f5576e` |
| `docs/DEPLOYMENT.md` | 2838 | `329e61c2997e1a1274f40b57bab70e88b61d2372dc46f3ff25ed66a01f2bf99a` |
| `docs/INCIDENT_RESPONSE.md` | 1309 | `698b64344a3edd8bab5c4d4c199d3c9e005ed02b511b3a3e5fde1f625b7c79e6` |
| `docs/MODEL_AND_PROMPT_GOVERNANCE.md` | 1667 | `e6b4a6cb2f2bcf4724500eaa58cbcad737ba3b0dce9a7f13e2febfd33dda3adf` |
| `docs/RELEASE_CHECKLIST.md` | 1126 | `9d4e6f9b52fbaaeddcd78287cbcd781964b2bdf3096d8b3984a655a7fd405a77` |
| `docs/SECURITY_AND_PRIVACY.md` | 2396 | `82def71587a0f7e6146b25833781b60266b72c6dc1aa7ec1c2044d90714859e7` |
| `docs/SERVICE_CATALOG.md` | 1653 | `372bc1742cc2403e67ee15f57b8bd7b221f1b4e7afad2b6dd87b6892d9e0ce16` |
| `examples/curl.md` | 584 | `2c41acc726df0e1f675af1d67efbe560f880424160af836d6237bb680ae46d62` |
| `nextjs/app/api/noor/route.ts` | 1927 | `77c009f9d37a4e070acec0a139179fd32555495da7e30d2aff6d729a00c54f6e` |
| `openapi/afiyah-ai-services.openapi.yaml` | 3174 | `dc5f7af7dcafc54a63412fee06c1f8bd340e9229d5c8ccc9d8b18c6653dc44bd` |
| `package.json` | 367 | `af33bc6341fbfb7fd6f7c5849f9d56d23601f7c52076c799fe00995f0d1aea96` |
| `schemas/noor-request.json` | 681 | `d0a398e824fe29c6ac6e11ba8cbfd8d7dd2812633caec33f2850c034fdfe6618` |
| `schemas/noor-response.json` | 1145 | `56dea79da3f83485dede9a6f0dd064ef2ae54587ba9e6e0e7b4a2a3a4f5c2410` |
| `schemas/proposed-action.json` | 736 | `c91e7f0aa50309b106c7f326f8c931910eb3e7dc72d1c38ab3bc0528d7d1280e` |
| `scripts/check_secrets.py` | 1120 | `a683ad945c5ead57f81302c0380723d4c9d3f0cfe311ac8a6c6132ed472c371f` |
| `scripts/validate_package.py` | 1119 | `98f6d0639ed2fc34ef8f294fea146b7df1a6c8bf496762c505fbd6a078a1f139` |
| `src/contracts.ts` | 738 | `15c7be705dd363edb258308b1a924f88f08e5f9880fa0d21385cd2495122577b` |
| `src/hash.ts` | 278 | `d5e18c776701e3b61df57a2ef6871a0f89e54c94ef9b6b33e11719a322e181b3` |
| `src/policy.ts` | 2407 | `c8fe1e12c173de2c2da1c3019c64a949060bdb14e6335744d394923e8d1e7423` |
| `src/validation.ts` | 4051 | `f35afecde3abb925fd9fb5d68075024cd8c0f01a5827f2463c2cab47fedcd52c` |
| `supabase/.env.functions.example` | 640 | `8ec593631f6f698a81cdb8ad26883210103e29892a6fd86ba62f0dd5082420b3` |
| `supabase/functions/_shared/contracts.ts` | 738 | `15c7be705dd363edb258308b1a924f88f08e5f9880fa0d21385cd2495122577b` |
| `supabase/functions/_shared/hash.ts` | 278 | `d5e18c776701e3b61df57a2ef6871a0f89e54c94ef9b6b33e11719a322e181b3` |
| `supabase/functions/_shared/http.ts` | 1686 | `3a57d884f552a29d6281a1182257b3b946e7205eee7d32bd6480b7675ba0bfef` |
| `supabase/functions/_shared/llm-gateway.ts` | 11326 | `4af7cd7149e164e1131e5a1ab2d77f46ecbd5faecbcf282303db00cd486ca42d` |
| `supabase/functions/_shared/policy.ts` | 2407 | `c8fe1e12c173de2c2da1c3019c64a949060bdb14e6335744d394923e8d1e7423` |
| `supabase/functions/_shared/validation.ts` | 4051 | `f35afecde3abb925fd9fb5d68075024cd8c0f01a5827f2463c2cab47fedcd52c` |
| `supabase/functions/agent-execute/index.ts` | 3334 | `f9fa0fdb5c9ce37e7d25e50aabccc7877e35d3b2bb1239a611dd292a8ef0eff4` |
| `supabase/functions/ai-identity-check/index.ts` | 5472 | `8225a5d594319c6756ee5b7fbfa6081a69a7c38603663ff3e674ead69952eedb` |
| `supabase/functions/barakah-baseline/index.ts` | 9493 | `9cef158f97382e039f32575e9bccb104c917bcda0d3b8b2cdeedcf7d85cef185` |
| `supabase/functions/coach-response/index.ts` | 9201 | `b5528b4667f4d21ea7bd4568b249442f993bb774a22d71eb7765181bf4b40542` |
| `supabase/functions/health/index.ts` | 670 | `aa82737668960f1a3ff06a4babe1c4889a487944ad336fbec4ce4af0646f05e2` |
| `supabase/functions/id-document-check/index.ts` | 6521 | `d35975a61fda3abb1a958e17f39d579e3a28b0d7571c4c01ff2ef4b9d6fa8baa` |
| `supabase/functions/noor-agent/index.ts` | 12630 | `1d5972db95b44a29d219c38bb57302633b5a639417e6a7d6bd8dfcf37410a5af` |
| `supabase/functions/noor-guard/index.ts` | 5844 | `25043facab11889b5eef0b8e1dcdf09c57ca4fea884e37c6a1f4edec550d9983` |
| `supabase/migrations/013_ai_services_control_plane.sql` | 7537 | `2e5c41d41c344fc27c436f1ce189451a071a52aeef8e07ee569169ad3934ea87` |
| `tests/contract-security.md` | 1066 | `154fc24fbc2341c632832d0a593401585888ca987aeea184abf4ee2e71dbe51e` |
| `tests/noor-security.test.ts` | 5780 | `dcfd7cdc311e2d0f2e3d3514f9ca2a7d21839481630851dbfd6856e90de6c99d` |
| `tests/policy.test.ts` | 813 | `59ee19b8dd9da752b87253174b8665f928697882ce6e9e55cbba282be1b88cdc` |
| `tests/validation.test.ts` | 867 | `be015c9b43c52091fafde5348c526d1086a7ad0de46fba64b5d78ba0bd47784a` |
