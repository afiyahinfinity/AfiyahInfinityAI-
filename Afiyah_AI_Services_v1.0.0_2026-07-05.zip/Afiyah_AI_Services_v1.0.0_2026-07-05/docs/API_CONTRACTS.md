# API Contracts

The canonical machine-readable contract is `openapi/afiyah-ai-services.openapi.yaml`.

## Authentication

All user-facing AI requests require:

```http
Authorization: Bearer <Supabase access token>
Content-Type: application/json
Idempotency-Key: <client-generated UUID>
```

The browser must never send a service-role key or model-provider key.

## Noor request

```json
{
  "message": "Help me make a monthly savings plan",
  "session_id": "optional-owned-session-uuid",
  "locale": "en",
  "client_timezone": "Asia/Dhaka"
}
```

Constraints:

- `message`: 1–4,000 characters;
- `session_id`: optional UUID owned by the caller;
- `locale`: supported locale code;
- `client_timezone`: IANA timezone.

## Noor response

```json
{
  "request_id": "uuid",
  "session_id": "uuid",
  "reply": "A bounded response",
  "actions": [
    {
      "id": "uuid",
      "action_type": "create_goal",
      "payload": {
        "dimension": "wealth",
        "goal_text": "Build a three-month emergency fund",
        "target_value": 12000
      },
      "proposal_reason": "You asked for a structured savings target.",
      "status": "proposed"
    }
  ],
  "safety": {
    "route": "standard",
    "human_review_required": false
  }
}
```

## Action decision

```json
{
  "action_id": "uuid",
  "decision": "approved"
}
```

Allowed decisions are `approved` and `declined`.

## Error envelope

```json
{
  "error": "machine_readable_code",
  "message": "Optional user-safe explanation",
  "request_id": "uuid"
}
```

Internal exception text, SQL errors, provider responses and stack traces must not be returned to clients.
