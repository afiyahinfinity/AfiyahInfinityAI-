# Deployment Runbook

## Prerequisites

- Existing Next.js application and Supabase projects for staging and production.
- Migration chain `001`–`012` applied successfully.
- RLS tests green.
- Approved legal pages and privacy disclosures.
- Verified support-resource workflow.
- Human reviewer accounts protected by MFA/TOTP.

## 1. Merge

Create a branch such as:

```bash
git checkout -b feat/ai-services-control-plane
```

Copy this package into the repository, preserving the existing application’s dependency and path conventions. Review all path conflicts rather than overwriting blindly.

## 2. Configure staging

Set server and Edge Function secrets from the supplied templates. Keep `AI_ENABLED=false` until health, auth and database checks pass.

## 3. Apply migration

```bash
supabase db push --project-ref <staging-project-ref>
```

Confirm migration `013_ai_services_control_plane.sql` creates no unexpected grants and that RLS is enabled.

## 4. Deploy functions

```bash
supabase functions deploy health --project-ref <staging-project-ref>
supabase functions deploy noor-guard --project-ref <staging-project-ref>
supabase functions deploy noor-agent --project-ref <staging-project-ref>
supabase functions deploy agent-execute --project-ref <staging-project-ref>
supabase functions deploy coach-response --project-ref <staging-project-ref>
supabase functions deploy barakah-baseline --project-ref <staging-project-ref>
supabase functions deploy ai-identity-check --project-ref <staging-project-ref>
supabase functions deploy id-document-check --project-ref <staging-project-ref>
```

## 5. Configure routes

- Public product traffic should call the Next.js `/api/noor` boundary.
- The server boundary forwards the user token to `noor-guard`.
- `noor-guard` forwards accepted requests to `noor-agent`.
- Proposed actions are decided through `agent-execute`.

## 6. Staging release gate

- wrong-origin request rejected;
- missing token rejected;
- another sister’s session returns not found;
- duplicate idempotency key returns the original request outcome;
- sensitive credential pattern never reaches the model;
- crisis phrase returns deterministic response;
- investment-recommendation request receives the educational boundary;
- malformed model JSON creates no actions;
- unknown action type is discarded;
- one action cannot execute twice;
- AI kill switch returns safe fallback;
- no secrets appear in built frontend assets;
- audit and safety events are present.

## 7. Production

1. Back up production and complete a restore drill.
2. Apply the migration in an approved window.
3. Deploy functions with `AI_ENABLED=false`.
4. Run auth, health and database smoke tests.
5. Enable one low-risk capability at a time.
6. Monitor errors, safety events, latency and budget.
7. Retain a documented rollback path.
