# Model and Prompt Governance

## Model governance

Each production route must record:

- capability name;
- provider-neutral tier;
- configuration version;
- enabled/disabled status;
- data-region and subprocessors where applicable;
- maximum tokens, timeout and daily budget;
- evaluation date and owner;
- rollback route.

A model change is a controlled release, not an environment-only convenience. It requires staging evaluation, safety checks, cost review and documented approval.

## Prompt lifecycle

Prompt statuses:

1. `draft`
2. `in_review`
3. `approved`
4. `retired`

Production services may load only `approved` prompt versions. Prompts touching Islamic, health, identity, financial or legal content require named human approval and a new immutable version identifier.

## Minimum prompt record

- service name;
- prompt version;
- purpose and prohibited behaviour;
- system prompt hash;
- approved locale(s);
- author and approver;
- approval timestamp;
- evaluation suite version;
- known limitations.

## Evaluation gates

- schema adherence;
- hallucination and unsupported-claim rate;
- prompt-injection resistance;
- sensitive-data leakage;
- crisis-route recall and false positives;
- regulated-advice boundary;
- Shariah-content source discipline;
- multilingual consistency;
- latency and cost.

## Knowledge-grounding rule

Religious content should be retrieved only from a curated, versioned and approved knowledge base. The model should not invent a fatwa or present an unaudited interpretation as authoritative. When a question exceeds the approved corpus, Noor should explain the limitation and route the user to qualified human guidance.
