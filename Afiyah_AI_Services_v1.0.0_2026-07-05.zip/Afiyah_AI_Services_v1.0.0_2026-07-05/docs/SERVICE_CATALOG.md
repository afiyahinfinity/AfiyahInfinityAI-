# Service Catalogue

## Publicly callable services

### `noor-guard`

Primary public AI boundary. Authenticates, validates, screens and forwards accepted requests to the hardened Noor agent.

### `agent-execute`

Accepts a sister’s approval or decline for a proposed Noor action. Delegates to the atomic database RPC. It does not use a service-role key.

### `coach-response`

Produces bounded, non-diagnostic coaching language. Crisis screening must occur before generation.

### `barakah-baseline`

Produces a narrative interpretation of a deterministic score. The score itself must be calculated outside the model.

### `ai-identity-check`

Assists prioritisation and plausibility checking. It must never approve or reject an identity on its own.

### `id-document-check`

Limited vision exception for identity-document plausibility. Input is transient; prompts must prohibit transcription; a human decides.

### `health`

Returns configuration-safe health metadata. It never reveals provider names, model IDs or secrets.

## Internal or privileged services

### `nightly-backup`

Produces supplementary exports only. It is not a substitute for a full managed database backup and restore procedure.

### Model gateway

Server-only provider adapter. Accepts capability tiers, enforces kill switch and timeouts, and returns provider-neutral metadata.

## Deferred services

- approved-knowledge retrieval with citation enforcement;
- automated prompt-evaluation pipeline;
- model output red-team corpus;
- multilingual safety evaluation;
- scholar escalation workflow;
- formal model risk register UI;
- jurisdiction-aware financial-education rules.
