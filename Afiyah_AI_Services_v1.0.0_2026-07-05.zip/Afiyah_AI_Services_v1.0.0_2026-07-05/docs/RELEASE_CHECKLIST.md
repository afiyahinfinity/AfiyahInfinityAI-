# AI Services Release Checklist

## Code and configuration

- [ ] No live secrets committed.
- [ ] Public variables contain no privileged values.
- [ ] All actions use allowlisted schemas.
- [ ] Provider timeout and retry limits configured.
- [ ] AI kill switch tested.
- [ ] Idempotency tested.
- [ ] Prompt and model configuration versions recorded.

## Security

- [ ] RLS tests pass.
- [ ] Cross-user session test passes.
- [ ] Atomic execution test passes.
- [ ] Prompt-injection and sensitive-data tests pass.
- [ ] Error responses expose no internals.
- [ ] Logs contain no sensitive raw content.

## Governance

- [ ] Human approval remains mandatory for consequential actions.
- [ ] Approved prompts only.
- [ ] Model evaluation documented.
- [ ] Knowledge-base approver named.
- [ ] Financial, medical, legal and Shariah disclaimers approved.
- [ ] Subprocessor and data-transfer disclosures updated.

## Operations

- [ ] Staging restore drill completed.
- [ ] Alert owner and escalation path documented.
- [ ] Cost and quota alerts configured.
- [ ] Rollback tested.
- [ ] Production smoke-test accounts prepared.
