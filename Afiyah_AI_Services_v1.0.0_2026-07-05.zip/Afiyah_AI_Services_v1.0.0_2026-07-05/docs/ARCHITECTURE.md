# AI Service Architecture

## Design goals

The service architecture prioritises privacy, human agency, provider portability, bounded AI behaviour and operational auditability. Generative AI is used only where probabilistic language generation adds value; calculations, authorization, consent, crisis safety and action execution remain deterministic.

## Service layers

### 1. Client boundary

The browser or mobile client sends an authenticated request to a server-controlled endpoint. Clients receive only public Supabase configuration and never receive model-provider credentials, service-role credentials, prompt bodies or internal routing rules.

### 2. Noor request guard

The guard performs controls before any model call:

- verifies the bearer token;
- restricts methods and origins;
- rejects oversized or malformed bodies;
- validates the request contract;
- screens for credentials, card numbers and identity-document data;
- routes crisis-like content to a fixed safe response;
- enforces the non-advisory financial boundary;
- reserves an idempotency record;
- forwards only accepted input to the hardened Noor agent.

### 3. Noor orchestration

The Noor agent:

- creates or loads only a session owned by the authenticated sister;
- applies daily quota and kill-switch controls;
- saves the user message before attempting AI;
- retrieves only necessary, scoped context;
- uses an approved versioned system prompt;
- requests a model capability tier rather than a vendor model name;
- validates all structured output;
- stores actions as `proposed`, never executed;
- appends an AI audit record.

### 4. Action approval and execution

A user decision calls one database transaction that:

- authorises the action owner;
- row-locks the proposal;
- verifies it has not already been decided or executed;
- records approval or decline;
- executes only registry-approved actions;
- stores immutable execution evidence;
- returns an idempotent result on retry.

### 5. Model gateway

The model gateway maps capabilities to configuration tiers:

| Capability | Default tier | Typical use |
|---|---|---|
| `classification` | fast | routing, safety classification, plausibility |
| `generation` | standard | Noor responses, baseline narrative |
| `vision` | vision | limited identity-document plausibility flow |
| `embedding` | embedding | approved knowledge retrieval |

Applications request a capability or tier. Provider and model IDs remain in server-side configuration.

## Trust boundaries

- **Public:** web assets, public configuration and generic API documentation.
- **Authenticated:** sister requests, session identifiers and proposed actions owned by that sister.
- **Privileged service:** model credentials, service-role database access, prompt text and internal model routing.
- **Human-review restricted:** identity documents, partner documents and review queues.

## Data minimisation

Before a model call, services must exclude or transform:

- passwords, authentication tokens and API keys;
- full payment-card numbers and bank credentials;
- government ID numbers unless the documented identity-vision exception applies;
- raw cycle history;
- unnecessary address, contact and family identifiers;
- private documents not essential to the specific task.

## Failure modes

| Failure | Required behaviour |
|---|---|
| Model unavailable | Return safe fallback; retain saved user data; no action execution |
| Invalid model JSON | Discard actions; return bounded fallback; log parse failure |
| Duplicate request | Return existing idempotent result |
| Quota exceeded | Return user-safe quota message |
| Unknown action type | Reject and log safety event |
| Database action conflict | Roll back whole transaction |
| AI kill switch off | Bypass model and preserve core product availability |
