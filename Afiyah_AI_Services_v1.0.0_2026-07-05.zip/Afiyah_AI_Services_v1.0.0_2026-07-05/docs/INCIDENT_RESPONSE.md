# AI Incident Response

## Severity

- **SEV-1:** credential exposure, cross-user data access, autonomous consequential action, harmful crisis response.
- **SEV-2:** repeated policy-boundary failure, prompt leakage, major hallucination affecting users, uncontrolled cost spike.
- **SEV-3:** isolated malformed output, latency degradation, non-sensitive logging defect.

## Immediate containment

1. Set `AI_ENABLED=false`.
2. Disable the affected capability in `ai_model_routes`.
3. Preserve relevant request IDs, hashes, audit rows and deployment SHA.
4. Revoke or rotate exposed credentials.
5. Block affected prompt/model version.
6. Escalate to the accountable product, security, legal and governance owners.

## Investigation

- establish affected users and time window;
- verify whether data crossed user boundaries;
- inspect prompt version and model-route configuration;
- reproduce with synthetic data;
- determine whether the failure was model, code, policy, data or operational control;
- document regulatory or contractual notification duties.

## Recovery

- patch and validate in staging;
- add a regression test;
- approve a new prompt/configuration version;
- deploy with the capability disabled;
- enable gradually under monitoring;
- complete post-incident review and remediation ownership.
