import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  const endpoint = process.env.NOOR_GUARD_URL;
  if (!endpoint) return NextResponse.json({ error: "server_misconfigured" }, { status: 500 });
  const authorization = request.headers.get("authorization");
  if (!authorization) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const idempotency = request.headers.get("idempotency-key") ?? crypto.randomUUID();
  const contentLength = Number(request.headers.get("content-length") ?? 0);
  if (contentLength > 16384) return NextResponse.json({ error: "body_too_large" }, { status: 413 });

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), Number(process.env.AI_REQUEST_TIMEOUT_MS ?? 25000));
  try {
    const body = await request.text();
    if (Buffer.byteLength(body, "utf8") > 16384) return NextResponse.json({ error: "body_too_large" }, { status: 413 });
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        authorization,
        "content-type": "application/json",
        "idempotency-key": idempotency,
        "x-client-info": "afiyah-nextjs-noor-boundary/1.0",
      },
      body,
      cache: "no-store",
      signal: controller.signal,
    });
    const payload = await response.json().catch(() => ({ error: "invalid_service_response" }));
    return NextResponse.json(payload, {
      status: response.status,
      headers: { "Cache-Control": "no-store", "X-Request-Id": String(payload.request_id ?? "") },
    });
  } catch (error) {
    const code = error instanceof DOMException && error.name === "AbortError" ? "service_timeout" : "service_unavailable";
    return NextResponse.json({ error: code }, { status: 503 });
  } finally {
    clearTimeout(timeout);
  }
}
