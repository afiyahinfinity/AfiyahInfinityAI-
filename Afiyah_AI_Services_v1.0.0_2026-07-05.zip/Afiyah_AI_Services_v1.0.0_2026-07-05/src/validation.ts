import type { NoorActionType, NoorModelEnvelope, NoorRequest, ProposedAction } from "./contracts.ts";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const ACTIONS = new Set<NoorActionType>(["create_goal", "update_goal_progress", "calc_zakat", "recommend_module"]);

export function isUuid(value: unknown): value is string {
  return typeof value === "string" && UUID_RE.test(value);
}

export function parseNoorRequest(input: unknown): { ok: true; value: NoorRequest } | { ok: false; error: string } {
  if (!input || typeof input !== "object" || Array.isArray(input)) return { ok: false, error: "invalid_body" };
  const body = input as Record<string, unknown>;
  const message = typeof body.message === "string" ? body.message.trim() : "";
  if (!message || message.length > 4000) return { ok: false, error: "invalid_message" };
  if (body.session_id != null && !isUuid(body.session_id)) return { ok: false, error: "invalid_session_id" };
  const locale = typeof body.locale === "string" ? body.locale.slice(0, 10) : "en";
  const client_timezone = typeof body.client_timezone === "string" ? body.client_timezone.slice(0, 64) : undefined;
  return { ok: true, value: { message, session_id: body.session_id as string | undefined, locale, client_timezone } };
}

function num(value: unknown, min: number, max: number): number | null {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) && n >= min && n <= max ? n : null;
}

export function sanitiseAction(value: unknown): ProposedAction | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const v = value as Record<string, unknown>;
  const type = String(v.action_type ?? "") as NoorActionType;
  if (!ACTIONS.has(type) || !v.payload || typeof v.payload !== "object" || Array.isArray(v.payload)) return null;
  const p = v.payload as Record<string, unknown>;
  const reason = String(v.reason ?? v.proposal_reason ?? "").trim().slice(0, 300);
  if (type === "create_goal") {
    const dimension = String(p.dimension ?? "");
    const goal_text = String(p.goal_text ?? "").trim().slice(0, 300);
    const target_value = num(p.target_value, 0, 1_000_000_000_000);
    if (!["spiritual", "wellness", "learning", "wealth", "giving", "sisterhood"].includes(dimension) || !goal_text || target_value === null) return null;
    return { action_type: type, payload: { dimension, goal_text, target_value }, reason };
  }
  if (type === "update_goal_progress") {
    const goal_id = String(p.goal_id ?? "");
    const current_value = num(p.current_value, 0, 1_000_000_000_000);
    if (!isUuid(goal_id) || current_value === null) return null;
    return { action_type: type, payload: { goal_id, current_value }, reason };
  }
  if (type === "calc_zakat") {
    const savings_aed = num(p.savings_aed ?? 0, 0, 1_000_000_000_000);
    const gold_grams = num(p.gold_grams ?? 0, 0, 1_000_000);
    if (savings_aed === null || gold_grams === null) return null;
    return { action_type: type, payload: { savings_aed, gold_grams }, reason };
  }
  const module_slug = String(p.module_slug ?? "").trim().slice(0, 80);
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(module_slug)) return null;
  return { action_type: type, payload: { module_slug }, reason };
}

export function parseModelEnvelope(input: unknown): { reply: string; actions: ProposedAction[]; blocked: number } {
  const envelope = (input && typeof input === "object" ? input : {}) as NoorModelEnvelope;
  const reply = typeof envelope.reply === "string" && envelope.reply.trim()
    ? envelope.reply.trim().slice(0, 1500)
    : "I want to answer that carefully, sister. Could you say it once more, a little differently?";
  const raw = Array.isArray(envelope.actions) ? envelope.actions.slice(0, 2) : [];
  const actions: ProposedAction[] = [];
  let blocked = 0;
  for (const item of raw) {
    const action = sanitiseAction(item);
    if (action) actions.push(action); else blocked += 1;
  }
  return { reply, actions, blocked };
}
