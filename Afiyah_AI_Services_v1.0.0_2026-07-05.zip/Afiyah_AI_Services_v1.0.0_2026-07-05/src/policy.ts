import type { GuardDecision } from "./contracts.ts";

const CRISIS_PATTERNS = [
  /\bkill myself\b/i,
  /\bsuicide\b/i,
  /\bend my life\b/i,
  /\bself[- ]?harm\b/i,
  /\bhurt myself\b/i,
  /\bdo not want to live\b/i,
];

const SECRET_PATTERNS = [
  /\b(?:password|passcode|otp|one[- ]time code)\s*[:=]/i,
  /\b(?:api[_ -]?key|secret[_ -]?key|bearer token|access token)\s*[:=]/i,
  /\b(?:sk|pk)_(?:live|test)_[A-Za-z0-9]{12,}\b/,
  /\b(?:\d[ -]*?){13,19}\b/,
  /\b(?:passport|national id|nid)\s*(?:number|no\.?|#)?\s*[:=]?\s*[A-Z0-9-]{6,}\b/i,
];

const REGULATED_ADVICE_PATTERNS = [
  /\bwhat (?:stock|share|crypto|fund) should i buy\b/i,
  /\btell me (?:exactly )?where to invest\b/i,
  /\bguaranteed return\b/i,
  /\bshould i buy or sell\b/i,
  /\bapprove my loan\b/i,
  /\bwhich investment is best for me\b/i,
];

export function classifyRequest(message: string): GuardDecision {
  if (CRISIS_PATTERNS.some((p) => p.test(message))) {
    return {
      allowModel: false,
      route: "crisis",
      reasonCode: "crisis_language",
      safeReply: "I’m really sorry you’re carrying this right now. Noor cannot safely handle an immediate crisis. Please contact local emergency services or a trusted person who can stay with you now. If you may act on these thoughts, move away from anything you could use to hurt yourself and seek urgent in-person help.",
    };
  }
  if (SECRET_PATTERNS.some((p) => p.test(message))) {
    return {
      allowModel: false,
      route: "sensitive_data",
      reasonCode: "sensitive_credential_pattern",
      safeReply: "For your safety, please do not share passwords, one-time codes, full card details, API keys or identity-document numbers here. Remove the sensitive information and ask the question again.",
    };
  }
  if (REGULATED_ADVICE_PATTERNS.some((p) => p.test(message))) {
    return {
      allowModel: false,
      route: "financial_boundary",
      reasonCode: "regulated_advice_request",
      safeReply: "I can help you learn about risk, budgeting, diversification and Shariah-screening principles, but I cannot tell you what to buy or sell or provide personalised investment advice. I can help you prepare questions for a qualified, licensed adviser.",
    };
  }
  return { allowModel: true, route: "standard" };
}

export function normaliseForHash(message: string): string {
  return message.normalize("NFKC").replace(/\s+/g, " ").trim();
}
