export type SafetyRoute = "standard" | "crisis" | "sensitive_data" | "financial_boundary" | "ai_disabled";

export interface NoorRequest {
  message: string;
  session_id?: string | null;
  locale?: string;
  client_timezone?: string;
}

export type NoorActionType = "create_goal" | "update_goal_progress" | "calc_zakat" | "recommend_module";

export interface ProposedAction {
  id?: string;
  action_type: NoorActionType;
  payload: Record<string, unknown>;
  reason?: string;
  proposal_reason?: string;
  status?: "proposed";
}

export interface NoorModelEnvelope {
  reply?: unknown;
  actions?: unknown;
}

export interface GuardDecision {
  allowModel: boolean;
  route: SafetyRoute;
  safeReply?: string;
  reasonCode?: string;
}
