import test from "node:test";
import assert from "node:assert/strict";
import { classifyRequest } from "../src/policy.ts";

test("crisis route bypasses model", () => {
  const result = classifyRequest("I want to kill myself");
  assert.equal(result.allowModel, false);
  assert.equal(result.route, "crisis");
});

test("credential pattern is blocked", () => {
  const result = classifyRequest("OTP: 123456");
  assert.equal(result.route, "sensitive_data");
});

test("personalised investment instruction is bounded", () => {
  const result = classifyRequest("What stock should I buy?");
  assert.equal(result.route, "financial_boundary");
});

test("normal coaching request proceeds", () => {
  const result = classifyRequest("Help me build a monthly savings habit");
  assert.equal(result.allowModel, true);
});
