import test from "node:test";
import assert from "node:assert/strict";
import { parseNoorRequest, sanitiseAction } from "../src/validation.ts";

test("request validator rejects unknown session shape", () => {
  const result = parseNoorRequest({ message: "hello", session_id: "not-a-uuid" });
  assert.equal(result.ok, false);
});

test("create_goal action is strictly shaped", () => {
  const action = sanitiseAction({
    action_type: "create_goal",
    payload: { dimension: "wealth", goal_text: "Emergency fund", target_value: 12000, injected: "drop table" },
    reason: "Requested by user",
  });
  assert.deepEqual(action?.payload, { dimension: "wealth", goal_text: "Emergency fund", target_value: 12000 });
});

test("unknown action is discarded", () => {
  assert.equal(sanitiseAction({ action_type: "transfer_money", payload: { amount: 1000 } }), null);
});
