# Contract and Security Test Cases

These tests must run against staging with synthetic accounts.

1. Missing bearer token returns `401`.
2. Disallowed origin returns `403`.
3. Body over configured size returns `413`.
4. Invalid UUID returns `400`.
5. Same idempotency key with different payload returns conflict.
6. Same idempotency key with the same payload returns the original response.
7. User A cannot access User B’s Noor session.
8. Crisis phrase does not call the model provider.
9. Card, API-key and OTP patterns do not call the model provider.
10. Regulated-advice request does not produce buy/sell instructions.
11. Model-proposed unknown action is discarded.
12. Model-proposed malformed action is discarded.
13. Declined action cannot later execute.
14. Approved action executes at most once under concurrent retries.
15. AI-disabled mode returns a safe fallback.
16. Provider timeout returns `503` without exposing provider details.
17. Frontend build contains no service-role or model key.
18. Health endpoint reveals no provider name or model ID.
