// Stage 1 security regression tests. STAGING ONLY.
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { createClient, SupabaseClient, User } from "@supabase/supabase-js";

const URL = process.env.STAGING_SUPABASE_URL!;
const ANON = process.env.STAGING_SUPABASE_ANON_KEY!;
const SERVICE = process.env.STAGING_SERVICE_ROLE_KEY!;
if (!URL || !ANON || !SERVICE || URL.includes("prod")) {
  throw new Error("Noor security tests must run against an isolated staging project.");
}

const admin = createClient(URL, SERVICE);
let a: User, b: User;
let userA: SupabaseClient, userB: SupabaseClient;
let tokenA = "";
let sessionB = "";
let actionB = "";

async function makeUser(tag: string) {
  const email = `noor-sec-${tag}-${Date.now()}@test.afiyah.local`;
  const password = "Test-Password-123!";
  const { data, error } = await admin.auth.admin.createUser({ email, password, email_confirm: true });
  if (error) throw error;
  await admin.from("sisters").insert({ id: data.user.id, email, status: "verified" });
  await admin.from("user_preferences").insert({ sister_id: data.user.id });
  const client = createClient(URL, ANON);
  const signed = await client.auth.signInWithPassword({ email, password });
  if (signed.error) throw signed.error;
  return { user: data.user, client, token: signed.data.session!.access_token };
}

beforeAll(async () => {
  const ua = await makeUser("a");
  const ub = await makeUser("b");
  a = ua.user; b = ub.user; userA = ua.client; userB = ub.client; tokenA = ua.token;

  const { data: session, error: sessionError } = await admin
    .from("agent_sessions")
    .insert({ sister_id: b.id })
    .select("id")
    .single();
  if (sessionError) throw sessionError;
  sessionB = session.id;

  const { data: action, error: actionError } = await admin
    .from("agent_actions")
    .insert({
      session_id: sessionB,
      sister_id: b.id,
      action_type: "create_goal",
      payload: { dimension: "wellness", goal_text: "Concurrency-safe Noor goal", target_value: 30 },
      proposal_reason: "test",
      status: "proposed",
      shariah_gate: "passed",
    })
    .select("id")
    .single();
  if (actionError) throw actionError;
  actionB = action.id;
});

afterAll(async () => {
  if (a?.id) await admin.auth.admin.deleteUser(a.id);
  if (b?.id) await admin.auth.admin.deleteUser(b.id);
});

describe("Noor session ownership", () => {
  it("rejects a caller-supplied session owned by another sister before context is read", async () => {
    const res = await fetch(`${URL}/functions/v1/noor-agent`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${tokenA}`,
        Origin: "https://afiyahinfinityai.com",
      },
      body: JSON.stringify({ message: "hello", session_id: sessionB }),
    });
    expect(res.status).toBe(404);
    const body = await res.json();
    expect(body.error).toBe("session_not_found");

    const { count } = await admin
      .from("agent_messages")
      .select("id", { count: "exact", head: true })
      .eq("session_id", sessionB)
      .eq("sister_id", a.id);
    expect(count).toBe(0);
  });

  it("database composite FK rejects a mismatched session/sister pair", async () => {
    const { error } = await admin.from("agent_messages").insert({
      session_id: sessionB,
      sister_id: a.id,
      role: "sister",
      content: "cross-tenant write",
    });
    expect(error).not.toBeNull();
  });
});

describe("Atomic action decision/execution", () => {
  it("another sister cannot decide or execute the action", async () => {
    const { data } = await userA.rpc("decide_and_execute_agent_action", {
      p_action_id: actionB,
      p_decision: "approved",
    });
    expect(data).toMatchObject({ ok: false, error: "not_found" });
  });

  it("direct table approval is no longer permitted", async () => {
    const { data } = await userB
      .from("agent_actions")
      .update({ status: "approved" })
      .eq("id", actionB)
      .select();
    expect(data ?? []).toHaveLength(0);
  });

  it("serialises concurrent approvals and creates the domain row once", async () => {
    const [first, second] = await Promise.all([
      userB.rpc("decide_and_execute_agent_action", {
        p_action_id: actionB,
        p_decision: "approved",
      }),
      userB.rpc("decide_and_execute_agent_action", {
        p_action_id: actionB,
        p_decision: "approved",
      }),
    ]);

    expect(first.error).toBeNull();
    expect(second.error).toBeNull();
    expect(first.data).toMatchObject({ ok: true, status: "executed" });
    expect(second.data).toMatchObject({ ok: true, status: "executed" });
    expect([Boolean(first.data.idempotent), Boolean(second.data.idempotent)].filter(Boolean)).toHaveLength(1);

    const { count: goalCount } = await admin
      .from("sister_goals")
      .select("id", { count: "exact", head: true })
      .eq("sister_id", b.id)
      .eq("goal_text", "Concurrency-safe Noor goal");
    expect(goalCount).toBe(1);

    const { count: executionCount } = await admin
      .from("agent_action_execution_log")
      .select("id", { count: "exact", head: true })
      .eq("action_id", actionB)
      .eq("event", "executed");
    expect(executionCount).toBe(1);
  });
});

describe("SECURITY DEFINER caller checks", () => {
  it("prevents user A from reading user B's streak through the RPC", async () => {
    const { error } = await userA.rpc("current_streak", { p_user: b.id });
    expect(error).not.toBeNull();
  });

  it("allows a sister to call the same RPC for herself", async () => {
    const { data, error } = await userA.rpc("current_streak", { p_user: a.id });
    expect(error).toBeNull();
    expect(typeof data).toBe("number");
  });
});
