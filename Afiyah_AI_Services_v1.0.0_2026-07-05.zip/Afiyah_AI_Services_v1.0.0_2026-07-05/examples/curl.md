# Request Examples

```bash
curl -X POST "$SUPABASE_URL/functions/v1/noor-guard" \
  -H "Authorization: Bearer $USER_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -H "Idempotency-Key: 123e4567-e89b-42d3-a456-426614174000" \
  -d '{"message":"Help me create a monthly savings habit","locale":"en","client_timezone":"Asia/Dhaka"}'
```

Approve a proposal:

```bash
curl -X POST "$SUPABASE_URL/functions/v1/agent-execute" \
  -H "Authorization: Bearer $USER_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"action_id":"ACTION_UUID","decision":"approved"}'
```
