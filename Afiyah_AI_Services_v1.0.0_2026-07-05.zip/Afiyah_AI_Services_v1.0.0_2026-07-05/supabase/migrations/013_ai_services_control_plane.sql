begin;

create extension if not exists pgcrypto;

create table if not exists public.ai_model_routes (
  capability text primary key,
  tier text not null check (tier in ('fast','standard','vision','embedding')),
  config_version text not null,
  enabled boolean not null default false,
  timeout_ms integer not null default 25000 check (timeout_ms between 1000 and 120000),
  max_output_tokens integer not null default 800 check (max_output_tokens between 1 and 10000),
  daily_budget_usd numeric(12,2) not null default 0 check (daily_budget_usd >= 0),
  approved_by uuid references auth.users(id),
  approved_at timestamptz,
  updated_at timestamptz not null default now()
);

create table if not exists public.ai_prompt_versions (
  id uuid primary key default gen_random_uuid(),
  service_name text not null,
  version text not null,
  status text not null default 'draft' check (status in ('draft','in_review','approved','retired')),
  system_prompt text not null,
  system_prompt_sha256 text not null check (system_prompt_sha256 ~ '^[0-9a-f]{64}$'),
  locale text not null default 'en',
  evaluation_suite_version text,
  created_by uuid references auth.users(id),
  approved_by uuid references auth.users(id),
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  unique(service_name, version, locale)
);

create table if not exists public.ai_service_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  service_name text not null,
  idempotency_key uuid not null,
  request_hash text not null check (request_hash ~ '^[0-9a-f]{64}$'),
  status text not null default 'pending' check (status in ('pending','completed','failed')),
  outcome_code text,
  response_body jsonb,
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  unique(user_id, service_name, idempotency_key)
);

create index if not exists ai_service_requests_user_created_idx
  on public.ai_service_requests(user_id, created_at desc);

create table if not exists public.ai_safety_events (
  id uuid primary key default gen_random_uuid(),
  request_id uuid references public.ai_service_requests(id) on delete set null,
  user_id uuid references auth.users(id) on delete set null,
  event_type text not null,
  severity text not null check (severity in ('low','medium','high','critical')),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.ai_model_routes enable row level security;
alter table public.ai_prompt_versions enable row level security;
alter table public.ai_service_requests enable row level security;
alter table public.ai_safety_events enable row level security;

-- Clients may read only their own request state. Writes happen through RPCs.
drop policy if exists ai_service_requests_select_own on public.ai_service_requests;
create policy ai_service_requests_select_own on public.ai_service_requests
  for select to authenticated using (user_id = auth.uid());

revoke all on public.ai_model_routes from public, anon, authenticated;
revoke all on public.ai_prompt_versions from public, anon, authenticated;
revoke all on public.ai_service_requests from public, anon, authenticated;
revoke all on public.ai_safety_events from public, anon, authenticated;
grant select on public.ai_service_requests to authenticated;

create or replace function public.reserve_ai_service_request(
  p_service_name text,
  p_idempotency_key uuid,
  p_request_hash text
) returns jsonb
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_user uuid := auth.uid();
  v_row public.ai_service_requests%rowtype;
begin
  if v_user is null then raise exception 'unauthorized'; end if;
  if p_service_name is null or length(p_service_name) > 80 then raise exception 'invalid_service'; end if;
  if p_request_hash !~ '^[0-9a-f]{64}$' then raise exception 'invalid_hash'; end if;

  insert into public.ai_service_requests(user_id, service_name, idempotency_key, request_hash)
  values (v_user, p_service_name, p_idempotency_key, p_request_hash)
  on conflict (user_id, service_name, idempotency_key) do nothing;

  select * into v_row
  from public.ai_service_requests
  where user_id = v_user and service_name = p_service_name and idempotency_key = p_idempotency_key;

  if v_row.request_hash <> p_request_hash then raise exception 'idempotency_payload_conflict'; end if;
  return jsonb_build_object(
    'request_id', v_row.id,
    'state', v_row.status,
    'response_body', v_row.response_body
  );
end;
$$;

create or replace function public.complete_ai_service_request(
  p_request_id uuid,
  p_response_body jsonb,
  p_outcome_code text
) returns boolean
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_user uuid := auth.uid();
begin
  if v_user is null then raise exception 'unauthorized'; end if;
  update public.ai_service_requests
     set status = 'completed', response_body = p_response_body,
         outcome_code = left(coalesce(p_outcome_code,'completed'),100), completed_at = now()
   where id = p_request_id and user_id = v_user and status = 'pending';
  if found then return true; end if;
  return exists(select 1 from public.ai_service_requests where id = p_request_id and user_id = v_user and status = 'completed');
end;
$$;

create or replace function public.fail_ai_service_request(
  p_request_id uuid,
  p_outcome_code text
) returns boolean
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_user uuid := auth.uid();
begin
  if v_user is null then raise exception 'unauthorized'; end if;
  update public.ai_service_requests
     set status = 'failed', outcome_code = left(coalesce(p_outcome_code,'failed'),100), completed_at = now()
   where id = p_request_id and user_id = v_user and status = 'pending';
  return found;
end;
$$;

create or replace function public.record_ai_safety_event(
  p_request_id uuid,
  p_event_type text,
  p_severity text,
  p_metadata jsonb default '{}'::jsonb
) returns uuid
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_user uuid := auth.uid();
  v_id uuid;
begin
  if v_user is null then raise exception 'unauthorized'; end if;
  if p_severity not in ('low','medium','high','critical') then raise exception 'invalid_severity'; end if;
  if not exists(select 1 from public.ai_service_requests where id = p_request_id and user_id = v_user) then
    raise exception 'request_not_owned';
  end if;
  insert into public.ai_safety_events(request_id,user_id,event_type,severity,metadata)
  values(p_request_id,v_user,left(p_event_type,100),p_severity,coalesce(p_metadata,'{}'::jsonb))
  returning id into v_id;
  return v_id;
end;
$$;

revoke all on function public.reserve_ai_service_request(text,uuid,text) from public, anon;
revoke all on function public.complete_ai_service_request(uuid,jsonb,text) from public, anon;
revoke all on function public.fail_ai_service_request(uuid,text) from public, anon;
revoke all on function public.record_ai_safety_event(uuid,text,text,jsonb) from public, anon;
grant execute on function public.reserve_ai_service_request(text,uuid,text) to authenticated;
grant execute on function public.complete_ai_service_request(uuid,jsonb,text) to authenticated;
grant execute on function public.fail_ai_service_request(uuid,text) to authenticated;
grant execute on function public.record_ai_safety_event(uuid,text,text,jsonb) to authenticated;

commit;
