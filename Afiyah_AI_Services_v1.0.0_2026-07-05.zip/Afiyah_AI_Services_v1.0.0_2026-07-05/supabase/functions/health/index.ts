import { corsHeaders, json, originAllowed } from "../_shared/http.ts";

Deno.serve((req) => {
  const cors = corsHeaders(req);
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (!originAllowed(req)) return json({ status: "unavailable" }, 403, cors);
  if (req.method !== "GET") return json({ error: "method_not_allowed" }, 405, cors);
  return json({
    status: "ok",
    service: "afiyah-ai-services",
    version: "1.0.0",
    ai_enabled: (Deno.env.get("AI_ENABLED") ?? "false").toLowerCase() === "true",
    config_version: Deno.env.get("LLM_CONFIG_VERSION") ?? "unset",
    timestamp: new Date().toISOString(),
  }, 200, cors);
});
