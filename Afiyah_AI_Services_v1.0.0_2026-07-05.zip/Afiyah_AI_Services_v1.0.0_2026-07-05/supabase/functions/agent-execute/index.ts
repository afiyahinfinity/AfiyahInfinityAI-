// ============================================================
// Atomic Noor action decision/execution endpoint.
// The sister's JWT calls one SECURITY DEFINER RPC that authorises,
// row-locks, decides and executes in a single database transaction.
// No service-role key is used in this Edge Function.
// ============================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  const cors = corsHeaders(req);
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (!originAllowed(req)) return json({ error: "origin_not_allowed" }, 403, cors);
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405, cors);

  const authHeader = req.headers.get("Authorization");
  if (!authHeader) return json({ error: "unauthorized" }, 401, cors);

  const url = Deno.env.get("SUPABASE_URL");
  const anon = Deno.env.get("SUPABASE_ANON_KEY");
  if (!url || !anon) return json({ error: "server_misconfigured" }, 500, cors);

  const supabase = createClient(url, anon, {
    global: { headers: { Authorization: authHeader } },
  });
  const { data: { user }, error: userError } = await supabase.auth.getUser();
  if (userError || !user) return json({ error: "unauthorized" }, 401, cors);

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return json({ error: "invalid_json" }, 400, cors);
  }

  const actionId = String(body.action_id ?? "");
  const decision = String(body.decision ?? "");
  if (!UUID_RE.test(actionId)) return json({ error: "invalid_action_id" }, 400, cors);
  if (!["approved", "declined"].includes(decision)) return json({ error: "invalid_decision" }, 400, cors);

  const { data, error } = await supabase.rpc("decide_and_execute_agent_action", {
    p_action_id: actionId,
    p_decision: decision,
  });

  if (error) return json({ error: "decision_failed" }, 400, cors);
  const result = (data ?? { ok: false, error: "empty_result" }) as Record<string, unknown>;
  const status = result.ok === true ? 200 : result.error === "not_found" ? 404 : 409;
  return json(result, status, cors);
});

function allowedOrigins(): string[] {
  return (Deno.env.get("ALLOWED_ORIGINS") ?? "https://afiyahinfinityai.com,https://www.afiyahinfinityai.com")
    .split(",")
    .map((v) => v.trim())
    .filter(Boolean);
}

function originAllowed(req: Request): boolean {
  const origin = req.headers.get("Origin");
  return !origin || allowedOrigins().includes(origin);
}

function corsHeaders(req: Request): Record<string, string> {
  const origin = req.headers.get("Origin");
  const allowed = allowedOrigins();
  const resolved = origin && allowed.includes(origin) ? origin : allowed[0];
  return {
    "Access-Control-Allow-Origin": resolved,
    "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Vary": "Origin",
  };
}

function json(payload: unknown, status: number, cors: Record<string, string>) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { ...cors, "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
  });
}
