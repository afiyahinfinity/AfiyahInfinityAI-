export function allowedOrigins(): string[] {
  return (Deno.env.get("ALLOWED_ORIGINS") ?? "https://afiyahinfinityai.com,https://www.afiyahinfinityai.com")
    .split(",").map((v) => v.trim()).filter(Boolean);
}

export function originAllowed(req: Request): boolean {
  const origin = req.headers.get("Origin");
  return !origin || allowedOrigins().includes(origin);
}

export function corsHeaders(req: Request): Record<string, string> {
  const origin = req.headers.get("Origin");
  const allowed = allowedOrigins();
  const resolved = origin && allowed.includes(origin) ? origin : allowed[0];
  return {
    "Access-Control-Allow-Origin": resolved,
    "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info, idempotency-key",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Vary": "Origin",
  };
}

export function json(payload: unknown, status: number, cors: Record<string, string>) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { ...cors, "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
  });
}

export async function readJsonWithLimit(req: Request): Promise<{ ok: true; value: unknown } | { ok: false; error: string }> {
  const max = Number(Deno.env.get("AI_MAX_BODY_BYTES") ?? 16384);
  const declared = Number(req.headers.get("content-length") ?? 0);
  if (declared > max) return { ok: false, error: "body_too_large" };
  const text = await req.text();
  if (new TextEncoder().encode(text).byteLength > max) return { ok: false, error: "body_too_large" };
  try { return { ok: true, value: JSON.parse(text) }; }
  catch { return { ok: false, error: "invalid_json" }; }
}
