// ============================================================
// supabase/functions/_shared/llm-gateway.ts
// Vendor-neutral AI gateway — Afiyah owns the agent, not the vendor.
//
// Founder directive: the platform must not be attached to any single
// AI provider. All Edge Functions call THIS module; the provider is
// chosen by environment variables and can be swapped with zero code
// changes. Audit logs record tiers, never vendor model names.
//
// Env vars:
//   AI_ENABLED            "true" | "false"   (kill-switch, B1 item 6)
//   LLM_PROVIDER          "anthropic" | "openai" | "azure" | "local"
//   LLM_API_KEY           key for the chosen provider
//   LLM_BASE_URL          optional override (Azure endpoint, local vLLM/Ollama)
//   LLM_MODEL_FAST        provider model id for classification tier
//   LLM_MODEL_STANDARD    provider model id for generation tier
//   LLM_CONFIG_VERSION    e.g. "v1" — stamped into audit rows
//
// Tiers (functions request a TIER, never a model):
//   "fast"     → identity plausibility, routing, classification
//   "standard" → coach responses, Barakah baseline, Shariah review
// ============================================================

export type Tier = "fast" | "standard";

export interface LLMResult {
  ok: boolean;
  text: string;
  provider_tier: string;      // e.g. "standard@v1" — safe for audit log
  latency_ms: number;
  error?: string;
}

interface ProviderAdapter {
  complete(model: string, system: string | null, prompt: string, maxTokens: number): Promise<string>;
}

// ── Provider adapters (add more without touching callers) ────

const anthropicAdapter: ProviderAdapter = {
  async complete(model, system, prompt, maxTokens) {
    const res = await fetch(
      (Deno.env.get("LLM_BASE_URL") ?? "https://api.anthropic.com") + "/v1/messages",
      {
        method: "POST",
        headers: {
          "x-api-key": Deno.env.get("LLM_API_KEY")!,
          "anthropic-version": "2023-06-01",
          "content-type": "application/json",
        },
        body: JSON.stringify({
          model, max_tokens: maxTokens,
          ...(system ? { system } : {}),
          messages: [{ role: "user", content: prompt }],
        }),
      },
    );
    if (!res.ok) throw new Error(`provider ${res.status}`);
    const data = await res.json();
    return (data.content ?? []).filter((b: any) => b.type === "text").map((b: any) => b.text).join("\n");
  },
};

// OpenAI-compatible: covers OpenAI, Azure OpenAI (with LLM_BASE_URL),
// and self-hosted vLLM / Ollama / LM Studio ("local") — one adapter.
const openaiCompatibleAdapter: ProviderAdapter = {
  async complete(model, system, prompt, maxTokens) {
    const base = Deno.env.get("LLM_BASE_URL") ?? "https://api.openai.com";
    const res = await fetch(base + "/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${Deno.env.get("LLM_API_KEY") ?? "none"}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model, max_tokens: maxTokens,
        messages: [
          ...(system ? [{ role: "system", content: system }] : []),
          { role: "user", content: prompt },
        ],
      }),
    });
    if (!res.ok) throw new Error(`provider ${res.status}`);
    const data = await res.json();
    return data.choices?.[0]?.message?.content ?? "";
  },
};

const ADAPTERS: Record<string, ProviderAdapter> = {
  anthropic: anthropicAdapter,
  openai: openaiCompatibleAdapter,
  azure: openaiCompatibleAdapter,
  local: openaiCompatibleAdapter,
};

// ── Public API ───────────────────────────────────────────────

export function aiEnabled(): boolean {
  return (Deno.env.get("AI_ENABLED") ?? "true").toLowerCase() === "true";
}

export async function complete(
  tier: Tier,
  prompt: string,
  opts: { system?: string; maxTokens?: number; retries?: number } = {},
): Promise<LLMResult> {
  const version = Deno.env.get("LLM_CONFIG_VERSION") ?? "v1";
  const provider_tier = `${tier}@${version}`;
  const t0 = Date.now();

  // Kill-switch: fail open — callers route to human review, never block.
  if (!aiEnabled()) {
    return { ok: false, text: "", provider_tier, latency_ms: 0, error: "ai_disabled" };
  }

  const providerName = Deno.env.get("LLM_PROVIDER") ?? "anthropic";
  const adapter = ADAPTERS[providerName];
  const model = Deno.env.get(tier === "fast" ? "LLM_MODEL_FAST" : "LLM_MODEL_STANDARD");
  if (!adapter || !model) {
    return { ok: false, text: "", provider_tier, latency_ms: 0, error: "misconfigured_provider" };
  }

  const retries = opts.retries ?? 1;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const text = await adapter.complete(model, opts.system ?? null, prompt, opts.maxTokens ?? 700);
      return { ok: true, text, provider_tier, latency_ms: Date.now() - t0 };
    } catch (e) {
      if (attempt === retries) {
        return { ok: false, text: "", provider_tier, latency_ms: Date.now() - t0, error: String(e?.message ?? e) };
      }
      await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
    }
  }
  return { ok: false, text: "", provider_tier, latency_ms: Date.now() - t0, error: "unreachable" };
}

// Structured output helper — strips fences, parses, fails open to null.
export async function completeJSON<T>(
  tier: Tier,
  prompt: string,
  opts: { system?: string; maxTokens?: number } = {},
): Promise<{ data: T | null; meta: LLMResult }> {
  const meta = await complete(tier, prompt, opts);
  if (!meta.ok) return { data: null, meta };
  try {
    const clean = meta.text.replace(/```json|```/g, "").trim();
    return { data: JSON.parse(clean) as T, meta };
  } catch {
    return { data: null, meta: { ...meta, ok: false, error: "json_parse_failed" } };
  }
}

// ── Vision: image + prompt → JSON (vendor-neutral) ───────────
export async function completeVisionJSON<T>(
  tier: Tier, b64: string, mediaType: string, instruction: string, maxTokens = 400,
): Promise<{ data: T | null; meta: LLMResult }> {
  const version = Deno.env.get("LLM_CONFIG_VERSION") ?? "v1";
  const provider_tier = `${tier}-vision@${version}`;
  const t0 = Date.now();
  if (!aiEnabled()) return { data: null, meta: { ok: false, text: "", provider_tier, latency_ms: 0, error: "ai_disabled" } };
  const providerName = Deno.env.get("LLM_PROVIDER") ?? "anthropic";
  const model = Deno.env.get(tier === "fast" ? "LLM_MODEL_FAST" : "LLM_MODEL_STANDARD")!;
  try {
    let text: string;
    if (providerName === "anthropic") {
      const res = await fetch((Deno.env.get("LLM_BASE_URL") ?? "https://api.anthropic.com") + "/v1/messages", {
        method: "POST",
        headers: { "x-api-key": Deno.env.get("LLM_API_KEY")!, "anthropic-version": "2023-06-01", "content-type": "application/json" },
        body: JSON.stringify({ model, max_tokens: maxTokens, messages: [{ role: "user", content: [
          { type: "image", source: { type: "base64", media_type: mediaType, data: b64 } },
          { type: "text", text: instruction }] }] }),
      });
      if (!res.ok) throw new Error(`provider ${res.status}`);
      const d = await res.json();
      text = d.content.filter((c: any) => c.type === "text").map((c: any) => c.text).join("");
    } else { // OpenAI-compatible vision
      const base = Deno.env.get("LLM_BASE_URL") ?? "https://api.openai.com";
      const res = await fetch(base + "/v1/chat/completions", {
        method: "POST",
        headers: { Authorization: `Bearer ${Deno.env.get("LLM_API_KEY") ?? "none"}`, "content-type": "application/json" },
        body: JSON.stringify({ model, max_tokens: maxTokens, messages: [{ role: "user", content: [
          { type: "image_url", image_url: { url: `data:${mediaType};base64,${b64}` } },
          { type: "text", text: instruction }] }] }),
      });
      if (!res.ok) throw new Error(`provider ${res.status}`);
      text = (await res.json()).choices?.[0]?.message?.content ?? "";
    }
    const meta: LLMResult = { ok: true, text, provider_tier, latency_ms: Date.now() - t0 };
    try { return { data: JSON.parse(text.replace(/```json|```/g, "").trim()) as T, meta }; }
    catch { return { data: null, meta: { ...meta, ok: false, error: "json_parse_failed" } }; }
  } catch (e) {
    return { data: null, meta: { ok: false, text: "", provider_tier, latency_ms: Date.now() - t0, error: String(e?.message ?? e) } };
  }
}

// ── Embeddings (vendor-neutral). Env: EMBED_PROVIDER, EMBED_API_KEY,
//    EMBED_BASE_URL, EMBED_MODEL. Any OpenAI-compatible endpoint works
//    (OpenAI, Azure, local text-embeddings-inference / Ollama).
export async function embed(input: string): Promise<number[] | null> {
  try {
    const base = Deno.env.get("EMBED_BASE_URL") ?? "https://api.openai.com";
    const res = await fetch(base + "/v1/embeddings", {
      method: "POST",
      headers: { Authorization: `Bearer ${Deno.env.get("EMBED_API_KEY") ?? "none"}`, "content-type": "application/json" },
      body: JSON.stringify({ model: Deno.env.get("EMBED_MODEL") ?? "text-embedding-3-small", input }),
    });
    if (!res.ok) return null;
    return (await res.json()).data?.[0]?.embedding ?? null;
  } catch { return null; }
}

/* ─────────────────────────────────────────────────────────────
REFACTOR GUIDE (1–2h total)

1) ai-identity-check/index.ts — replace the inline fetch block with:

   import { completeJSON } from "../_shared/llm-gateway.ts";
   const { data, meta } = await completeJSON<{score:number;flags:string[];reason:string}>(
     "fast", prompt, { maxTokens: 300 });
   const score = data ? Math.max(0, Math.min(100, data.score)) : 50;
   const flags = data?.flags ?? ["ai_parse_fallback"];   // → human queue
   // audit row: ai_model: meta.provider_tier   (NOT a vendor string)

2) id-document-check → tier "fast". 3) barakah-baseline → "standard".
4) coach-response → "standard"; DELETE the OPENAI_API_KEY branch —
   multi-vendor now lives in env config, not code.

5) Migration (include in 006): widen the audit column meaning —
   COMMENT ON COLUMN ai_response_audit_log.model_used IS
     'provider tier + config version (vendor-neutral), e.g. standard@v1';

6) Secrets to set (example — anthropic today, swappable tomorrow):
   supabase secrets set AI_ENABLED=true LLM_PROVIDER=anthropic \
     LLM_API_KEY=<provider-key> LLM_MODEL_FAST=claude-haiku-4-5 \
     LLM_MODEL_STANDARD=claude-sonnet-4-6 LLM_CONFIG_VERSION=v1

   To move to a self-hosted model later (full sovereignty):
   LLM_PROVIDER=local LLM_BASE_URL=https://ai.afiyahinfinityai.com \
     LLM_MODEL_FAST=qwen2.5-7b LLM_MODEL_STANDARD=llama-3.3-70b

Governance note (deck + privacy policy): "Afiyah's AI agents are
proprietary orchestration built in-house; underlying language models
are supplied by interchangeable leading LLM providers under
no-training-on-API-data terms, disclosed as sub-processors."
───────────────────────────────────────────────────────────── */
