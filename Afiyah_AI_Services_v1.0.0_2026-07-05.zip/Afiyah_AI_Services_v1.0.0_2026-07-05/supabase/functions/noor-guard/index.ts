import { createClient } from "jsr:@supabase/supabase-js@2";
import { classifyRequest, normaliseForHash } from "../_shared/policy.ts";
import { parseNoorRequest } from "../_shared/validation.ts";
import { sha256Hex } from "../_shared/hash.ts";
import { corsHeaders, json, originAllowed, readJsonWithLimit } from "../_shared/http.ts";

Deno.serve(async (req) => {
  const cors = corsHeaders(req);
  const requestId = crypto.randomUUID();
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (!originAllowed(req)) return json({ error: "origin_not_allowed", request_id: requestId }, 403, cors);
  if (req.method !== "POST") return json({ error: "method_not_allowed", request_id: requestId }, 405, cors);

  const authorization = req.headers.get("Authorization");
  if (!authorization) return json({ error: "unauthorized", request_id: requestId }, 401, cors);
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  if (!supabaseUrl || !anonKey) return json({ error: "server_misconfigured", request_id: requestId }, 500, cors);

  const client = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authorization } } });
  const { data: { user }, error: userError } = await client.auth.getUser();
  if (userError || !user) return json({ error: "unauthorized", request_id: requestId }, 401, cors);

  const parsedJson = await readJsonWithLimit(req);
  if (!parsedJson.ok) return json({ error: parsedJson.error, request_id: requestId }, parsedJson.error === "body_too_large" ? 413 : 400, cors);
  const parsed = parseNoorRequest(parsedJson.value);
  if (!parsed.ok) return json({ error: parsed.error, request_id: requestId }, 400, cors);

  const idempotencyKey = req.headers.get("Idempotency-Key");
  if (!idempotencyKey || !/^[0-9a-f-]{36}$/i.test(idempotencyKey)) {
    return json({ error: "invalid_idempotency_key", request_id: requestId }, 400, cors);
  }

  const requestHash = await sha256Hex(normaliseForHash(parsed.value.message));
  const { data: reservation, error: reserveError } = await client.rpc("reserve_ai_service_request", {
    p_service_name: "noor",
    p_idempotency_key: idempotencyKey,
    p_request_hash: requestHash,
  });
  if (reserveError) return json({ error: "request_reservation_failed", request_id: requestId }, 409, cors);
  const reserved = reservation as { request_id?: string; state?: string; response_body?: unknown } | null;
  const persistedRequestId = reserved?.request_id ?? requestId;
  if (reserved?.state === "completed" && reserved.response_body) {
    return json(reserved.response_body, 200, cors);
  }

  const decision = classifyRequest(parsed.value.message);
  if (!decision.allowModel) {
    const response = {
      request_id: persistedRequestId,
      session_id: parsed.value.session_id ?? null,
      reply: decision.safeReply,
      actions: [],
      safety: { route: decision.route, human_review_required: decision.route === "crisis" },
    };
    await client.rpc("record_ai_safety_event", {
      p_request_id: persistedRequestId,
      p_event_type: decision.reasonCode ?? decision.route,
      p_severity: decision.route === "crisis" ? "high" : "medium",
    });
    await client.rpc("complete_ai_service_request", {
      p_request_id: persistedRequestId,
      p_response_body: response,
      p_outcome_code: decision.route,
    });
    return json(response, 200, cors);
  }

  if ((Deno.env.get("AI_ENABLED") ?? "false").toLowerCase() !== "true") {
    const response = {
      request_id: persistedRequestId,
      session_id: parsed.value.session_id ?? null,
      reply: "Noor is resting for maintenance right now. Your other Afiyah services remain available.",
      actions: [],
      safety: { route: "ai_disabled", human_review_required: false },
    };
    await client.rpc("complete_ai_service_request", {
      p_request_id: persistedRequestId,
      p_response_body: response,
      p_outcome_code: "ai_disabled",
    });
    return json(response, 200, cors);
  }

  const target = Deno.env.get("NOOR_AGENT_URL") ?? `${supabaseUrl}/functions/v1/noor-agent`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), Number(Deno.env.get("AI_REQUEST_TIMEOUT_MS") ?? 25000));
  try {
    const upstream = await fetch(target, {
      method: "POST",
      headers: { Authorization: authorization, "Content-Type": "application/json", "Idempotency-Key": idempotencyKey },
      body: JSON.stringify(parsed.value),
      signal: controller.signal,
    });
    const upstreamBody = await upstream.json().catch(() => ({ error: "invalid_upstream_response" }));
    if (!upstream.ok) {
      await client.rpc("fail_ai_service_request", {
        p_request_id: persistedRequestId,
        p_outcome_code: String((upstreamBody as Record<string, unknown>).error ?? "upstream_failed"),
      });
      return json({ ...upstreamBody, request_id: persistedRequestId }, upstream.status, cors);
    }
    const response = {
      ...(upstreamBody as Record<string, unknown>),
      request_id: persistedRequestId,
      safety: { route: "standard", human_review_required: false },
    };
    await client.rpc("complete_ai_service_request", {
      p_request_id: persistedRequestId,
      p_response_body: response,
      p_outcome_code: "completed",
    });
    return json(response, 200, cors);
  } catch (error) {
    const outcome = error instanceof DOMException && error.name === "AbortError" ? "upstream_timeout" : "upstream_unavailable";
    await client.rpc("fail_ai_service_request", { p_request_id: persistedRequestId, p_outcome_code: outcome });
    return json({ error: outcome, message: "Noor is temporarily unavailable. Please try again.", request_id: persistedRequestId }, 503, cors);
  } finally {
    clearTimeout(timeout);
  }
});
