// ============================================================
// supabase/functions/id-document-check/index.ts
// Step 2: Claude vision check on the uploaded ID document.
//
// GOVERNANCE NOTE — the one deliberate exception to "no PII to AI":
// the document image itself must be seen to be checked. Rules that
// keep this defensible:
//   1. Transient only — image fetched via signed URL, sent to the API,
//      never written anywhere else; Anthropic API does not train on
//      API data (disclose Anthropic as processor in the privacy policy).
//   2. The audit log stores a SUMMARY ONLY (booleans + category),
//      never extracted text, never the image.
//   3. AI never decides alone: every ID goes to the human queue;
//      the AI result only sets priority and pre-fills flags.
//   4. The image auto-deletes 60 days after decision (migration 002/004).
// ============================================================
import { createClient } from "jsr:@supabase/supabase-js@2";
import { completeVisionJSON } from "../_shared/llm-gateway.ts";

const PROMPT_VERSION = "id-check-v1.0";

Deno.serve(async (req) => {
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  const jwt = req.headers.get("authorization")?.replace("Bearer ", "");
  const { data: { user } } = await createClient(
    Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: `Bearer ${jwt}` } } },
  ).auth.getUser();
  if (!user) return Response.json({ error: "unauthorised" }, { status: 401 });

  const { storage_path, document_type } = await req.json();
  // Path must be inside HER folder — defence in depth on top of storage RLS.
  if (!storage_path?.startsWith(`${user.id}/`)) {
    return Response.json({ error: "invalid_path" }, { status: 400 });
  }

  // Mark submitted + persist path regardless of AI availability.
  await supabase.from("sister_verifications").upsert({
    sister_id: user.id,
    document_url: storage_path,
    document_type,
  }, { onConflict: "sister_id" });
  await supabase.from("sisters").update({ status: "id_submitted" }).eq("id", user.id);

  // Kill-switch / quota — same gates as identity check.
  if (Deno.env.get("AI_ENABLED") !== "true") {
    await enqueue(supabase, user.id, "high", "AI disabled — manual ID review");
    return Response.json({ route: "human_review" });
  }
  const { data: ok } = await supabase.rpc("consume_ai_quota",
    { p_user: user.id, p_daily_limit: 10 });
  if (!ok) return Response.json({ error: "quota_exceeded" }, { status: 429 });

  // Registered name — needed for the match check, sent ONLY for comparison.
  const { data: sister } = await supabase
    .from("sisters").select("display_name").eq("id", user.id).single();

  // Transient signed URL (120s) for the model to fetch — never logged.
  const { data: signed } = await supabase.storage
    .from("id-documents").createSignedUrl(storage_path, 120);

  const imgRes = await fetch(signed!.signedUrl);
  const imgBytes = new Uint8Array(await imgRes.arrayBuffer());
  if (imgBytes.length > 8_000_000) {
    return Response.json({ error: "file_too_large" }, { status: 400 });
  }
  const b64 = btoa(String.fromCharCode(...imgBytes));
  const mediaType = imgRes.headers.get("content-type") ?? "image/jpeg";

  const instruction = `You are checking an identity document for a verification queue.
Registered name on the account: "${sister?.display_name}"
Claimed document type: ${document_type}

Answer ONLY in JSON:
{
 "looks_like_real_id": true/false,        // structure of a genuine ID document (photo area, fields, machine-readable zone where applicable)
 "readable": true/false,                   // clear enough for a human to verify
 "name_match": "match"|"partial"|"no_match"|"unreadable",  // vs registered name; transliteration variants count as partial/match
 "document_type_match": true/false,
 "confidence": 0-100,
 "flags": [short strings, e.g. "screenshot_of_screen","cropped","glare"]
}
Do NOT transcribe any other personal data (numbers, dates, address). Do not include extracted text in your answer.`;

  // Vendor-neutral vision call via gateway ("standard" tier)
  const { data: parsedVision, meta } = await completeVisionJSON<{
    looks_like_real_id: boolean; readable: boolean;
    name_match: string; document_type_match: boolean;
    confidence: number; flags: string[];
  }>("standard", b64, mediaType, instruction, 400);

  let result = { looks_like_real_id: false, readable: false, name_match: "unreadable",
                 document_type_match: false, confidence: 0, flags: ["ai_unavailable"] };
  if (parsedVision) result = parsedVision;
  else if (meta.error === "json_parse_failed") result.flags = ["ai_parse_fallback"];

  // Audit: SUMMARY ONLY — booleans and category, nothing extracted.
  const promptHash = await sha256(PROMPT_VERSION + storage_path);
  await supabase.rpc("log_ai_call", {
    p_entity_type: "sister", p_entity_id: user.id,
    p_prompt_hash: promptHash, p_prompt_version: PROMPT_VERSION,
    p_model: meta.provider_tier,
    p_summary: `id_check real=${result.looks_like_real_id} readable=${result.readable} name=${result.name_match} conf=${result.confidence} flags=${(result.flags||[]).join(",")}`,
    p_flagged: !result.looks_like_real_id || result.name_match === "no_match",
  });

  await supabase.from("sister_verifications").update({
    ai_confidence_score: result.confidence,
    ai_flags: result.flags,
    ai_model: meta.provider_tier,
    ai_checked_at: new Date().toISOString(),
  }).eq("sister_id", user.id);

  // EVERY ID gets a human; AI only sets priority + prefilled notes.
  const priority =
    (!result.looks_like_real_id || result.name_match === "no_match") ? "high" : "normal";
  await enqueue(supabase, user.id, priority,
    `ID check — real:${result.looks_like_real_id} readable:${result.readable} name:${result.name_match} conf:${result.confidence}`);

  return Response.json({ route: "human_review", received: true });
});

async function enqueue(sb: any, sisterId: string, priority: string, notes: string) {
  await sb.from("admin_review_queue").insert({
    entity_type: "sister", entity_id: sisterId,
    priority, status: "pending", notes,
  });
}

async function sha256(s: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
}
