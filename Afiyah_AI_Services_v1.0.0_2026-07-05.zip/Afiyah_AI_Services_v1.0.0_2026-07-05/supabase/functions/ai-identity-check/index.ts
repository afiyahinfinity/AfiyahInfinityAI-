// ============================================================
// supabase/functions/ai-identity-check/index.ts
// Step 1 gate: Claude Haiku plausibility check on signup signals.
// Governance built in: kill-switch · quota · no-PII prompt ·
// hash-chained audit · confidence routing (≥70 advance / 40–69
// queue / <40 soft-reject-with-appeal).
// Invoked by: app/api/identity-check route after email verification.
// ============================================================
import { createClient } from "jsr:@supabase/supabase-js@2";
import { completeJSON } from "../_shared/llm-gateway.ts";

const PROMPT_VERSION = "identity-check-v1.0";
const THRESHOLD_ADVANCE = 70;
const THRESHOLD_REJECT = 40;

Deno.serve(async (req) => {
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  // Caller must be the authenticated sister herself (JWT forwarded).
  const jwt = req.headers.get("authorization")?.replace("Bearer ", "");
  const { data: { user } } = await createClient(
    Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: `Bearer ${jwt}` } } },
  ).auth.getUser();
  if (!user) return Response.json({ error: "unauthorised" }, { status: 401 });

  // ── Governance gate 1: kill-switch ──
  if (Deno.env.get("AI_ENABLED") !== "true") {
    // Fail open to human-only: queue directly, no AI.
    await supabase.from("admin_review_queue").insert({
      entity_type: "sister", entity_id: user.id,
      priority: "normal", status: "pending",
      notes: "AI disabled — direct human review",
    });
    return Response.json({ route: "human_review" });
  }

  // ── Governance gate 2: quota ──
  const { data: ok } = await supabase.rpc("consume_ai_quota",
    { p_user: user.id, p_daily_limit: 10 });
  if (!ok) return Response.json({ error: "quota_exceeded" }, { status: 429 });

  // ── Build ANONYMISED signals (the no-PII rule) ──
  // We never send her name or email. We send derived signals only.
  const { data: sister } = await supabase
    .from("sisters")
    .select("display_name, country_code, created_at")
    .eq("id", user.id).single();

  const emailDomain = user.email!.split("@")[1].toLowerCase();
  const signals = {
    email_domain: emailDomain,                       // domain only, never the address
    email_domain_is_disposable_hint: null,           // model judges from domain
    name_token_count: (sister?.display_name ?? "").trim().split(/\s+/).length,
    name_has_digits: /\d/.test(sister?.display_name ?? ""),
    name_script: /[\u0600-\u06FF]/.test(sister?.display_name ?? "") ? "arabic"
               : /[\u0980-\u09FF]/.test(sister?.display_name ?? "") ? "bengali" : "latin",
    country_code: sister?.country_code ?? "unknown",
    account_age_minutes: Math.round((Date.now() - new Date(sister!.created_at).getTime()) / 60000),
  };

  const prompt = `You are a registration-plausibility scorer for a women-only wellness platform.
Score 0-100 how plausible this registration is as a genuine individual signup (NOT a bot/bulk/disposable account). You are NOT judging gender or identity — only signup-pattern plausibility. Higher = more plausible.

Signals (derived, anonymised):
${JSON.stringify(signals, null, 2)}

Consider: disposable/throwaway email domains score low; well-known consumer or corporate domains score high; name signal anomalies (digits, zero/one tokens) lower the score; instant-signup automation patterns lower it.

Respond ONLY with JSON: {"score": <0-100>, "flags": [<short strings>], "reason": "<one sentence>"}`;

  // ── Call the vendor-neutral gateway ("fast" tier) ──
  const { data: parsed, meta } = await completeJSON<{ score: number; flags: string[]; reason: string }>(
    "fast", prompt, { maxTokens: 300 });

  let score = 50, flags: string[] = ["ai_parse_fallback"], reason = "fallback";
  if (parsed) {
    score = Math.max(0, Math.min(100, parsed.score));
    flags = parsed.flags ?? [];
    reason = parsed.reason ?? "";
  } else if (meta.error === "ai_disabled" || meta.error?.startsWith("provider")) {
    // Kill-switch or outage: fail open to human review, never block the sister.
    flags = ["ai_unavailable"];
  }

  // ── Governance gate 3: hash-chained audit log ──
  const promptHash = await sha256(prompt);
  await supabase.rpc("log_ai_call", {
    p_entity_type: "sister", p_entity_id: user.id,
    p_prompt_hash: promptHash, p_prompt_version: PROMPT_VERSION,
    p_model: meta.provider_tier,
    p_summary: `identity score=${score} flags=${flags.join(",")} | ${reason}`.slice(0, 500),
    p_flagged: score < THRESHOLD_ADVANCE,
  });

  // ── Persist + route ──
  await supabase.from("sister_verifications").upsert({
    sister_id: user.id,
    ai_confidence_score: score,
    ai_flags: flags,
    ai_model: meta.provider_tier,
    ai_checked_at: new Date().toISOString(),
  }, { onConflict: "sister_id" });
  // (the 003 trigger enqueues 40–69 + <40 automatically)

  const route =
    score >= THRESHOLD_ADVANCE ? "proceed_to_id_upload" :
    score >= THRESHOLD_REJECT ? "human_review" : "soft_reject_appeal";

  return Response.json({ route, score });
});

async function sha256(s: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
}
