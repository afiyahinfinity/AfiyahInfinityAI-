// =====================================================
// AFIYAH INFINITY AI — AI Coach Edge Function
// Deploy: supabase functions deploy coach-response
// Secrets: LLM_* + EMBED_* (see _shared/llm-gateway.ts) — vendor-neutral
// =====================================================

import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import { complete, embed } from "../_shared/llm-gateway.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return json({ error: "Missing authorization" }, 401);

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) return json({ error: "Unauthorized" }, 401);

    const body = await req.json();
    const messageType = body.message_type ?? "dashboard_nudge";
    const userQuestion = body.user_message ?? "Give me my personalised dashboard nudge.";

    // Load sister profile
    const { data: profile } = await supabase
      .from("sisters")
      .select("first_name, preferred_language")
      .eq("id", user.id)
      .maybeSingle();

    const firstName = profile?.first_name ?? "Sister";
    const preferredLanguage = profile?.preferred_language ?? "en";

    // Load latest check-in
    const { data: checkin } = await supabase
      .from("daily_checkins")
      .select("id, date, answers")
      .eq("user_id", user.id)
      .order("date", { ascending: false })
      .limit(1)
      .maybeSingle();

    // Load active cycle status
    const { data: cycle } = await supabase
      .from("cycle_logs")
      .select("*")
      .eq("user_id", user.id)
      .eq("is_active_bleeding", true)
      .order("start_date", { ascending: false })
      .limit(1)
      .maybeSingle();

    // Safety guardrail check
    const guardrail = inspectIntent(userQuestion);

    if (guardrail !== "safe") {
      const fallback = fallbackResponse(guardrail, (await supabase.from("sisters").select("country_code").eq("id", user.id).maybeSingle()).data?.country_code);
      await supabase.from("ai_coach_responses").insert({
        user_id: user.id,
        checkin_id: checkin?.id ?? null,
        response_type: messageType,
        prompt_context: { userQuestion, checkin: checkin?.answers ?? null, cycle },
        retrieved_sources: [],
        ai_response: fallback,
        safety_status: "fallback",
      });
      return json({ response: fallback, sources: [], safety_status: "fallback" });
    }

    // Build retrieval query from check-in context
    const embeddingText = buildRetrievalQuery(userQuestion, checkin?.answers, cycle);

    // Embedding via vendor-neutral gateway (EMBED_* env config)
    const queryEmbedding = await embed(embeddingText);

    // Vector search for relevant Islamic sources
    let sources: any[] = [];
    if (queryEmbedding) {
      const { data: matchedSources } = await supabase.rpc(
        "match_islamic_knowledge_multilingual",
        {
          query_embedding: queryEmbedding,
          user_language: preferredLanguage,
          match_threshold: 0.72,
          match_count: 4,
          topic_filter: null,
        }
      );
      sources = matchedSources ?? [];
    }

    const sourceText = sources
      .map((s: any, i: number) => `[${i + 1}] ${s.reference} — ${s.translated_text}`)
      .join("\n");

    // Build personalised system prompt
    const systemPrompt = buildSystemPrompt({
      checkin: checkin?.answers ?? {},
      cycle,
      sources: sourceText,
      preferredLanguage,
      firstName,
    });

    // Vendor-neutral generation ("standard" tier)
    const gen = await complete("standard", userQuestion, {
      system: systemPrompt, maxTokens: 280,
    });
    const response = gen.ok && gen.text
      ? gen.text
      : "Bismillah. I am here with you, Sister. Complete your check-in so I can guide you more personally.";

    // Log the response for audit
    await supabase.from("ai_coach_responses").insert({
      user_id: user.id,
      checkin_id: checkin?.id ?? null,
      response_type: messageType,
      prompt_context: { userQuestion, checkin: checkin?.answers ?? null, cycle, preferredLanguage },
      retrieved_sources: sources,
      ai_response: response,
      safety_status: "safe",
      ai_model: gen.provider_tier,
    });

    return json({ response, sources, safety_status: "safe" });

  } catch (err) {
    return json({ error: String(err) }, 500);
  }
});

function json(payload: unknown, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function inspectIntent(message: string): string {
  const text = message.toLowerCase();
  const fatwaTerms = ["fatwa","is it haram","is this haram","is it halal","is this halal","ruling on","is it a sin"];
  const emergencyTerms = ["heart attack","chest pain","bleeding heavily","emergency","overdose","can't breathe"];
  const crisisTerms = ["suicide","kill myself","end my life","hurt myself","self harm","self-harm","don't want to live","want to die","no reason to live"];
  if (crisisTerms.some((t) => text.includes(t))) return "mental_health_crisis";
  if (emergencyTerms.some((t) => text.includes(t))) return "medical_emergency";
  if (fatwaTerms.some((t) => text.includes(t))) return "fiqh_required";
  return "safe";
}

function fallbackResponse(type: string, country?: string): string {
  if (type === "mental_health_crisis") {
    // Gap 17: never a queue, never a wait. Human-reviewed template.
    // Region-aware immediate support; helplines verified at deploy time.
    const lines =
      country === "BD"
        ? "• Kaan Pete Roi emotional support line (Bangladesh)\n• Emergency services: 999"
        : "• Estijaba helpline: 800-HOPE (800 4673) (UAE)\n• Emergency services: 998 / 999";
    return (
      "Sister, what you are carrying right now matters, and you deserve immediate human support — more than I can give as an app.\n\n" +
      "Please reach out now:\n" + lines + "\n• Or someone you trust — a family member, a friend, your imam or a sister nearby.\n\n" +
      "You are not alone, and seeking help is an act of strength, not weakness. " +
      "A member of our human care team will also follow up with you. \u2764\uFE0F"
    );
  }
  if (type === "medical_emergency") {
    return "Sister, this may be urgent. Please contact local emergency services or go to the nearest hospital immediately. Afiyah AI cannot provide emergency medical care.";
  }
  if (type === "fiqh_required") {
    return "Sister, I can share general educational reminders, but I cannot issue fatwas or Islamic legal rulings. Please consult a qualified scholar for this specific matter.";
  }
  return "I want to answer carefully, but I do not have enough verified information for that. Please rephrase or ask a qualified expert.";
}

function buildRetrievalQuery(userQuestion: string, checkin: any, cycle: any): string {
  const spiritualEnergy = checkin?.spiritual_energy ?? 5;
  const mood = checkin?.mood ?? 3;
  const stress = checkin?.stress ?? 3;
  const isCycleActive = !!cycle?.is_active_bleeding;
  return `User question: ${userQuestion}\nSpiritual energy: ${spiritualEnergy}\nMood: ${mood}\nStress: ${stress}\nCycle active: ${isCycleActive}\nNeeded topics: dhikr, dua, gratitude, rest, wellness, reminders`;
}

function buildSystemPrompt({ checkin, cycle, sources, preferredLanguage, firstName }: any): string {
  const isCycleActive = !!cycle?.is_active_bleeding;

  return `You are Afiyah AI Coach — a gentle, faith-aligned wellness companion for Muslim women.

Sister's name: ${firstName}
Preferred language: ${preferredLanguage}

Rules:
- Give one warm, personal dashboard nudge based on her check-in data.
- Use ONLY the verified Islamic sources provided below. Do not invent citations.
- Do not issue fatwa, provide medical diagnosis, or give regulated financial advice.
- Keep response under 90 words.
- Tone: sisterly, dignified, calming, practical.
- Reply in the user's preferred language where possible.

Cycle-aware rule:
${isCycleActive
  ? "Sister has marked active bleeding. Do NOT suggest Salah or fasting tracking. Suggest dhikr, dua, Quran listening, rest, hydration, gentle movement, reflection, sadaqah, or journaling."
  : "Sister has not marked active bleeding. You may suggest Salah consistency, dhikr, dua, reflection, learning, rest, hydration, or sadaqah."
}

Sister's check-in data:
${JSON.stringify(checkin)}

Verified Islamic sources (use only these — do not invent):
${sources || "No matching approved source found. Give a general non-citation wellness nudge."}`;
}
