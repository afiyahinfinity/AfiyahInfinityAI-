# Changelog

## 1.0.0 — 5 July 2026

- Added AI service architecture and service catalogue.
- Added OpenAPI and JSON Schema contracts.
- Added Noor Guard deterministic safety middleware.
- Added Next.js server boundary.
- Included hardened Noor Agent and atomic action execution from Stage 1.
- Added provider-neutral model gateway.
- Added AI control-plane migration with idempotency, prompt versions, model routes and safety events.
- Added security, governance, deployment and incident-response documentation.
- Added unit and staging security test specifications.
