# Validation report

**Package:** Afiyah Backend v1.0.0  
**Date:** 5 July 2026

## Completed checks

- `npm install --package-lock-only` completed and produced a reproducible lockfile.
- `npm ci` completed with 223 packages installed in the validation environment.
- TypeScript strict typecheck passed with `tsc --noEmit`.
- Production TypeScript build passed with `tsc -p tsconfig.build.json`.
- Four Vitest files passed: 8 tests total.
- Authentication-header parsing tests passed.
- Environment validation and weak-secret rejection tests passed.
- Structured-log redaction tests passed.
- Resend/Svix missing-header and invalid-signature rejection tests passed.
- Package structure, JSON, OpenAPI YAML and migration-control checks passed.
- Python validation and secret-scanning scripts compiled.
- Shell smoke-test script passed syntax validation.
- High-signal secret scan passed.
- Migration 014 passed structural checks for transaction boundaries, RLS, protected search paths, restricted grants and idempotency failure handling.
- Runtime smoke test passed for `/health/live`.
- Runtime readiness test correctly returned HTTP 503 when the database control-plane table was unavailable.
- Final ZIP integrity test passed.

## Not executed in this packaging environment

- Migration 014 against the actual Afiyah staging Supabase project.
- Cross-user RLS and service-role permission tests against the real schema.
- End-to-end authenticated profile, wellness, Noor and webhook flows.
- Container build, because Docker was not installed in the packaging environment.
- Load, soak, failover and autoscaling tests.
- External penetration testing.

## Mandatory release gate

Do not deploy to production until every unchecked item in `docs/RELEASE_CHECKLIST.md` passes in staging and the schema-column mapping is confirmed against migrations 001–013.
