import { z } from 'zod';

const booleanFromString = z.enum(['true', 'false']).transform((value) => value === 'true');

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'staging', 'production']).default('development'),
  HOST: z.string().default('0.0.0.0'),
  PORT: z.coerce.number().int().min(1).max(65535).default(8080),
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  TRUST_PROXY: booleanFromString.default(false),
  CORS_ORIGINS: z.string().default('http://localhost:3000'),
  REQUEST_BODY_LIMIT_BYTES: z.coerce.number().int().positive().max(5_242_880).default(1_048_576),
  REQUEST_TIMEOUT_MS: z.coerce.number().int().positive().max(120_000).default(15_000),
  SUPABASE_URL: z.string().url(),
  SUPABASE_ANON_KEY: z.string().min(20),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(20),
  AI_SERVICES_BASE_URL: z.string().url(),
  AI_SERVICES_INTERNAL_TOKEN: z.string().min(24),
  AI_SERVICES_TIMEOUT_MS: z.coerce.number().int().positive().max(120_000).default(20_000),
  RESEND_WEBHOOK_SECRET: z.string().min(24),
  INTERNAL_CRON_SECRET: z.string().min(24),
  SENTRY_DSN: z.string().url().optional().or(z.literal('')),
  OTEL_EXPORTER_OTLP_ENDPOINT: z.string().url().optional().or(z.literal('')),
  APP_RELEASE: z.string().default('local')
});

export type Env = z.infer<typeof schema> & { corsOrigins: string[] };

export function loadEnv(source: NodeJS.ProcessEnv = process.env): Env {
  const parsed = schema.parse(source);
  return {
    ...parsed,
    corsOrigins: parsed.CORS_ORIGINS.split(',').map((item) => item.trim()).filter(Boolean)
  };
}
