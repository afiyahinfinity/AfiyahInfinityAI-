import type { SupabaseClient } from '@supabase/supabase-js';
import { sha256 } from '../lib/hash.js';
import { conflict } from '../lib/errors.js';

export type ClaimResult = { state: 'claimed' | 'replay' | 'processing'; status_code?: number; response_body?: unknown };

export class ApiControlRepository {
  constructor(private readonly admin: SupabaseClient) {}

  async claim(input: { key: string; userId: string; route: string; method: string; body: unknown; requestId: string }): Promise<ClaimResult> {
    const { data, error } = await this.admin.rpc('claim_backend_idempotency', {
      p_idempotency_key: input.key,
      p_user_id: input.userId,
      p_route: input.route,
      p_method: input.method,
      p_request_hash: sha256(input.body),
      p_request_id: input.requestId
    });
    if (error) throw new Error(`Idempotency claim failed: ${error.message}`);
    const result = (Array.isArray(data) ? data[0] : data) as (ClaimResult | { state: 'conflict' });
    if (result?.state === 'conflict') throw conflict('The idempotency key was already used for a different request.');
    return result;
  }

  async complete(input: { key: string; userId: string; statusCode: number; responseBody: unknown }): Promise<void> {
    const { error } = await this.admin.rpc('complete_backend_idempotency', {
      p_idempotency_key: input.key,
      p_user_id: input.userId,
      p_status_code: input.statusCode,
      p_response_body: input.responseBody
    });
    if (error) throw new Error(`Idempotency completion failed: ${error.message}`);
  }

  async fail(input: { key: string; userId: string; errorCode: string }): Promise<void> {
    const { error } = await this.admin.rpc('fail_backend_idempotency', {
      p_idempotency_key: input.key,
      p_user_id: input.userId,
      p_error_code: input.errorCode
    });
    if (error) throw new Error(`Idempotency failure write failed: ${error.message}`);
  }
}
