const REDACTED = '[REDACTED]';
const sensitiveKeys = /authorization|cookie|token|secret|password|api[_-]?key|service[_-]?role|document|national[_-]?id|passport|card[_-]?number/i;

export function redact(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(redact);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value as Record<string, unknown>).map(([key, child]) => [
    key,
    sensitiveKeys.test(key) ? REDACTED : redact(child)
  ]));
}
