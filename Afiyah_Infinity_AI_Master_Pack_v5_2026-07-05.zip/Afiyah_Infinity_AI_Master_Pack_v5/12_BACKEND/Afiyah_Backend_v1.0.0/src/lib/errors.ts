export class AppError extends Error {
  constructor(
    public readonly statusCode: number,
    public readonly code: string,
    message: string,
    public readonly details?: unknown
  ) {
    super(message);
    this.name = 'AppError';
  }
}

export const unauthorized = () => new AppError(401, 'UNAUTHORIZED', 'Authentication is required.');
export const forbidden = () => new AppError(403, 'FORBIDDEN', 'You are not permitted to perform this action.');
export const badRequest = (message: string, details?: unknown) => new AppError(400, 'BAD_REQUEST', message, details);
export const conflict = (message: string) => new AppError(409, 'CONFLICT', message);
export const dependencyUnavailable = (message: string) => new AppError(503, 'DEPENDENCY_UNAVAILABLE', message);
