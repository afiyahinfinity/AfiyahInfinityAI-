import { createHash } from 'node:crypto';
export function sha256(value: unknown): string {
  const body = typeof value === 'string' ? value : JSON.stringify(value ?? null);
  return createHash('sha256').update(body).digest('hex');
}
