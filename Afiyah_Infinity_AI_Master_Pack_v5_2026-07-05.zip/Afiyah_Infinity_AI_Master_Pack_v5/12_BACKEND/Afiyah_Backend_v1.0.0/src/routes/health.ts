import type { FastifyPluginAsync } from 'fastify';
import type { SupabaseClient } from '@supabase/supabase-js';
import type { Env } from '../config/env.js';

export const healthRoutes = (env: Env, admin: SupabaseClient): FastifyPluginAsync => async (app) => {
  app.get('/health/live', async () => ({ status: 'ok', release: env.APP_RELEASE }));
  app.get('/health/ready', async (_request, reply) => {
    const { data, error } = await admin.from('backend_runtime_settings').select('key,value').eq('key','backend_control_plane_version').maybeSingle();
    if (error || !data) return reply.status(503).send({ status: 'not_ready', dependency: 'database_control_plane' });
    return { status: 'ready', release: env.APP_RELEASE, controlPlane: data.value };
  });
};
