import type { FastifyPluginAsync } from 'fastify';
import { requireUser } from '../plugins/auth.js';
import { WellnessService } from '../services/wellness.service.js';
export const wellnessRoutes: FastifyPluginAsync = async (app) => {
  app.get('/v1/wellness/summary', async (request) => { requireUser(request); return new WellnessService(request.userDb, request.authUser.id).getSummary(); });
};
