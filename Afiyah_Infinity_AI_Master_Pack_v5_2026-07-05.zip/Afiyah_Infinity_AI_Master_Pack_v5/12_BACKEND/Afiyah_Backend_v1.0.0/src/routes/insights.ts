import type { FastifyPluginAsync } from 'fastify';
import { z } from 'zod';
import { requireUser } from '../plugins/auth.js';
import { InsightsService } from '../services/insights.service.js';
const querySchema = z.object({ category: z.string().trim().max(64).optional(), limit: z.coerce.number().int().min(1).max(50).default(20) });
export const insightRoutes: FastifyPluginAsync = async (app) => {
  app.get('/v1/insights', async (request) => { requireUser(request); return new InsightsService(request.userDb).list(querySchema.parse(request.query)); });
};
