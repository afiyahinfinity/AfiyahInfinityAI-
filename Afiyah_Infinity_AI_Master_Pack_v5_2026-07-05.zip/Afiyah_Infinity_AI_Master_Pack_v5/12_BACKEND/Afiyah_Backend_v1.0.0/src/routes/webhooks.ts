import type { FastifyPluginAsync } from 'fastify';
import { z } from 'zod';
import type { SupabaseClient } from '@supabase/supabase-js';
import type { Env } from '../config/env.js';
import { WebhookService, verifyResendWebhook } from '../services/webhook.service.js';
import { badRequest } from '../lib/errors.js';

const envelope = z.object({ id: z.string().min(1).max(200), type: z.string().min(1).max(120), created_at: z.string().optional(), data: z.unknown() });

export const webhookRoutes = (env: Env, admin: SupabaseClient): FastifyPluginAsync => async (app) => {
  const service = new WebhookService(admin);
  app.post('/v1/webhooks/resend', { config: { rawBody: true, rateLimit: { max: 60, timeWindow: '1 minute' } } }, async (request, reply) => {
    if (!request.rawBody) throw badRequest('Raw webhook body is unavailable.');
    const rawBody = typeof request.rawBody === 'string' ? request.rawBody : request.rawBody.toString('utf8');
    const verified = verifyResendWebhook(rawBody, {
      'svix-id': request.headers['svix-id'] as string | undefined,
      'svix-timestamp': request.headers['svix-timestamp'] as string | undefined,
      'svix-signature': request.headers['svix-signature'] as string | undefined
    }, env.RESEND_WEBHOOK_SECRET);
    const body = envelope.parse(verified);
    const result = await service.receive({ source: 'resend', externalId: body.id, eventType: body.type, payload: body });
    return reply.status(202).send({ accepted: true, result });
  });
};
