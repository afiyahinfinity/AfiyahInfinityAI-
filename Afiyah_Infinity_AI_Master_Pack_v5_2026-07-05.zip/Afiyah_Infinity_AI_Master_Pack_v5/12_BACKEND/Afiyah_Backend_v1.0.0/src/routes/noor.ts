import type { FastifyPluginAsync } from 'fastify';
import { z } from 'zod';
import type { SupabaseClient } from '@supabase/supabase-js';
import type { Env } from '../config/env.js';
import { requireUser, extractBearerToken } from '../plugins/auth.js';
import { badRequest, conflict } from '../lib/errors.js';
import { idempotencyKeySchema, uuidSchema } from '../schemas/common.js';
import { NoorService } from '../services/noor.service.js';
import { ApiControlRepository } from '../repositories/api-control.repository.js';

const messageSchema = z.object({ sessionId: uuidSchema, message: z.string().trim().min(1).max(4000), locale: z.enum(['en','ar','bn']).default('en'), context: z.record(z.string(), z.unknown()).optional() });
const decisionSchema = z.object({ decision: z.enum(['approve','reject']), reason: z.string().trim().max(500).optional() });

export const noorRoutes = (env: Env, admin: SupabaseClient): FastifyPluginAsync => async (app) => {
  const noor = new NoorService(env);
  const control = new ApiControlRepository(admin);

  app.post('/v1/noor/messages', async (request, reply) => {
    requireUser(request);
    const key = idempotencyKeySchema.safeParse(request.headers['idempotency-key']);
    if (!key.success) throw badRequest('A valid Idempotency-Key header is required.');
    const token = extractBearerToken(request.headers.authorization);
    if (!token) throw badRequest('Bearer token is missing.');
    const body = messageSchema.parse(request.body);
    const claim = await control.claim({ key:key.data,userId:request.authUser.id,route:'/v1/noor/messages',method:'POST',body,requestId:request.requestId });
    if (claim.state === 'replay') return reply.status(claim.status_code ?? 200).send(claim.response_body);
    if (claim.state === 'processing') throw conflict('This request is already processing.');
    try {
      const result = await noor.message({ userId: request.authUser.id, accessToken: token, idempotencyKey: key.data, requestId: request.requestId, body });
      await control.complete({ key:key.data,userId:request.authUser.id,statusCode:200,responseBody:result });
      return result;
    } catch (error) {
      await control.fail({ key:key.data,userId:request.authUser.id,errorCode:error instanceof Error ? error.name : 'UNKNOWN' }).catch(() => undefined);
      throw error;
    }
  });

  app.post('/v1/noor/actions/:proposalId/decision', async (request, reply) => {
    requireUser(request);
    const params = z.object({ proposalId: uuidSchema }).parse(request.params);
    const key = idempotencyKeySchema.safeParse(request.headers['idempotency-key']);
    if (!key.success) throw badRequest('A valid Idempotency-Key header is required.');
    const token = extractBearerToken(request.headers.authorization);
    if (!token) throw badRequest('Bearer token is missing.');
    const body = decisionSchema.parse(request.body);
    const route=`/v1/noor/actions/${params.proposalId}/decision`;
    const claim = await control.claim({ key:key.data,userId:request.authUser.id,route,method:'POST',body,requestId:request.requestId });
    if (claim.state === 'replay') return reply.status(claim.status_code ?? 200).send(claim.response_body);
    if (claim.state === 'processing') throw conflict('This decision is already processing.');
    try {
      const result = await noor.decide({ userId: request.authUser.id, accessToken: token, idempotencyKey: key.data, requestId: request.requestId, proposalId: params.proposalId, body });
      await control.complete({ key:key.data,userId:request.authUser.id,statusCode:200,responseBody:result });
      return result;
    } catch (error) {
      await control.fail({ key:key.data,userId:request.authUser.id,errorCode:error instanceof Error ? error.name : 'UNKNOWN' }).catch(() => undefined);
      throw error;
    }
  });
};
