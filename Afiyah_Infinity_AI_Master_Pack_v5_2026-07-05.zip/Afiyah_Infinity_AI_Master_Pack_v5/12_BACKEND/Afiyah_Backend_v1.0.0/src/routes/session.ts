import type { FastifyPluginAsync } from 'fastify';
import { requireUser } from '../plugins/auth.js';
export const sessionRoutes: FastifyPluginAsync = async (app) => {
  app.get('/v1/session', async (request) => {
    requireUser(request);
    return { user: { id: request.authUser.id, email: request.authUser.email ?? null, audience: request.authUser.aud }, requestId: request.requestId };
  });
};
