import type { FastifyPluginAsync } from 'fastify';
import { z } from 'zod';
import { requireUser } from '../plugins/auth.js';
import { ProfileService } from '../services/profile.service.js';

const updateSchema = z.object({ displayName: z.string().trim().min(1).max(80).optional(), timezone: z.string().trim().min(1).max(64).optional(), preferredLanguage: z.enum(['en','ar','bn']).optional() }).refine((value) => Object.keys(value).length > 0, 'At least one field is required.');

export const profileRoutes: FastifyPluginAsync = async (app) => {
  app.get('/v1/profile', async (request) => { requireUser(request); return new ProfileService(request.userDb, request.authUser.id).get(); });
  app.patch('/v1/profile', async (request) => { requireUser(request); return new ProfileService(request.userDb, request.authUser.id).update(updateSchema.parse(request.body)); });
};
