import type { SupabaseClient, User } from '@supabase/supabase-js';

declare module 'fastify' {
  interface FastifyRequest {
    requestId: string;
    authUser: User | null;
    userDb: SupabaseClient | null;
    rawBody?: string;
  }
}
export {};
