import { Webhook } from 'svix';
import type { SupabaseClient } from '@supabase/supabase-js';
import { sha256 } from '../lib/hash.js';
import { unauthorized } from '../lib/errors.js';

export function verifyResendWebhook(rawBody: string, headers: Record<string, string | undefined>, secret: string): unknown {
  const id = headers['svix-id'];
  const timestamp = headers['svix-timestamp'];
  const signature = headers['svix-signature'];
  if (!id || !timestamp || !signature) throw unauthorized();
  try {
    return new Webhook(secret).verify(rawBody, { 'svix-id': id, 'svix-timestamp': timestamp, 'svix-signature': signature });
  } catch {
    throw unauthorized();
  }
}

export class WebhookService {
  constructor(private readonly admin: SupabaseClient) {}
  async receive(input: { source: string; externalId: string; eventType: string; payload: unknown }) {
    const { data, error } = await this.admin.from('backend_webhook_receipts').upsert({ source: input.source, external_id: input.externalId, event_type: input.eventType, payload_hash: sha256(input.payload), status: 'received' }, { onConflict: 'source,external_id', ignoreDuplicates: true }).select('id,status').maybeSingle();
    if (error) throw new Error(error.message);
    return data ?? { duplicate: true };
  }
}
