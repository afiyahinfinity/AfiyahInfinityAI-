import type { SupabaseClient } from '@supabase/supabase-js';

export class WellnessService {
  constructor(private readonly db: SupabaseClient, private readonly userId: string) {}
  async getSummary() {
    const [score, checkins, streak] = await Promise.all([
      this.db.from('barakah_scores').select('composite_score,band,created_at').eq('sister_id', this.userId).order('created_at', { ascending: false }).limit(1).maybeSingle(),
      this.db.from('daily_checkins').select('id,date').eq('sister_id', this.userId).order('date', { ascending: false }).limit(7),
      this.db.rpc('current_streak', { p_user: this.userId })
    ]);
    return {
      barakah: score.data ?? null,
      recentCheckins: checkins.data ?? [],
      currentStreak: typeof streak.data === 'number' ? streak.data : 0,
      disclaimer: 'This summary supports reflection and education. It is not medical, legal, investment, or financial advice.'
    };
  }
}
