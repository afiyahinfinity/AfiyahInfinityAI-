import type { SupabaseClient } from '@supabase/supabase-js';
import { AppError } from '../lib/errors.js';

export class ProfileService {
  constructor(private readonly db: SupabaseClient, private readonly userId: string) {}

  async get() {
    const [profile, preferences] = await Promise.all([
      this.db.from('sisters').select('id,email,display_name,preferred_language,status,created_at').eq('id', this.userId).single(),
      this.db.from('user_preferences').select('timezone').eq('sister_id', this.userId).maybeSingle()
    ]);
    if (profile.error) throw new AppError(404, 'PROFILE_NOT_FOUND', 'Profile was not found.');
    return { ...profile.data, timezone: preferences.data?.timezone ?? 'Asia/Dubai' };
  }

  async update(input: { displayName?: string | undefined; timezone?: string | undefined; preferredLanguage?: string | undefined }) {
    const patch: Record<string, string> = {};
    if (input.displayName !== undefined) patch.display_name = input.displayName;
    if (input.preferredLanguage !== undefined) patch.preferred_language = input.preferredLanguage;
    if (Object.keys(patch).length > 0) {
      const { error } = await this.db.from('sisters').update(patch).eq('id', this.userId);
      if (error) throw new AppError(400, 'PROFILE_UPDATE_FAILED', 'Profile could not be updated.');
    }
    if (input.timezone !== undefined) {
      const { error } = await this.db.from('user_preferences').upsert({ sister_id: this.userId, timezone: input.timezone }, { onConflict: 'sister_id' });
      if (error) throw new AppError(400, 'PREFERENCES_UPDATE_FAILED', 'Preferences could not be updated.');
    }
    return this.get();
  }
}
