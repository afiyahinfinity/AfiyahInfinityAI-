import type { SupabaseClient } from '@supabase/supabase-js';

export class InsightsService {
  constructor(private readonly db: SupabaseClient) {}
  async list(input: { category?: string | undefined; limit: number }) {
    let query = this.db.from('educational_insights').select('id,title,summary,category,reading_minutes,published_at').eq('status', 'published').order('published_at', { ascending: false }).limit(input.limit);
    if (input.category) query = query.eq('category', input.category);
    const { data, error } = await query;
    if (error && error.code !== '42P01') throw new Error(error.message);
    return { items: data ?? [], disclaimer: 'Educational information only. No investment recommendation is provided.' };
  }
}
