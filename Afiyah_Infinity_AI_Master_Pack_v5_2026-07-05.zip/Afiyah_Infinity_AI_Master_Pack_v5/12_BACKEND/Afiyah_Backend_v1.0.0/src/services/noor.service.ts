import type { Env } from '../config/env.js';
import { dependencyUnavailable } from '../lib/errors.js';

export class NoorService {
  constructor(private readonly env: Env) {}

  private async call(path: string, init: RequestInit) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.env.AI_SERVICES_TIMEOUT_MS);
    try {
      const response = await fetch(`${this.env.AI_SERVICES_BASE_URL}${path}`, {
        ...init,
        signal: controller.signal,
        headers: { 'content-type': 'application/json', 'x-afiyah-internal-token': this.env.AI_SERVICES_INTERNAL_TOKEN, ...(init.headers ?? {}) }
      });
      const body = await response.json().catch(() => ({ error: { code: 'INVALID_DEPENDENCY_RESPONSE' } }));
      if (!response.ok) throw dependencyUnavailable('Noor services are temporarily unavailable.');
      return body;
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') throw dependencyUnavailable('Noor services timed out.');
      throw error;
    } finally { clearTimeout(timer); }
  }

  async message(input: { userId: string; accessToken: string; idempotencyKey: string; requestId: string; body: unknown }) {
    return this.call('/v1/noor/messages', { method: 'POST', body: JSON.stringify(input.body), headers: { authorization: `Bearer ${input.accessToken}`, 'idempotency-key': input.idempotencyKey, 'x-request-id': input.requestId, 'x-afiyah-user-id': input.userId } });
  }

  async decide(input: { userId: string; accessToken: string; idempotencyKey: string; requestId: string; proposalId: string; body: unknown }) {
    return this.call(`/v1/noor/actions/${encodeURIComponent(input.proposalId)}/decision`, { method: 'POST', body: JSON.stringify(input.body), headers: { authorization: `Bearer ${input.accessToken}`, 'idempotency-key': input.idempotencyKey, 'x-request-id': input.requestId, 'x-afiyah-user-id': input.userId } });
  }
}
