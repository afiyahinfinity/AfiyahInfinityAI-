import { randomUUID } from 'node:crypto';
import type { FastifyInstance } from 'fastify';

export async function installRequestContext(app: FastifyInstance): Promise<void> {
  app.decorateRequest('requestId', '');
  app.decorateRequest('authUser', null);
  app.decorateRequest('userDb', null);
  app.addHook('onRequest', async (request, reply) => {
    const incoming = request.headers['x-request-id'];
    request.requestId = typeof incoming === 'string' && incoming.length <= 128 ? incoming : randomUUID();
    reply.header('x-request-id', request.requestId);
  });
}
