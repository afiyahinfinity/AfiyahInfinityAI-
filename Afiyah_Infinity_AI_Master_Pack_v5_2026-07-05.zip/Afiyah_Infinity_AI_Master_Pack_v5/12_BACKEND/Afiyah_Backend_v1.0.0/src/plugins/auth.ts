import type { FastifyInstance, FastifyRequest } from 'fastify';
import type { Env } from '../config/env.js';
import { createAdminClient, createUserClient } from '../lib/supabase.js';
import { unauthorized } from '../lib/errors.js';

export function extractBearerToken(header: string | undefined): string | null {
  if (!header) return null;
  const match = /^Bearer\s+(.+)$/i.exec(header.trim());
  return match?.[1] ?? null;
}

export function requireUser(request: FastifyRequest): asserts request is FastifyRequest & { authUser: NonNullable<FastifyRequest['authUser']>; userDb: NonNullable<FastifyRequest['userDb']> } {
  if (!request.authUser || !request.userDb) throw unauthorized();
}

export async function installAuth(app: FastifyInstance, env: Env): Promise<void> {
  const admin = createAdminClient(env);
  app.addHook('preHandler', async (request) => {
    const token = extractBearerToken(request.headers.authorization);
    if (!token) return;
    const { data, error } = await admin.auth.getUser(token);
    if (error || !data.user) throw unauthorized();
    request.authUser = data.user;
    request.userDb = createUserClient(env, token);
  });
}
