import type { FastifyInstance } from 'fastify';
import type { SupabaseClient } from '@supabase/supabase-js';

export function installAudit(app: FastifyInstance, admin: SupabaseClient): void {
  app.addHook('onResponse', async (request, reply) => {
    if (request.url.startsWith('/health/')) return;
    const { error } = await admin.from('backend_api_audit_log').insert({
      request_id: request.requestId,
      user_id: request.authUser?.id ?? null,
      route: request.routeOptions.url ?? request.url.split('?')[0],
      method: request.method,
      status_code: reply.statusCode,
      event_type: 'request_completed',
      evidence: { ip_hash_recorded: false }
    });
    if (error) request.log.warn({ requestId: request.requestId, code: error.code }, 'Audit evidence write failed');
  });
}
