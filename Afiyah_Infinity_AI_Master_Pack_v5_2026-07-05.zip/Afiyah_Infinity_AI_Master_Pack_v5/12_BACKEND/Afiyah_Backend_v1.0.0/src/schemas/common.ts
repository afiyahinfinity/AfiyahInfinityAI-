import { z } from 'zod';
export const idempotencyKeySchema = z.string().min(16).max(128).regex(/^[A-Za-z0-9._:-]+$/);
export const uuidSchema = z.string().uuid();
export const paginationSchema = z.object({ limit: z.coerce.number().int().min(1).max(50).default(20) });
