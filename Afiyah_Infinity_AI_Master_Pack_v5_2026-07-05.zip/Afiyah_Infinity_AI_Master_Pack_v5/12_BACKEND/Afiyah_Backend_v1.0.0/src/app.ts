import Fastify from 'fastify';
import rawBody from 'fastify-raw-body';
import type { Env } from './config/env.js';
import { createAdminClient } from './lib/supabase.js';
import { installRequestContext } from './plugins/request-context.js';
import { installAuth } from './plugins/auth.js';
import { installSecurity } from './plugins/security.js';
import { installErrorHandler } from './plugins/error-handler.js';
import { installAudit } from './plugins/audit.js';
import { healthRoutes } from './routes/health.js';
import { sessionRoutes } from './routes/session.js';
import { profileRoutes } from './routes/profile.js';
import { wellnessRoutes } from './routes/wellness.js';
import { insightRoutes } from './routes/insights.js';
import { noorRoutes } from './routes/noor.js';
import { webhookRoutes } from './routes/webhooks.js';

export async function buildApp(env: Env) {
  const app = Fastify({
    trustProxy: env.TRUST_PROXY,
    bodyLimit: env.REQUEST_BODY_LIMIT_BYTES,
    requestTimeout: env.REQUEST_TIMEOUT_MS,
    logger: { level: env.LOG_LEVEL, redact: ['req.headers.authorization','req.headers.cookie','res.headers.set-cookie'] }
  });
  const admin = createAdminClient(env);
  await installRequestContext(app);
  await installSecurity(app, env);
  await app.register(rawBody, { field: 'rawBody', global: false, encoding: 'utf8', runFirst: true });
  await installAuth(app, env);
  installErrorHandler(app);
  installAudit(app, admin);
  await app.register(healthRoutes(env, admin));
  await app.register(sessionRoutes);
  await app.register(profileRoutes);
  await app.register(wellnessRoutes);
  await app.register(insightRoutes);
  await app.register(noorRoutes(env, admin));
  await app.register(webhookRoutes(env, admin));
  return app;
}
