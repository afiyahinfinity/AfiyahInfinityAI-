export default [
  { ignores: ['dist/**', 'coverage/**'] },
  {
    files: ['**/*.ts'],
    rules: {
      'no-console': 'error',
      'no-debugger': 'error',
      'no-eval': 'error'
    }
  }
];
