-- Afiyah Backend control plane
-- Apply only after migrations 001-013. Test in staging before production.

begin;

alter table public.sisters
  add column if not exists display_name text,
  add column if not exists preferred_language text not null default 'en';

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname='sisters_preferred_language_check'
      and conrelid='public.sisters'::regclass
  ) then
    alter table public.sisters
      add constraint sisters_preferred_language_check
      check (preferred_language in ('en','ar','bn')) not valid;
  end if;
end $$;

alter table public.sisters validate constraint sisters_preferred_language_check;

create table if not exists public.educational_insights (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  summary text not null,
  category text not null,
  reading_minutes integer not null default 3 check (reading_minutes between 1 and 60),
  status text not null default 'draft' check (status in ('draft','review','published','archived')),
  content_version text not null default '1.0',
  shariah_review_status text not null default 'pending' check (shariah_review_status in ('pending','approved','rejected','not_required')),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.educational_insights enable row level security;
drop policy if exists "authenticated reads published educational insights" on public.educational_insights;
create policy "authenticated reads published educational insights"
  on public.educational_insights for select to authenticated
  using (status='published' and shariah_review_status in ('approved','not_required'));
revoke all on public.educational_insights from anon;
grant select on public.educational_insights to authenticated;
grant all on public.educational_insights to service_role;

create table if not exists public.backend_idempotency_keys (
  id uuid primary key default gen_random_uuid(),
  idempotency_key text not null,
  user_id uuid not null references auth.users(id) on delete cascade,
  route text not null,
  method text not null check (method in ('POST','PUT','PATCH','DELETE')),
  request_hash text not null check (length(request_hash)=64),
  request_id text not null,
  state text not null default 'processing' check (state in ('processing','completed','failed')),
  status_code integer,
  response_body jsonb,
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  expires_at timestamptz not null default (now() + interval '24 hours'),
  unique (user_id, idempotency_key)
);

create table if not exists public.backend_api_audit_log (
  id bigint generated always as identity primary key,
  request_id text not null,
  user_id uuid references auth.users(id) on delete set null,
  route text not null,
  method text not null,
  status_code integer,
  event_type text not null,
  evidence jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.backend_webhook_receipts (
  id uuid primary key default gen_random_uuid(),
  source text not null,
  external_id text not null,
  event_type text not null,
  payload_hash text not null check (length(payload_hash)=64),
  status text not null default 'received' check (status in ('received','processing','completed','failed','ignored')),
  attempts integer not null default 0 check (attempts >= 0),
  last_error text,
  received_at timestamptz not null default now(),
  processed_at timestamptz,
  unique (source, external_id)
);

create table if not exists public.backend_runtime_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id) on delete set null
);

alter table public.backend_idempotency_keys enable row level security;
alter table public.backend_api_audit_log enable row level security;
alter table public.backend_webhook_receipts enable row level security;
alter table public.backend_runtime_settings enable row level security;

revoke all on public.backend_idempotency_keys from anon, authenticated;
revoke all on public.backend_api_audit_log from anon, authenticated;
revoke all on public.backend_webhook_receipts from anon, authenticated;
revoke all on public.backend_runtime_settings from anon, authenticated;

grant all on public.backend_idempotency_keys to service_role;
grant all on public.backend_api_audit_log to service_role;
grant all on public.backend_webhook_receipts to service_role;
grant select on public.backend_runtime_settings to service_role;

create or replace function public.claim_backend_idempotency(
  p_idempotency_key text,
  p_user_id uuid,
  p_route text,
  p_method text,
  p_request_hash text,
  p_request_id text
) returns table(state text, status_code integer, response_body jsonb)
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare existing public.backend_idempotency_keys%rowtype;
begin
  if p_user_id is null or p_idempotency_key is null or length(p_idempotency_key) < 16 then
    raise exception 'invalid idempotency claim';
  end if;
  select * into existing from public.backend_idempotency_keys
   where user_id=p_user_id and idempotency_key=p_idempotency_key
   for update;
  if found then
    if existing.request_hash <> p_request_hash or existing.route <> p_route or existing.method <> p_method then
      return query select 'conflict'::text, null::integer, null::jsonb;
    elsif existing.state='completed' then
      return query select 'replay'::text, existing.status_code, existing.response_body;
    elsif existing.state='failed' or existing.expires_at <= now() then
      update public.backend_idempotency_keys set state='processing', request_id=p_request_id, completed_at=null, status_code=null, response_body=null, expires_at=now()+interval '24 hours' where id=existing.id;
      return query select 'claimed'::text, null::integer, null::jsonb;
    else
      return query select 'processing'::text, null::integer, null::jsonb;
    end if;
    return;
  end if;
  insert into public.backend_idempotency_keys(idempotency_key,user_id,route,method,request_hash,request_id)
  values(p_idempotency_key,p_user_id,p_route,p_method,p_request_hash,p_request_id);
  return query select 'claimed'::text, null::integer, null::jsonb;
end;
$$;

create or replace function public.complete_backend_idempotency(
  p_idempotency_key text,
  p_user_id uuid,
  p_status_code integer,
  p_response_body jsonb
) returns void
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
begin
  update public.backend_idempotency_keys
     set state='completed', status_code=p_status_code, response_body=p_response_body,
         completed_at=now()
   where user_id=p_user_id and idempotency_key=p_idempotency_key and state='processing';
  if not found then raise exception 'idempotency record not claimable'; end if;
end;
$$;


create or replace function public.fail_backend_idempotency(
  p_idempotency_key text,
  p_user_id uuid,
  p_error_code text
) returns void
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
begin
  update public.backend_idempotency_keys
     set state='failed', status_code=503,
         response_body=jsonb_build_object('error',jsonb_build_object('code',left(coalesce(p_error_code,'DEPENDENCY_ERROR'),120))),
         completed_at=now()
   where user_id=p_user_id and idempotency_key=p_idempotency_key and state='processing';
end;
$$;

revoke all on function public.claim_backend_idempotency(text,uuid,text,text,text,text) from public, anon, authenticated;
revoke all on function public.complete_backend_idempotency(text,uuid,integer,jsonb) from public, anon, authenticated;
revoke all on function public.fail_backend_idempotency(text,uuid,text) from public, anon, authenticated;
grant execute on function public.claim_backend_idempotency(text,uuid,text,text,text,text) to service_role;
grant execute on function public.complete_backend_idempotency(text,uuid,integer,jsonb) to service_role;
grant execute on function public.fail_backend_idempotency(text,uuid,text) to service_role;

create or replace function public.prevent_backend_evidence_mutation() returns trigger
language plpgsql
security definer
set search_path = pg_catalog, public
as $$ begin raise exception 'backend evidence is append-only'; end; $$;
revoke all on function public.prevent_backend_evidence_mutation() from public, anon, authenticated;

drop trigger if exists backend_audit_immutable on public.backend_api_audit_log;
create trigger backend_audit_immutable before update or delete on public.backend_api_audit_log
for each row execute function public.prevent_backend_evidence_mutation();

insert into public.backend_runtime_settings(key,value)
values ('backend_control_plane_version','"1.0.0"'::jsonb)
on conflict (key) do update set value=excluded.value,updated_at=now();

commit;
