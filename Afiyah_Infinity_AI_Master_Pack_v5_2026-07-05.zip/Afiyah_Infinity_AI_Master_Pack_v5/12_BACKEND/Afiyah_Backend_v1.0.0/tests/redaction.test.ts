import { describe, expect, it } from 'vitest';
import { redact } from '../src/lib/redaction.js';
describe('redact', () => {
  it('removes nested secret values', () => expect(redact({ authorization:'Bearer x', nested:{ password:'x', safe:'ok' } })).toEqual({ authorization:'[REDACTED]', nested:{ password:'[REDACTED]', safe:'ok' } }));
});
