import { describe, expect, it } from 'vitest';
import { verifyResendWebhook } from '../src/services/webhook.service.js';
describe('verifyResendWebhook', () => {
  it('rejects requests missing Svix headers', () => expect(() => verifyResendWebhook('{}', {}, 'whsec_' + 's'.repeat(32))).toThrow());
  it('rejects invalid signatures', () => expect(() => verifyResendWebhook('{}', { 'svix-id':'msg_test','svix-timestamp':'1614265330','svix-signature':'v1,bad' }, 'whsec_' + 's'.repeat(32))).toThrow());
});
