import { describe, expect, it } from 'vitest';
import { extractBearerToken } from '../src/plugins/auth.js';
describe('extractBearerToken', () => {
  it('extracts a bearer token', () => expect(extractBearerToken('Bearer abc.def')).toBe('abc.def'));
  it('is case insensitive', () => expect(extractBearerToken('bearer token')).toBe('token'));
  it('rejects malformed headers', () => expect(extractBearerToken('Basic abc')).toBeNull());
});
