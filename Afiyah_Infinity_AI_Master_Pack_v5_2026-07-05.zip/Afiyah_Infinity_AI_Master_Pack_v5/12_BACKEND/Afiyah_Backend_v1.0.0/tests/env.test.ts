import { describe, expect, it } from 'vitest';
import { loadEnv } from '../src/config/env.js';
const base = { SUPABASE_URL:'https://example.supabase.co',SUPABASE_ANON_KEY:'a'.repeat(30),SUPABASE_SERVICE_ROLE_KEY:'s'.repeat(30),AI_SERVICES_BASE_URL:'https://ai.example.com',AI_SERVICES_INTERNAL_TOKEN:'i'.repeat(30),RESEND_WEBHOOK_SECRET:'r'.repeat(30),INTERNAL_CRON_SECRET:'c'.repeat(30) };
describe('loadEnv', () => {
  it('parses origins', () => expect(loadEnv({ ...base, CORS_ORIGINS:'https://a.example,https://b.example' }).corsOrigins).toEqual(['https://a.example','https://b.example']));
  it('rejects weak secrets', () => expect(() => loadEnv({ ...base, INTERNAL_CRON_SECRET:'short' })).toThrow());
});
