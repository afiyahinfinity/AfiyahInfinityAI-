# Changelog

## 1.0.0 — 2026-07-05

- Added Fastify/TypeScript BFF scaffold.
- Added Supabase token verification and RLS-preserving user client.
- Added profile, wellness, insights and Noor routes.
- Added idempotency, webhook receipts and append-only audit migration.
- Added security middleware, redaction, tests, Docker, CI and operational documentation.
