# Backend security baseline

- TLS only in staging/production.
- Strict CORS allowlist; no wildcard with credentials.
- Helmet security headers.
- Global and route-specific rate limits.
- Maximum request body size and request timeout.
- Zod validation at every public boundary.
- Idempotency for unsafe retries.
- User-scoped Supabase access preserving RLS.
- Append-only audit evidence.
- HMAC webhook verification and deduplication.
- Structured logging with field redaction.
- Container runs as non-root with a read-only filesystem.
- Secrets supplied by the platform secret manager, never source control.

## Mandatory production additions

- WAF/bot protection for public endpoints.
- Sentry or equivalent error monitoring with PII scrubbing.
- OpenTelemetry traces without prompt or personal-data bodies.
- Dependency and container scanning.
- Secret rotation drill.
- Penetration testing before public KYC or partner workflows.

## Email webhooks

Resend verification uses the raw request body plus `svix-id`, `svix-timestamp` and `svix-signature`. JSON re-serialization must not be used for signature verification.
