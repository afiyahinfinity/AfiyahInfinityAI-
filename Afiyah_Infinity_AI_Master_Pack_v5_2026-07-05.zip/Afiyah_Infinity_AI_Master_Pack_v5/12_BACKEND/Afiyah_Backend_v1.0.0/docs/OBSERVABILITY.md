# Observability

Metrics:
- request count, latency and error rate by route/status;
- auth failures and rate-limit rejections;
- Supabase and AI-services latency/error rate;
- idempotency replays/conflicts;
- webhook backlog and retry count;
- Noor safety fallback and escalation counts without storing raw sensitive prompts.

Alerts:
- readiness failure;
- sustained 5xx rate;
- authentication anomaly;
- webhook processing backlog;
- AI-service timeout spike;
- zero successful audit writes;
- migration/schema mismatch.
