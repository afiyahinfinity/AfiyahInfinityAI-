# Threat model

| Threat | Primary control |
|---|---|
| Stolen bearer token | short-lived sessions, revocation, secure storage, optional device attestation |
| Cross-user data access | user-scoped client plus PostgreSQL RLS |
| Service-role leakage | server-only secret manager, redacted logs, secret scanning |
| Duplicate consequential action | idempotency plus atomic Noor execution |
| Prompt injection | AI-services policy boundary; tools are allowlisted and server-owned |
| Webhook forgery/replay | HMAC verification and unique external event ID |
| PII in logs | structured redaction and telemetry payload allowlist |
| Resource exhaustion | body limits, timeouts, rate limits and autoscaling |
| Privilege escalation | roles loaded server-side; AAL2 for reviewers/admins |
