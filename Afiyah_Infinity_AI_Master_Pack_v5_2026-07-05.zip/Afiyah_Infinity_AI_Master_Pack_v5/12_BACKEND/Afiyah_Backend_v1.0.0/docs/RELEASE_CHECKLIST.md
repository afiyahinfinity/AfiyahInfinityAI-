# Backend release checklist

- [ ] `npm ci`, typecheck, tests, validation and build pass.
- [ ] Migration 014 applies cleanly after migrations 001–013.
- [ ] RLS tests prove cross-user access is denied.
- [ ] No service-role key appears in client bundles or logs.
- [ ] CORS allows only approved Afiyah domains.
- [ ] Auth rejects missing, expired and forged tokens.
- [ ] Noor requests require idempotency keys.
- [ ] Duplicate Noor decisions cannot execute twice.
- [ ] AI outage returns a safe failure without data loss or action execution.
- [ ] Webhook signature and replay tests pass.
- [ ] Health checks and graceful shutdown work.
- [ ] Secrets are stored in the deployment platform and rotation owners are assigned.
- [ ] Backup restore and rollback procedures are rehearsed.
- [ ] Legal, privacy, Shariah, security and product owners approve the release.
