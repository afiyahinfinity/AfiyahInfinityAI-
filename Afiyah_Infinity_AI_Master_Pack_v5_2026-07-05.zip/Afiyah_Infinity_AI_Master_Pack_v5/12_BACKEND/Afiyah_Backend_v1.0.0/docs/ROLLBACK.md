# Rollback

1. Stop traffic promotion and retain the previous immutable image.
2. Roll back the application image first; do not reverse a migration automatically.
3. Prefer forward-fix database migrations.
4. Disable AI with the platform kill switch if the incident involves Noor.
5. Preserve logs, request IDs and audit evidence.
6. Confirm idempotency records before replaying failed client requests.
7. Complete incident review before restoring normal deployment velocity.
