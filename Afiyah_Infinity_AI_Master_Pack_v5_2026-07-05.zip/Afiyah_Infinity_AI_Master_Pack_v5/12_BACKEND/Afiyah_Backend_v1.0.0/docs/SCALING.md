# Scaling and reliability

## Stateless API

The API is stateless. Scale horizontally behind a load balancer. Idempotency, webhook receipts and durable evidence are stored in PostgreSQL.

## Suggested stages

- **Pilot:** 1 staging instance; 2 production instances; low concurrency; manual observation.
- **Early growth:** autoscale 2–6 instances; connection pooling; queue long-running jobs.
- **Scale:** isolate webhook workers and notification jobs; add read replicas only after query evidence; partition high-volume audit tables; enforce per-tenant quotas.

## Performance controls

- Avoid service-role broad selects.
- Select only required columns.
- Add indexes based on production query plans, not guesses.
- Use PgBouncer/Supavisor-compatible connection patterns.
- Keep AI calls outside database transactions.
- Bound every outbound request with a timeout.
