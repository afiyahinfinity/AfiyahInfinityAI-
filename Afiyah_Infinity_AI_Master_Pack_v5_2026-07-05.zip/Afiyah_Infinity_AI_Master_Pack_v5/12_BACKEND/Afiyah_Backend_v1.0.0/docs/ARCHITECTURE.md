# Backend architecture

## Role

The backend is a thin, policy-enforcing BFF. PostgreSQL/Supabase remains the system of record. AI Services owns model routing and Noor safety policy. The backend owns client-facing authentication, request shaping, dependency isolation and operational controls.

## Trust boundaries

1. **Untrusted client:** web or Flutter application.
2. **Public backend:** validates bearer tokens and payloads.
3. **User-scoped database client:** forwards the user JWT; RLS decides access.
4. **Server-only administrative client:** used only for idempotency, webhooks and controlled audit records.
5. **AI Services:** internal service authenticated with a separate internal token and the user bearer token.

## Data-access rule

User-facing data must use `createUserClient()`. A new service-role query requires a documented reason, a narrow repository method, an audit event and a security review.

## Failure strategy

- Supabase auth failure: 401.
- RLS/data validation failure: 400/403/404 without leaking table details.
- AI timeout: 503 safe fallback; no action executes.
- Webhook retry: deduplicated using `(source, external_id)`.
- Duplicate mutation: replay stored response or reject a mismatched request hash.
