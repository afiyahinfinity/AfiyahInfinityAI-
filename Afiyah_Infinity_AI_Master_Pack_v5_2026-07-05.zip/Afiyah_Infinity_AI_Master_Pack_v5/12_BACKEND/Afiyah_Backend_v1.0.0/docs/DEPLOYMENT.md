# Deployment

## Staging order

1. Confirm migrations 001–013 are applied and tested.
2. Apply migration 014.
3. Create deployment secrets from `.env.example`.
4. Deploy AI Services and record its internal URL.
5. Build the backend container.
6. Deploy to a private/staging service.
7. Configure `api-staging.afiyahinfinityai.com` and TLS.
8. Run health, auth, RLS, idempotency, Noor and webhook tests.
9. Review logs for PII leakage.
10. Promote only after release-gate approval.

## Platform requirements

- Node.js 22-compatible container runtime.
- Minimum two instances for production availability.
- Health checks on `/health/live` and `/health/ready`.
- Graceful shutdown window of at least 30 seconds.
- Secret manager and immutable image deployment.
- Network access to Supabase and AI Services.

Do not deploy the service-role key to browser/serverless edge code that can be inspected by clients.
