# API contracts

Canonical machine-readable contract: `openapi/afiyah-backend.openapi.yaml`.

## Headers

- `Authorization: Bearer <Supabase access token>` for authenticated routes.
- `X-Request-ID` optional; the backend creates one when absent.
- `Idempotency-Key` mandatory for Noor messages, decisions and future financial mutations.

## Error envelope

```json
{
  "error": { "code": "VALIDATION_ERROR", "message": "Request validation failed.", "details": {} },
  "requestId": "uuid"
}
```

## Versioning

Breaking contracts require a new URL major version. Additive response fields are allowed. Removing fields or changing semantics requires `/v2`.
