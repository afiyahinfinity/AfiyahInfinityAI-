# Authentication and data access

- Clients obtain sessions from Supabase Auth.
- The backend verifies each bearer token with Supabase Auth.
- Every user-data request creates a Supabase client carrying that user's access token.
- PostgreSQL RLS remains the final authorization layer.
- The backend does not infer authorization from email domains, request body user IDs or client-supplied roles.
- Service-role keys exist only in the deployment secret manager.
- Admin routes require both authenticated identity and a server-side role lookup with AAL2 where applicable.
- Never log JWTs, refresh tokens, cookies or signed storage URLs.
