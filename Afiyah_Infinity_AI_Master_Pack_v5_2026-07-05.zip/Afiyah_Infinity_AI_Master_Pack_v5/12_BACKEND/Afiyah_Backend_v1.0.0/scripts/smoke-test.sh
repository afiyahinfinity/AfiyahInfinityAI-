#!/usr/bin/env sh
set -eu
BASE_URL="${BASE_URL:-http://localhost:8080}"
curl -fsS "$BASE_URL/health/live"
curl -fsS "$BASE_URL/health/ready"
echo "Smoke tests passed."
