from pathlib import Path
import json, sys, yaml
root=Path(__file__).resolve().parents[1]
required=['README.md','package.json','src/server.ts','src/app.ts','supabase/migrations/014_backend_control_plane.sql','openapi/afiyah-backend.openapi.yaml','docs/SECURITY.md','docs/DEPLOYMENT.md']
missing=[p for p in required if not (root/p).is_file()]
if missing: print('Missing required files:',missing); sys.exit(1)
json.loads((root/'package.json').read_text())
yaml.safe_load((root/'openapi/afiyah-backend.openapi.yaml').read_text())
sql=(root/'supabase/migrations/014_backend_control_plane.sql').read_text().lower()
for needle in ['security definer','set search_path','revoke all','enable row level security']:
 if needle not in sql: print('Migration missing:',needle); sys.exit(1)
print('Package structure, JSON, YAML and migration controls validated.')
