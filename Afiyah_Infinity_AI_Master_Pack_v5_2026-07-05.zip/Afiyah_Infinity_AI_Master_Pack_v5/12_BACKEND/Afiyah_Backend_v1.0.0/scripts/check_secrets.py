from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
patterns=[
 re.compile(r'(?i)(service[_-]?role[_-]?key|anthropic[_-]?api[_-]?key|openai[_-]?api[_-]?key)\s*[=:]\s*["\']?[A-Za-z0-9_-]{24,}'),
 re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
 re.compile(r'(?i)bearer\s+[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{20,}')
]
allow={'.env.example'}
fail=[]
for p in root.rglob('*'):
 if not p.is_file() or '.git' in p.parts or p.name in allow or p.suffix in {'.zip','.png','.jpg','.jpeg','.webp'}: continue
 try: text=p.read_text(encoding='utf-8')
 except Exception: continue
 for pattern in patterns:
  if pattern.search(text): fail.append(str(p.relative_to(root)))
if fail:
 print('Potential live secrets:', *sorted(set(fail)), sep='\n- '); sys.exit(1)
print('Secret scan passed.')
