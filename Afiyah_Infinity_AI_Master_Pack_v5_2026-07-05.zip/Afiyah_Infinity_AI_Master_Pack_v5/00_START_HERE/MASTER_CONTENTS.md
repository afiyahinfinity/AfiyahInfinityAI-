# Master contents

- `00_START_HERE/` — release notes, manifest and navigation.
- `01_SOURCE_ARCHIVES/` — original and generated source ZIPs with checksums.
- `02_CONSOLIDATED_CODE/` — reviewed source, baseline and Stage 1 remediation.
- `03_AUDIT_AND_REMEDIATION/` — technical audit and security instructions.
- `04_DEPLOYMENT_AND_GITHUB/` — repository and hosting runbooks.
- `05_ENVIRONMENT_KEYS/` — safe placeholder templates and secret register.
- `06_FIGMA_AND_DESIGN/` — Afiyah Design System and Figma handoff assets.
- `07_CHECKSUMS/` — integrity records.
- `08_CHAT_DELIVERABLES/` — key documents produced during the review.
- `09_REPOSITORY_OVERLAY_STAGE1/` — secured web repository overlay.
- `10_AI_SERVICES/` — AI architecture, Noor safety middleware, contracts and tests.
- `11_MOBILE_APP/` — Flutter source scaffold, mobile security and release documentation.
- `12_BACKEND/` — Fastify/TypeScript BFF, Supabase data access, migration 014, OpenAPI, CI, tests and operations documentation.
