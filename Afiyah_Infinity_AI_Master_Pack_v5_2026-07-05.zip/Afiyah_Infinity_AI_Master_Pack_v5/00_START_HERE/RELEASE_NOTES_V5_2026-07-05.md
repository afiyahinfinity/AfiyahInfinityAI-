# Master Pack v5 Release Notes

- Added Afiyah Backend v1.0.0.
- Added authenticated Fastify/TypeScript Backend-for-Frontend for web and mobile clients.
- Added Supabase bearer-token verification and RLS-preserving user-scoped database access.
- Added profile, wellness, educational insight and Noor proxy endpoints.
- Added migration 014 for idempotency, webhook deduplication, runtime settings, educational content and append-only audit evidence.
- Added Resend/Svix raw-body webhook verification.
- Added rate limiting, CORS, security headers, body/time limits, structured redaction and graceful shutdown.
- Added OpenAPI 3.1 contract, Dockerfile, GitHub Actions CI, unit tests and deployment/scaling/security runbooks.
- Added backend source ZIP and checksum to source archives.
