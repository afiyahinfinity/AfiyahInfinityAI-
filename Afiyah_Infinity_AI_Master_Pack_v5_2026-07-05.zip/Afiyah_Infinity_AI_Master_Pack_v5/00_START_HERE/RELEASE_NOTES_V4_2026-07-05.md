# Master Pack v4 Release Notes

- Added Afiyah Mobile App v1.0.0.
- Added Flutter 3.44 source scaffold for Android and iOS.
- Added Riverpod state management, GoRouter navigation and Material 3 brand theme.
- Added secure session storage, optional biometric re-entry and a single Dio API boundary.
- Added local Noor pre-flight guard and server-owned Noor integration.
- Added onboarding, dashboard, portfolio, insights, Noor and profile screens.
- Added accessibility, RTL, privacy, financial-boundary and threat-model documentation.
- Added Android/iOS platform bootstrap, release checklists, CI and automated test scaffold.
- Added mobile source ZIP and checksum to source archives.
