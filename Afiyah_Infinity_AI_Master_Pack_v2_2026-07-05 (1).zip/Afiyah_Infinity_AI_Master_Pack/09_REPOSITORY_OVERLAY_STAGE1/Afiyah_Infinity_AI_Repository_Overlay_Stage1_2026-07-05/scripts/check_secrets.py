#!/usr/bin/env python3
from pathlib import Path
import re, sys

root = Path(__file__).resolve().parents[1]
skip_names = {"MANIFEST_SHA256.txt"}
patterns = [
    ("private key", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("JWT-like secret", re.compile(r"\beyJ[A-Za-z0-9_-]{40,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\b")),
    ("OpenAI/provider key", re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b")),
    ("Resend key", re.compile(r"\bre_[A-Za-z0-9_-]{20,}\b")),
    ("GitHub token", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}\b")),
    ("AWS access key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
]
findings=[]
for path in root.rglob('*'):
    if not path.is_file() or path.name in skip_names or '.git' in path.parts:
        continue
    try:
        text=path.read_text(encoding='utf-8')
    except UnicodeDecodeError:
        continue
    for label, pat in patterns:
        for m in pat.finditer(text):
            line=text.count('\n',0,m.start())+1
            findings.append((path.relative_to(root),line,label,m.group(0)[:16]+'…'))
if findings:
    for p,line,label,sample in findings:
        print(f"{p}:{line}: potential {label}: {sample}")
    sys.exit(1)
print('High-signal secret scan passed.')
