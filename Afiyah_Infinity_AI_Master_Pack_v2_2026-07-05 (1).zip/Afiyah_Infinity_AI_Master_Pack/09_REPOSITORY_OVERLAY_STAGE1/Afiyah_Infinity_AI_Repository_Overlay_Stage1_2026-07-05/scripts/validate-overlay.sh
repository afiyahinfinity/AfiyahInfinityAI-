#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

required=(
  "app/noor/page.tsx"
  "supabase/migrations/006_admin_security_and_recovery.sql"
  "supabase/migrations/007_timezone_streaks_notifications.sql"
  "supabase/migrations/008_kyc_hardening.sql"
  "supabase/migrations/009_agentic_noor.sql"
  "supabase/migrations/010_payments.sql"
  "supabase/migrations/011_partner_governance.sql"
  "supabase/migrations/012_noor_atomic_security.sql"
  "supabase/functions/noor-agent/index.ts"
  "supabase/functions/agent-execute/index.ts"
  "tests/noor-security.test.ts"
)

for file in "${required[@]}"; do
  [[ -f "$file" ]] || { echo "Missing required file: $file" >&2; exit 1; }
done

# Prevent accidental inclusion of real environment files or private keys.
if find . -type f   ! -path './.git/*'   \( -name '.env' -o -name '.env.local' -o -name '.env.production' -o -name '*.pem' -o -name '*.p12' -o -name '*.pfx' \)   | grep -q .; then
  echo "Potential secret file found. Remove it before commit." >&2
  exit 1
fi

python3 scripts/check_secrets.py

echo "Overlay structure and basic secret checks passed."
