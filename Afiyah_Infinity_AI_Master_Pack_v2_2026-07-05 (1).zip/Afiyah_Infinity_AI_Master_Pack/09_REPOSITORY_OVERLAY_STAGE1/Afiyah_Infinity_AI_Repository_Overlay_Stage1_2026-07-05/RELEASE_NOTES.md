# Release Notes — Stage 1 Repository Overlay

## Added

- clean repository-aligned tree for `afiyahinfinity/mtbdiaries1-afiyah-infinity`;
- authoritative Noor Stage 1 replacements;
- migrations 006–012 without duplicate migration numbering;
- environment and Supabase secret templates;
- merge map, deployment runbook, production blockers and security checklist;
- Figma handoff status plus implementation-reference brand tokens;
- package validation and secret-scanning scripts;
- per-file SHA-256 manifest.

## Security changes

- verifies Noor session ownership before service-role reads/writes;
- enforces session/sister consistency through database constraints;
- performs decision and execution atomically with row locking;
- makes retries idempotent;
- prevents direct user mutation of action lifecycle state;
- validates proposed action payloads;
- restricts Edge Function browser origins;
- hardens privileged database functions and grants.

## Not included

- live credentials;
- migrations 001–005;
- the full existing Next.js application root;
- a genuine Figma `.fig` file;
- regulated payment/KYC partner integrations;
- the obsolete standalone demo or unauthenticated placeholder Noor API route.
