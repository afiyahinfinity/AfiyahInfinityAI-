# Production Blockers

The release must remain in staging until every item below is resolved.

1. **Base schema available:** migrations 001–005, or a verified equivalent schema, exist and match the tables/columns referenced by 006–012.
2. **Real application root available:** the target repo contains its real `package.json`, Next.js configuration, layout, styles and existing routes.
3. **Hosting source of truth confirmed:** choose and document Hostinger Node/Git or Vercel; do not allow two independent production deployment pipelines.
4. **Staging migration succeeds:** 006–012 apply cleanly to a production-like staging database.
5. **RLS/security tests pass:** cross-user access, direct status mutation and concurrent execution tests are green.
6. **No real identity documents in staging.**
7. **Legal texts live:** Privacy Policy, Terms, medical/AI/Shariah disclaimers and cycle-consent text are approved.
8. **Human governance ready:** second reviewer has NDA and TOTP; the Islamic knowledge-base approver is named.
9. **Crisis resources verified:** regional helplines and emergency numbers are checked immediately before launch.
10. **Payment/KYC integrations remain gated:** visual prototypes must not be presented as active regulated services until licensed partners and webhooks are configured.
11. **Backup restore drill completed:** the JSONL export is not treated as the sole production backup.
12. **Figma handoff incomplete:** no genuine editable Figma file is included; UI fidelity must be reviewed against the actual design source before a design-signoff release.
