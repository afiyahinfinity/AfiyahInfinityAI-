# Expected Existing Project Dependencies

This overlay does not replace the repository's package manifest. The existing application should provide compatible versions of:

- `next` (the source documents target Next.js 14 App Router)
- `react` and `react-dom`
- `@supabase/supabase-js`
- `@supabase/auth-helpers-nextjs`
- `typescript`
- `vitest`
- `@playwright/test` for the broader release suite

Before merging, assess whether the repository has migrated from `@supabase/auth-helpers-nextjs` to `@supabase/ssr`. If it has, adapt the supplied pages and middleware rather than adding the older helper package.
