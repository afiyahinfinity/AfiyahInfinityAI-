# Staging-to-Production Deployment Runbook

## 1. Branch and backup

- Branch: `security/noor-stage1-remediation`
- Record current application commit and Supabase migration head.
- Create a database backup/rollback point.
- Set `AI_ENABLED=false` for the first staging deployment.

## 2. Preflight

```bash
bash scripts/validate-overlay.sh
cp .env.example .env.local
cp .env.test.example .env.test.local
```

Merge this overlay into the existing application. Install missing dependencies in the existing project rather than replacing its package manifest. Expected packages include Next.js/React, `@supabase/supabase-js`, `@supabase/auth-helpers-nextjs`, Vitest and Playwright where already used.

## 3. Database

Confirm migrations 001–005 or their equivalent. Then apply 006–012 to **staging** through the repository's normal migration pipeline.

```bash
supabase link --project-ref "$AFIYAH_STAGING_PROJECT_REF"
supabase db push
```

Stop immediately on any missing relation, missing column, policy conflict or failed function definition. Use a new patch migration; never edit a migration already applied to production.

## 4. Edge Functions

Deploy shared gateway-dependent functions after secrets are set:

```bash
supabase functions deploy ai-identity-check --project-ref "$AFIYAH_STAGING_PROJECT_REF"
supabase functions deploy id-document-check --project-ref "$AFIYAH_STAGING_PROJECT_REF"
supabase functions deploy barakah-baseline --project-ref "$AFIYAH_STAGING_PROJECT_REF"
supabase functions deploy coach-response --project-ref "$AFIYAH_STAGING_PROJECT_REF"
supabase functions deploy noor-agent --project-ref "$AFIYAH_STAGING_PROJECT_REF"
supabase functions deploy agent-execute --project-ref "$AFIYAH_STAGING_PROJECT_REF"
supabase functions deploy nightly-backup --project-ref "$AFIYAH_STAGING_PROJECT_REF"
```

## 5. Tests

```bash
pnpm vitest run tests/rls.test.ts tests/noor-security.test.ts
pnpm lint
pnpm typecheck
pnpm build
```

Required Noor evidence:

- another sister's session returns `404 session_not_found`;
- mismatched session/sister writes fail;
- browser/user cannot directly mark actions approved or executed;
- two concurrent approvals create one domain write and one execution log;
- declined actions create no domain write;
- retries return the stored terminal result;
- `AI_ENABLED=false` preserves safe app behaviour.

## 6. Frontend staging

Deploy to one staging hostname. Test:

- signup and email verification;
- password reset;
- KYC status flow using dummy documents only;
- Noor new session, proposal, decline, approve and retry;
- membership page without live payment claims;
- partner governance access control;
- admin TOTP/AAL2 gate.

## 7. Production promotion

Only after signoff:

1. back up production;
2. apply migrations through the approved pipeline;
3. deploy functions;
4. deploy frontend;
5. keep AI disabled until smoke tests pass;
6. enable AI and monitor Edge Function, database, auth and email logs;
7. verify `agent_action_execution_log`, audit-chain checks and error rates.

## Rollback

Prefer forward-fix migrations. For application rollback, redeploy the previous commit. For a severe Noor incident, set `AI_ENABLED=false` immediately; do not disable RLS or bypass the atomic execution RPC.
