# Keys and Secrets

## Rules

- Never paste live keys into GitHub, documentation, screenshots, chat exports or ZIP archives.
- Store frontend secrets in the selected hosting provider's encrypted environment settings.
- Store Edge Function secrets with `supabase secrets set`.
- Use separate staging and production credentials.
- Rotate any credential that was ever pasted into a public place.
- Keep `SUPABASE_SERVICE_ROLE_KEY` server-side only. It bypasses RLS.

## Browser-safe

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `NEXT_PUBLIC_APP_ENV`

The anon key is public by design but remains safe only when RLS is correct.

## Server/Edge only

- `SUPABASE_SERVICE_ROLE_KEY`
- `LLM_API_KEY`
- `EMBED_API_KEY`
- `RESEND_API_KEY`
- `CRON_SECRET`
- `SYSTEM_ADMIN_ID`

## Configuration values

- `AI_ENABLED`
- `ALLOWED_ORIGINS`
- `LLM_PROVIDER`
- `LLM_BASE_URL`
- `LLM_MODEL_FAST`
- `LLM_MODEL_STANDARD`
- `LLM_CONFIG_VERSION`
- `EMBED_BASE_URL`
- `EMBED_MODEL`
- `FOUNDER_EMAIL`
- `APP_BASE_URL`

## Recommended setup command pattern

```bash
supabase secrets set \
  AI_ENABLED=false \
  ALLOWED_ORIGINS="https://staging.afiyahinfinityai.com,https://afiyahinfinityai.com,https://www.afiyahinfinityai.com" \
  LLM_PROVIDER="anthropic" \
  LLM_API_KEY="<set-in-terminal>" \
  LLM_MODEL_FAST="<model-id>" \
  LLM_MODEL_STANDARD="<model-id>" \
  LLM_CONFIG_VERSION="v1" \
  RESEND_API_KEY="<set-in-terminal>" \
  CRON_SECRET="<random-secret>" \
  FOUNDER_EMAIL="info@afiyahinfinity.com" \
  SYSTEM_ADMIN_ID="<uuid>" \
  --project-ref "$AFIYAH_STAGING_PROJECT_REF"
```

Do not save the completed command in shell history on a shared machine. Prefer the provider dashboard or a protected CI secret store.
