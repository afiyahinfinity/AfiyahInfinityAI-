# Figma and Design Handoff Status

No genuine Figma design URL, file key or exported `.fig` file was supplied in the source archives used to create this overlay. Therefore this package does **not** claim to contain an editable Figma design.

Included under `design/tokens/` are documented Afiyah brand tokens for implementation reference. They are not a substitute for a component library, responsive screen specifications, interaction states or developer-mode measurements.

Before design signoff, obtain or create the editable Figma file with:

- desktop, tablet and mobile frames;
- authentication, onboarding, dashboard, Noor, KYC, membership and partner screens;
- components and variants for inputs, buttons, cards, alerts, modals and navigation;
- loading, empty, error, disabled, success and permission-denied states;
- typography, colour, spacing, radius, elevation and icon variables;
- accessibility annotations and minimum contrast checks;
- Code Connect or clear component-to-code mapping.
