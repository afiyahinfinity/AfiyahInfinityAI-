# Migration Order

The files in this overlay begin at migration 006. They depend on the founder's existing core schema and Sprint 1 migrations 001–005.

| Order | File | Purpose |
|---:|---|---|
| 006 | `006_admin_security_and_recovery.sql` | admin security and recovery controls |
| 007 | `007_timezone_streaks_notifications.sql` | local-date streak and notification support |
| 008 | `008_kyc_hardening.sql` | KYC state machine and AML/PEP fields |
| 009 | `009_agentic_noor.sql` | Noor sessions, messages, actions and registry |
| 010 | `010_payments.sql` | plan, subscription and payment records |
| 011 | `011_partner_governance.sql` | rulings, risk register and partner governance |
| 012 | `012_noor_atomic_security.sql` | ownership constraints, atomic execution and function hardening |

Never renumber an already-applied migration. If the target repository already uses any of these numbers for different changes, create a reconciliation plan and new forward-only migration numbers.
