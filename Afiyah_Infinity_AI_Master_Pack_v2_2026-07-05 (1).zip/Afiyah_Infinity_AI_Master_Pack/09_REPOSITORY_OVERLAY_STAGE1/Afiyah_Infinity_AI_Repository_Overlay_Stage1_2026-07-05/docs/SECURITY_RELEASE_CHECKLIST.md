# Security Release Checklist

## Repository

- [ ] Branch protection enabled
- [ ] Pull request reviewed by a second technical reviewer
- [ ] No `.env` or credentials committed
- [ ] Secret scan clean
- [ ] `integration-patches/signup_page_PATCHED.tsx` merged manually

## Database

- [ ] Base schema 001–005 verified
- [ ] Migrations 006–012 reviewed and applied to staging
- [ ] RLS enabled on every user-sensitive table
- [ ] `SECURITY DEFINER` grants inspected
- [ ] Composite session/sister constraints present
- [ ] Proposal immutability trigger present
- [ ] Execution log append-only protection present

## Noor

- [ ] Cross-session test passes
- [ ] Cross-user RPC tests pass
- [ ] Direct status update blocked
- [ ] Concurrent approval test is idempotent
- [ ] Decline creates no write
- [ ] Payload schema validation rejects malformed actions
- [ ] Allowed origins restricted
- [ ] AI kill switch tested

## Operations

- [ ] Database backup and restore drill complete
- [ ] Edge Function monitoring enabled
- [ ] DNS/SSL verified
- [ ] SPF, DKIM and DMARC pass
- [ ] Founder and reviewer TOTP enabled
- [ ] Crisis resources verified
- [ ] Legal/governance signoff recorded
