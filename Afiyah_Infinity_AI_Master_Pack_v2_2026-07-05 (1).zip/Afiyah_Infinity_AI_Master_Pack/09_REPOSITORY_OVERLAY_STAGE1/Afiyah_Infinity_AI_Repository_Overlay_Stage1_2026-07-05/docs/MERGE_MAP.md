# Merge Map

## Replace these existing files

- `app/noor/page.tsx`
- `supabase/functions/noor-agent/index.ts`
- `supabase/functions/agent-execute/index.ts`

The versions in this overlay are the Stage 1 security-remediated versions.

## Add if absent; review before replacing if already customised

- `app/auth/reset-password/page.tsx`
- `app/auth/update-password/page.tsx`
- `app/kyc/page.tsx`
- `app/membership/page.tsx`
- `app/partner/governance/page.tsx`
- `middleware.ts`
- `supabase/functions/_shared/llm-gateway.ts`
- `supabase/functions/ai-identity-check/index.ts`
- `supabase/functions/barakah-baseline/index.ts`
- `supabase/functions/coach-response/index.ts`
- `supabase/functions/id-document-check/index.ts`
- `supabase/functions/nightly-backup/index.ts`
- `tests/rls.test.ts`
- `tests/noor-security.test.ts`

## Apply in numerical order after confirming migrations 001–005

- `006_admin_security_and_recovery.sql`
- `007_timezone_streaks_notifications.sql`
- `008_kyc_hardening.sql`
- `009_agentic_noor.sql`
- `010_payments.sql`
- `011_partner_governance.sql`
- `012_noor_atomic_security.sql`

## Manual integration only

`integration-patches/signup_page_PATCHED.tsx` is a patch reference. Diff its 18+ attestation and consent changes into the repository's actual signup route. Do not copy it blindly to `app/`.

## Deliberately excluded from the deploy tree

- standalone demo files;
- unauthenticated placeholder `app/api/noor/route.ts`;
- duplicate/obsolete original Noor function, execute function and page;
- the draft `012_security_hardening.sql`, because the release already has an authoritative migration 012;
- source ZIPs and duplicated audit packs.
