## Purpose

Stage 1 Afiyah remediation / integration.

## Evidence

- [ ] Migrations reviewed
- [ ] RLS tests pass on staging
- [ ] Noor security tests pass on staging
- [ ] Lint/typecheck/build pass
- [ ] No secrets committed
- [ ] Backup/rollback point recorded
- [ ] Product/legal/governance signoff attached where applicable

## Deployment impact

- Database migrations:
- Edge Functions:
- Frontend routes:
- Environment variables:
- Rollback commit:
