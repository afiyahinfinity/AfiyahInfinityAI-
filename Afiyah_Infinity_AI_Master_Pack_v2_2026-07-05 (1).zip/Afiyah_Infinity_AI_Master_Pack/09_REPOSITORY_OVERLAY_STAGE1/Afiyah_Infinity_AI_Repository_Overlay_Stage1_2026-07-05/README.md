# Afiyah Infinity AI — Stage 1 Repository Overlay

**Target repository:** `afiyahinfinity/mtbdiaries1-afiyah-infinity`  
**Release:** 2026-07-05  
**Purpose:** merge the reviewed Sprint 1 features and the hardened Noor security remediation into the existing private Next.js/Supabase application.

## Read this first

This archive is a **repository overlay**, not a complete standalone application. It intentionally does not invent the missing project root or base schema. Before copying it into the repository, confirm that the target branch already contains:

- the real Next.js root (`package.json`, `app/layout.tsx`, global styles and project configuration);
- Supabase migrations **001–005** or a production-equivalent base schema;
- the existing signup page into which `integration-patches/signup_page_PATCHED.tsx` will be manually merged;
- staging and production Supabase projects;
- an authenticated deployment connection for the selected frontend host.

Do not deploy migrations 006–012 against an empty database.

## What this overlay contains

- Next.js pages for authentication, KYC, membership, Noor and partner governance;
- middleware with the admin AAL2/TOTP gate;
- Supabase migrations 006–012;
- vendor-neutral AI gateway and reviewed Edge Functions;
- hardened Noor session ownership and atomic action execution;
- RLS and Noor security tests;
- environment templates, release checklist, deployment runbook and design-token handoff.

## Safe merge sequence

1. Create branch `security/noor-stage1-remediation` from the current protected development branch.
2. Read `docs/MERGE_MAP.md` and `docs/PRODUCTION_BLOCKERS.md`.
3. Copy the overlay into the repository **without overwriting unrelated project files**.
4. Manually merge the signup attestation patch.
5. Set secrets from the templates; never commit real values.
6. Apply migrations 006–012 to staging in order.
7. Deploy the Edge Functions listed in `docs/DEPLOYMENT_RUNBOOK.md`.
8. Run RLS, Noor security, build and smoke tests.
9. Promote only after the release checklist is signed off.

## Security posture

- Noor caller-supplied session IDs are ownership-checked.
- Session/message/action ownership is also enforced at database level.
- Approval and execution are row-locked, atomic and idempotent.
- Proposal fields and execution evidence are immutable.
- privileged functions use restricted grants and protected search paths.
- AI can be disabled with `AI_ENABLED=false` without blocking core data capture.

## Important exclusions

The older browser-exposed/placeholder Noor route and the standalone demo were deliberately excluded. The original security-hardening draft that also used migration number `012` was excluded to prevent a migration collision. The authoritative Stage 1 migration is:

`supabase/migrations/012_noor_atomic_security.sql`

A genuine `.fig` file was not supplied. The `design/` folder contains documented brand tokens and a Figma handoff checklist, not a fabricated Figma export.
