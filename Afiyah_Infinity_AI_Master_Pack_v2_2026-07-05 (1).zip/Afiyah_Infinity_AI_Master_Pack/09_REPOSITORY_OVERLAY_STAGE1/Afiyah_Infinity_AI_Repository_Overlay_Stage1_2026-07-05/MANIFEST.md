# File Manifest

Total listed files: 50

| Path | Bytes | SHA-256 |
|---|---:|---|
| `.env.example` | 433 | `f87724b85f3ece4c89f5e010f5b8cc56384794635d5dccaa4351931cbe83acab` |
| `.env.test.example` | 238 | `8ae5f734e613647ff610ecf8650c2613ae53eb54b91836064218898d1d7de67a` |
| `.github/pull_request_template.md` | 456 | `ad4bc4ec74d8873b7306c0610f02baa8a07a70e8b4887df225c146bf8b7b5a88` |
| `.gitignore` | 332 | `ae963a704ad304f1e3ea81ac866e6aadec06594ecd7ef79eefc41dcfc584b5f5` |
| `README.md` | 2998 | `1e533d4246c383085789ced6cee47288e9713a3484810fb5d2e11171ae46a072` |
| `RELEASE_NOTES.md` | 1217 | `f3d6f7e1e7388f235696e1907a26473a9b7c9bbfd98ef2e4033f310e89457a36` |
| `VALIDATION_REPORT.md` | 1060 | `298749a592f78a8f943281c6b389d49c162ea6824c80dda4e166cd9f06021747` |
| `app/auth/reset-password/page.tsx` | 2198 | `e26bbc8bccc7ee67844ce87d1c5ac835b3472a685a6c945e18969d825126a04f` |
| `app/auth/update-password/page.tsx` | 2515 | `d87a0e894909fe01051452ca85205ed7fa74b71c3696cc4e1480febc7ba5c9bd` |
| `app/kyc/page.tsx` | 3288 | `1eafc0db3a7263e2c87518bb486f4d2678f8d2dd36c158417cd3fb483047839f` |
| `app/membership/page.tsx` | 4046 | `bf6b2cb67e28d9d668d64d29baf76f884d62de1cd869d89e3e4c1637b409cc6f` |
| `app/noor/page.tsx` | 7082 | `dc7f78384e02d68d13f96b1cfe45c45ea439c3ce05444fcaf3efef30b579c83c` |
| `app/partner/governance/page.tsx` | 6019 | `dab3fd99ec0c9cb86ce3c2336112b13acf486fa80c7cd09f94bb65bb8572ea9c` |
| `design/tokens/afiyah-brand.css` | 397 | `730d593d86ecd9487105ce3cc1a2a46a2104ea9633b8c04a749f2b3ed6c7f824` |
| `design/tokens/afiyah-brand.tokens.json` | 916 | `2669ff71f743a9cf6e7fc11cd5dfe40186b51328022ed8fd7bbdf26fa5f5859a` |
| `docs/DEPENDENCIES_REQUIRED.md` | 609 | `daf29a782a98dab9309ae0503bc4c69b0dcf19ee899e43b2fc63b4646b65f6fb` |
| `docs/DEPLOYMENT_RUNBOOK.md` | 3259 | `92d05e4c7177d29da4d993500b7c99267f0e69f87379ec987157dcc97cbf65ac` |
| `docs/FIGMA_HANDOFF.md` | 1003 | `d9bdde558a422784478ea66303acc73f8b9ec1c589fd4d2e8084b9cd7d2efe62` |
| `docs/KEYS_AND_SECRETS.md` | 1720 | `a23d9629895fd225102c97faa9f66abc72b44f25a162edc77c05caa4fd232c93` |
| `docs/MERGE_MAP.md` | 1674 | `e770617f2c85475cace2b682a825e78e3e81f83bbcd4a0f38b300314849a5409` |
| `docs/MIGRATION_ORDER.md` | 994 | `d346b158f45107b89502d37d819ceda702fb8f48031fca4eeeb574ce1fe1c2ce` |
| `docs/PRODUCTION_BLOCKERS.md` | 1589 | `f0495449b61f8733da34de62a73dfbe474b3ae5f5d80a5cb858e256d36f52767` |
| `docs/SECURITY_RELEASE_CHECKLIST.md` | 1189 | `39a0f1ba701f038dca556eeb656856af0b6f15c6335dca617f96b4265380826b` |
| `docs/audit/AFIYAH_PACK_REVIEW.md` | 8777 | `3d93e6cc4ca22300dd82302eb65eba9b4bdd53bc11b3a5a4b0577336fdd9336a` |
| `docs/source/README_MERGE.md` | 3523 | `3e4b6d64d763dc0065d825fd85f209e8dbb5143bf3bd82c1a6411d9c7353f5b1` |
| `docs/source/README_NEXT_STEPS.md` | 2024 | `0366cca295c65006146fe9b7f20041c1beef89fe5d2a61f6a7a9b9de44ef8190` |
| `docs/source/README_STAGE1_DEPLOYMENT.md` | 4450 | `103ff23c8dac38fe012d709bd731f3147f91acecfadf5e63dc995275e329102d` |
| `integration-patches/signup_page_PATCHED.tsx` | 11055 | `a484b9b82f2b54d0656874e9f9a1ec756b3b08c63a71ebc2e2f9ae8d00dcbbfa` |
| `middleware.ts` | 1465 | `eadd96c1cb07cb24f015705f3cd5846f619f0aa23168e99aab8920abdd8b6025` |
| `scripts/__pycache__/check_secrets.cpython-313.pyc` | 2323 | `f1837546370a0763586447e210a3b118162ebc4a97c514bfe9dbd8470fec29ce` |
| `scripts/check_secrets.py` | 1228 | `8c63b54b77d7da0588290114ee9c979d93c808527509096dbe3d3bbb3fb641c2` |
| `scripts/validate-overlay.sh` | 1162 | `7131e1a03f5ec93240b23fb3df2a1ead93a3d7914b281d177f7e1124025d24e8` |
| `supabase/.env.functions.example` | 871 | `30ed6cb85f888b5f460d08b7ce9a821ab509837f4e8fbfacab9883796dfc8ae4` |
| `supabase/functions/_shared/llm-gateway.ts` | 11326 | `4af7cd7149e164e1131e5a1ab2d77f46ecbd5faecbcf282303db00cd486ca42d` |
| `supabase/functions/agent-execute/index.ts` | 3334 | `f9fa0fdb5c9ce37e7d25e50aabccc7877e35d3b2bb1239a611dd292a8ef0eff4` |
| `supabase/functions/ai-identity-check/index.ts` | 5472 | `8225a5d594319c6756ee5b7fbfa6081a69a7c38603663ff3e674ead69952eedb` |
| `supabase/functions/barakah-baseline/index.ts` | 9493 | `9cef158f97382e039f32575e9bccb104c917bcda0d3b8b2cdeedcf7d85cef185` |
| `supabase/functions/coach-response/index.ts` | 9201 | `b5528b4667f4d21ea7bd4568b249442f993bb774a22d71eb7765181bf4b40542` |
| `supabase/functions/id-document-check/index.ts` | 6521 | `d35975a61fda3abb1a958e17f39d579e3a28b0d7571c4c01ff2ef4b9d6fa8baa` |
| `supabase/functions/nightly-backup/index.ts` | 3025 | `22c77957ea2f2b954d919196b48ea220280282f52035c5faeef914d2286b3992` |
| `supabase/functions/noor-agent/index.ts` | 12630 | `1d5972db95b44a29d219c38bb57302633b5a639417e6a7d6bd8dfcf37410a5af` |
| `supabase/migrations/006_admin_security_and_recovery.sql` | 3346 | `62a2b364ebac886f856e425f6f28820040881136f7d34e506e3e20d0b52e0175` |
| `supabase/migrations/007_timezone_streaks_notifications.sql` | 3011 | `226a52850dc57b204a353025732280f275457e6e31a6c17e37c9f94d2f9126d2` |
| `supabase/migrations/008_kyc_hardening.sql` | 2882 | `860538fb80e347e105490fac3c01410c3c2d92f7c00008169e452d1e90642a9f` |
| `supabase/migrations/009_agentic_noor.sql` | 4977 | `696f7a08d0fc119c50a5ad35b4e6a8720cc875611c6a998be5b34f26d9e03670` |
| `supabase/migrations/010_payments.sql` | 3787 | `d83916d84d422770d95c4781f7a9e3553bb23b96f6eb27677999bbb9810dafca` |
| `supabase/migrations/011_partner_governance.sql` | 4159 | `01a76f069a1c65bc6483b7b4361cfbfe9693e980118242d03ee5b0abc7cb2142` |
| `supabase/migrations/012_noor_atomic_security.sql` | 21342 | `197aa851b8a8229239c0e2cefc92c8e5aca59d7ffe9d90247cd204109a6b5868` |
| `tests/noor-security.test.ts` | 5780 | `dcfd7cdc311e2d0f2e3d3514f9ca2a7d21839481630851dbfd6856e90de6c99d` |
| `tests/rls.test.ts` | 4905 | `cb88fd34bd7c6974e0c74e0a43c644bedc944f19d61bf168f8e474cffda1eee9` |
