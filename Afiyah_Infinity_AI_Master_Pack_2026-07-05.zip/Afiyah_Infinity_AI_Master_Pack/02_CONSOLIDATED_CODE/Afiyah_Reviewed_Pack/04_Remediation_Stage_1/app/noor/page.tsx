// Noor — chat with approval-gated agentic proposals.
"use client";
import { useEffect, useRef, useState } from "react";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";

const G = "#C9A84C", BG = "#0A1F14", BG2 = "#142D1E", IV = "#EDE6D3", TE = "#2E9E80";

type NoorMessage = { role: string; content: string };
type NoorAction = {
  id: string;
  action_type: string;
  payload: Record<string, unknown>;
  proposal_reason?: string;
};

export default function NoorPage() {
  const supabase = createClientComponentClient();
  const [msgs, setMsgs] = useState<NoorMessage[]>([
    { role: "noor", content: "As-salamu alaykum, sister 🌙 I'm Noor. Ask me anything — and if it helps, I can propose small actions. Nothing happens without your approval." },
  ]);
  const [pending, setPending] = useState<NoorAction[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [deciding, setDeciding] = useState<Record<string, boolean>>({});
  const [sessionId, setSessionId] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), [msgs, pending]);

  async function callFn(name: string, body: Record<string, unknown>) {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.access_token) throw new Error("unauthorized");

    const res = await fetch(`${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/${name}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify(body),
    });
    const out = await res.json().catch(() => ({ error: "invalid_server_response" }));
    if (!res.ok) throw new Error(String(out.error ?? "request_failed"));
    return out;
  }

  async function send() {
    const text = input.trim();
    if (!text || busy) return;
    setInput("");
    setBusy(true);
    setMsgs((m) => [...m, { role: "sister", content: text }]);
    try {
      const out = await callFn("noor-agent", { message: text, session_id: sessionId });
      if (out.session_id) setSessionId(String(out.session_id));
      setMsgs((m) => [...m, { role: "noor", content: String(out.reply ?? "…") }]);
      if (Array.isArray(out.actions) && out.actions.length) {
        setPending((p) => [...p, ...(out.actions as NoorAction[])]);
      }
    } catch (error) {
      const code = error instanceof Error ? error.message : "request_failed";
      setMsgs((m) => [...m, {
        role: "noor",
        content: code === "session_not_found"
          ? "That conversation is no longer available. I have not opened or changed any other sister's session. Please start a new chat."
          : "Connection hiccup — please try again in a moment.",
      }]);
      if (code === "session_not_found") setSessionId(null);
    } finally {
      setBusy(false);
    }
  }

  async function decide(action: NoorAction, approve: boolean) {
    if (deciding[action.id]) return;
    setDeciding((d) => ({ ...d, [action.id]: true }));
    try {
      // One endpoint performs approval/decline + execution atomically.
      // The browser never directly updates agent_actions.
      const out = await callFn("agent-execute", {
        action_id: action.id,
        decision: approve ? "approved" : "declined",
      });
      setPending((p) => p.filter((x) => x.id !== action.id));
      setMsgs((m) => [...m, {
        role: "noor",
        content: approve ? `✦ ${String(out.summary ?? "Action completed.")}` : "Action declined. Nothing was changed.",
      }]);
    } catch {
      setMsgs((m) => [...m, {
        role: "noor",
        content: "I couldn't complete that safely. Nothing was changed.",
      }]);
    } finally {
      setDeciding((d) => ({ ...d, [action.id]: false }));
    }
  }

  return (
    <main style={{ minHeight: "100vh", background: BG, color: IV, fontFamily: "Georgia, serif" }}>
      <div style={{ maxWidth: 720, margin: "0 auto", padding: 24, display: "flex", flexDirection: "column", height: "100vh" }}>
        <header style={{ borderBottom: `1px solid ${G}44`, paddingBottom: 12, marginBottom: 12 }}>
          <h1 style={{ color: G, margin: 0 }}>Noor</h1>
          <small style={{ opacity: 0.7 }}>Your AI buddy · every action needs your approval · audited under Amanah</small>
        </header>
        <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 10 }}>
          {msgs.map((m, i) => (
            <div key={i} style={{
              alignSelf: m.role === "sister" ? "flex-end" : "flex-start",
              maxWidth: "85%", padding: "10px 14px", borderRadius: 10, lineHeight: 1.6,
              background: m.role === "sister" ? G : BG2,
              color: m.role === "sister" ? BG : IV,
              borderLeft: m.role === "sister" ? "none" : `3px solid ${G}`,
            }}>{m.content}</div>
          ))}
          {pending.map((a) => (
            <div key={a.id} style={{ border: `1px dashed ${TE}`, borderRadius: 10, padding: 12, background: BG2 }}>
              <div style={{ color: TE, fontSize: 12, letterSpacing: 2, textTransform: "uppercase" }}>Noor proposes</div>
              <div style={{ margin: "6px 0" }}>
                <b>{a.action_type.replace(/_/g, " ")}</b>
                {a.proposal_reason && <span style={{ opacity: 0.8 }}> — {a.proposal_reason}</span>}
              </div>
              <pre style={{ fontSize: 12, opacity: 0.7, whiteSpace: "pre-wrap" }}>{JSON.stringify(a.payload)}</pre>
              <div style={{ display: "flex", gap: 8 }}>
                <button disabled={deciding[a.id]} onClick={() => decide(a, true)} style={{ background: G, color: BG, border: "none", borderRadius: 8, padding: "8px 18px", fontWeight: 700 }}>
                  {deciding[a.id] ? "Processing…" : "Approve"}
                </button>
                <button disabled={deciding[a.id]} onClick={() => decide(a, false)} style={{ background: "transparent", color: G, border: `1px solid ${G}`, borderRadius: 8, padding: "8px 18px" }}>
                  Decline
                </button>
              </div>
            </div>
          ))}
          {busy && <div style={{ color: G, fontSize: 13 }}>Noor is thinking…</div>}
          <div ref={endRef} />
        </div>
        <div style={{ display: "flex", gap: 8, paddingTop: 12 }}>
          <input value={input} onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Ask Noor, or say: set my reminder to 06:30 · zakat on 60k + 40g gold"
            style={{ flex: 1, padding: 12, borderRadius: 8, border: `1px solid ${G}44`, background: BG2, color: IV }} />
          <button onClick={send} disabled={busy}
            style={{ background: G, color: BG, border: "none", borderRadius: 8, padding: "12px 22px", fontWeight: 700 }}>
            {busy ? "…" : "Send"}
          </button>
        </div>
      </div>
    </main>
  );
}
