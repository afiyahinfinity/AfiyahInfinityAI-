# Stage 1 Remediation — Noor Security and Atomic Execution

## Scope completed

This bundle addresses the three P0 items selected for the next remediation stage:

1. **Noor session ownership**
   - Caller-supplied `session_id` values are accepted only after proving `id + sister_id + active session` ownership.
   - Message/action rows now have composite foreign keys linking `(session_id, sister_id)` to the owning session, so service-role code cannot accidentally cross tenants.

2. **Atomic approval and execution**
   - The browser no longer writes `agent_actions.status = approved` directly.
   - `decide_and_execute_agent_action()` authorises the sister, locks the action row, decides, validates and executes in one PostgreSQL transaction.
   - Concurrent retries are idempotent: only one terminal `executed` event is created and later calls return the stored result.
   - Proposal fields are immutable after insertion.

3. **`SECURITY DEFINER` hardening**
   - Safe `search_path = pg_catalog, public` is applied.
   - Functions accepting user IDs enforce self/service/admin authorization.
   - Default `PUBLIC`, `anon` and broad `authenticated` execution is revoked, then only intended entry points are re-granted.

The replacement Noor function also validates action payloads before storage and restricts CORS to configured origins.

## Files to merge

- `supabase/migrations/012_noor_atomic_security.sql`
- `supabase/functions/noor-agent/index.ts`
- `supabase/functions/agent-execute/index.ts`
- `app/noor/page.tsx`
- `tests/noor-security.test.ts`

## Staging deployment order

```bash
# 1. Apply migration through the normal migration pipeline.
supabase db push --project-ref "$AFIYAH_STAGING_PROJECT_REF"

# 2. Configure origins and existing secrets.
supabase secrets set \
  ALLOWED_ORIGINS="https://afiyahinfinityai.com,https://www.afiyahinfinityai.com" \
  --project-ref "$AFIYAH_STAGING_PROJECT_REF"

# 3. Deploy the two affected Edge Functions.
supabase functions deploy noor-agent --project-ref "$AFIYAH_STAGING_PROJECT_REF"
supabase functions deploy agent-execute --project-ref "$AFIYAH_STAGING_PROJECT_REF"

# 4. Run security tests against staging only.
pnpm vitest run tests/noor-security.test.ts tests/rls.test.ts

# 5. Build and smoke-test the web app.
pnpm lint
pnpm typecheck
pnpm build
```

## Required release evidence

Do not promote to production until all of these pass:

- Cross-session attack returns `404 session_not_found` and writes no row.
- Mismatched `(session_id, sister_id)` insert fails at the database constraint.
- A sister cannot directly update a proposal to `approved`, `declined` or `executed`.
- Two concurrent approval requests produce one domain write and one `executed` log.
- User A cannot call `current_streak`, `submit_checkin`, `local_date_for`, `seed_kyc_steps` or `agent_quota_ok` for User B.
- Existing check-in, reminders, KYC seeding, admin RLS and AI audit flows still pass regression tests.
- A database backup and rollback point exists before production migration 012.

## GitHub and hosting status

The connected GitHub login is `afiyahinfinity`, but no accessible repository named `afiyahinfinity` currently exists. The profile contains unrelated public forks; this bundle must not be committed into those repositories.

Recommended source repository:

```text
afiyahinfinity/afiyahinfinity
```

Create it as **private**, install/authorise the GitHub connector for that repository, then merge this bundle on a branch such as:

```text
security/noor-stage-1
```

The project documents conflict on frontend hosting: one says **Hostinger is provisioned**, while another deployment runbook specifies **Vercel**. Confirm the actual production source/deployment integration before changing DNS or deploying. Supabase migrations and Edge Functions remain hosted in Supabase regardless of whether the Next.js frontend is deployed through Hostinger's Node/Git integration or Vercel.

## Production promotion

After staging approval:

1. Back up production and record migration head.
2. Apply migration 012.
3. Deploy `noor-agent` and `agent-execute`.
4. Deploy the updated Noor page.
5. Run a test-sister smoke flow: new session → proposal → decline; new proposal → approve; retry approval.
6. Monitor Edge Function errors, PostgreSQL logs and `agent_action_execution_log` for the release window.
7. Keep `AI_ENABLED=false` until smoke tests pass if this is the first real-user release.
