-- ============================================================
-- 012_noor_atomic_security.sql
-- Stage 1 remediation:
--   1) Enforce Noor session ownership at the database boundary.
--   2) Make sister approval + deterministic execution atomic,
--      row-locked and idempotent.
--   3) Harden SECURITY DEFINER functions and EXECUTE grants.
--
-- Apply to STAGING first. Run the Noor security test suite before
-- production. This migration deliberately fails if existing rows
-- violate the new session/sister consistency constraints.
-- ============================================================

begin;

-- ------------------------------------------------------------------
-- A. Session ownership consistency cannot rely on Edge code alone.
-- Both the session id and sister id must match the parent session.
-- ------------------------------------------------------------------

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'uq_agent_sessions_id_sister'
      and conrelid = 'public.agent_sessions'::regclass
  ) then
    alter table public.agent_sessions
      add constraint uq_agent_sessions_id_sister unique (id, sister_id);
  end if;
end $$;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'fk_agent_messages_session_owner'
      and conrelid = 'public.agent_messages'::regclass
  ) then
    alter table public.agent_messages
      add constraint fk_agent_messages_session_owner
      foreign key (session_id, sister_id)
      references public.agent_sessions (id, sister_id)
      on delete cascade not valid;
  end if;
end $$;

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'fk_agent_actions_session_owner'
      and conrelid = 'public.agent_actions'::regclass
  ) then
    alter table public.agent_actions
      add constraint fk_agent_actions_session_owner
      foreign key (session_id, sister_id)
      references public.agent_sessions (id, sister_id)
      on delete cascade not valid;
  end if;
end $$;

alter table public.agent_messages
  validate constraint fk_agent_messages_session_owner;
alter table public.agent_actions
  validate constraint fk_agent_actions_session_owner;

-- Proposal content is immutable after creation. Only lifecycle fields
-- may change during a decision/execution transaction.
create or replace function public.protect_agent_action_proposal()
returns trigger
language plpgsql
set search_path = pg_catalog, public
as $$
begin
  if new.session_id is distinct from old.session_id
     or new.sister_id is distinct from old.sister_id
     or new.action_type is distinct from old.action_type
     or new.payload is distinct from old.payload
     or new.proposal_reason is distinct from old.proposal_reason
     or new.shariah_gate is distinct from old.shariah_gate then
    raise exception 'agent proposal fields are immutable after creation';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_agent_action_proposal_immutable
  on public.agent_actions;
create trigger trg_agent_action_proposal_immutable
before update on public.agent_actions
for each row execute function public.protect_agent_action_proposal();

-- Remove the two-step client-side approval policy. Sisters approve or
-- decline only through decide_and_execute_agent_action().
drop policy if exists "sister approves or declines own proposals"
  on public.agent_actions;

-- Append-only action decision/execution evidence.
create table if not exists public.agent_action_execution_log (
  id          bigserial primary key,
  action_id   uuid not null references public.agent_actions(id) on delete cascade,
  sister_id   uuid not null references public.sisters(id) on delete cascade,
  event       text not null check (event in ('declined','blocked','executed','idempotent_replay')),
  detail      jsonb not null default '{}',
  created_at  timestamptz not null default now()
);
create unique index if not exists uq_agent_action_terminal_event
  on public.agent_action_execution_log(action_id, event)
  where event in ('declined','blocked','executed');

alter table public.agent_action_execution_log enable row level security;
drop policy if exists "sister reads own action execution log"
  on public.agent_action_execution_log;
create policy "sister reads own action execution log"
  on public.agent_action_execution_log
  for select using (sister_id = auth.uid());

create or replace function public.block_agent_execution_log_mutation()
returns trigger
language plpgsql
set search_path = pg_catalog, public
as $$
begin
  raise exception 'agent_action_execution_log is append-only';
end;
$$;

drop trigger if exists trg_agent_execution_log_append_only
  on public.agent_action_execution_log;
create trigger trg_agent_execution_log_append_only
before update or delete on public.agent_action_execution_log
for each row execute function public.block_agent_execution_log_mutation();

-- ------------------------------------------------------------------
-- B. Atomic decision + deterministic execution.
-- The action row is locked FOR UPDATE. Concurrent retries wait and then
-- receive the existing terminal result instead of executing twice.
-- ------------------------------------------------------------------
create or replace function public.decide_and_execute_agent_action(
  p_action_id uuid,
  p_decision text
)
returns jsonb
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_uid uuid := auth.uid();
  v_action public.agent_actions%rowtype;
  v_payload jsonb;
  v_enabled boolean;
  v_summary text;
  v_dimension text;
  v_goal_text text;
  v_goal_id uuid;
  v_module_slug text;
  v_question text;
  v_time_text text;
  v_target numeric;
  v_current numeric;
  v_savings numeric;
  v_gold_grams numeric;
  v_gold_rate numeric;
  v_nisab numeric;
  v_wealth numeric;
  v_rows integer;
begin
  if v_uid is null then
    return jsonb_build_object('ok', false, 'error', 'unauthorized');
  end if;

  if p_decision is null or p_decision not in ('approved', 'declined') then
    return jsonb_build_object('ok', false, 'error', 'invalid_decision');
  end if;

  select * into v_action
  from public.agent_actions
  where id = p_action_id
    and sister_id = v_uid
  for update;

  if not found then
    return jsonb_build_object('ok', false, 'error', 'not_found');
  end if;

  -- Safe idempotent replay after a successful first request.
  if v_action.status = 'executed' then
    insert into public.agent_action_execution_log(action_id, sister_id, event, detail)
    values (v_action.id, v_uid, 'idempotent_replay', jsonb_build_object('status', 'executed'));
    return jsonb_build_object(
      'ok', true,
      'idempotent', true,
      'status', 'executed',
      'summary', v_action.result_summary
    );
  end if;

  if v_action.status <> 'proposed' then
    return jsonb_build_object(
      'ok', false,
      'error', 'already_decided',
      'status', v_action.status,
      'summary', v_action.result_summary
    );
  end if;

  if p_decision = 'declined' then
    update public.agent_actions
       set status = 'declined',
           approved_at = null,
           result_summary = 'Declined by sister'
     where id = v_action.id;

    insert into public.agent_action_execution_log(action_id, sister_id, event, detail)
    values (v_action.id, v_uid, 'declined', jsonb_build_object('action_type', v_action.action_type));

    return jsonb_build_object('ok', true, 'status', 'declined', 'summary', 'Action declined. Nothing was changed.');
  end if;

  select enabled into v_enabled
  from public.agent_action_registry
  where action_type = v_action.action_type;

  if v_action.shariah_gate <> 'passed' or coalesce(v_enabled, false) is not true then
    update public.agent_actions
       set status = 'blocked',
           result_summary = 'Action type is disabled or did not pass the Shariah gate'
     where id = v_action.id;

    insert into public.agent_action_execution_log(action_id, sister_id, event, detail)
    values (
      v_action.id,
      v_uid,
      'blocked',
      jsonb_build_object('action_type', v_action.action_type, 'reason', 'registry_or_shariah_gate')
    );

    return jsonb_build_object('ok', false, 'error', 'action_blocked', 'status', 'blocked');
  end if;

  -- "approved" exists only inside this transaction. It is never left
  -- pending for a second worker to race or replay.
  update public.agent_actions
     set status = 'approved', approved_at = clock_timestamp()
   where id = v_action.id;

  v_payload := coalesce(v_action.payload, '{}'::jsonb);
  if jsonb_typeof(v_payload) <> 'object' then
    raise exception 'invalid_payload';
  end if;

  case v_action.action_type
    when 'create_goal' then
      v_dimension := v_payload->>'dimension';
      v_goal_text := btrim(coalesce(v_payload->>'goal_text', ''));
      if v_dimension is null
         or v_dimension not in ('spiritual','wellness','learning','wealth','giving','sisterhood')
         or char_length(v_goal_text) not between 1 and 300 then
        raise exception 'invalid_create_goal_payload';
      end if;
      if v_payload ? 'target_value' and nullif(v_payload->>'target_value','') is not null then
        v_target := (v_payload->>'target_value')::numeric;
        if v_target < 0 or v_target > 1000000000000 then
          raise exception 'invalid_target_value';
        end if;
      else
        v_target := null;
      end if;

      insert into public.sister_goals(
        sister_id, dimension, goal_text, target_value, current_value
      ) values (
        v_uid, v_dimension, v_goal_text, v_target, 0
      );
      v_summary := format('Goal created: %s', left(v_goal_text, 80));

    when 'update_goal_progress' then
      v_goal_id := (v_payload->>'goal_id')::uuid;
      v_current := (v_payload->>'current_value')::numeric;
      if v_current is null or v_current < 0 or v_current > 1000000000000 then
        raise exception 'invalid_current_value';
      end if;

      update public.sister_goals
         set current_value = v_current
       where id = v_goal_id and sister_id = v_uid;
      get diagnostics v_rows = row_count;
      if v_rows <> 1 then
        raise exception 'goal_not_found';
      end if;
      v_summary := format('Progress updated to %s', v_current);

    when 'calc_zakat' then
      v_savings := coalesce(nullif(v_payload->>'savings_aed','')::numeric, 0);
      v_gold_grams := coalesce(nullif(v_payload->>'gold_grams','')::numeric, 0);
      if v_savings < 0 or v_gold_grams < 0
         or v_savings > 1000000000000 or v_gold_grams > 1000000 then
        raise exception 'invalid_zakat_payload';
      end if;

      select value into v_gold_rate
      from public.reference_rates
      where key = 'gold_aed_per_gram';
      if v_gold_rate is null or v_gold_rate <= 0 then
        raise exception 'gold_rate_unavailable';
      end if;

      v_nisab := 85 * v_gold_rate;
      v_wealth := v_savings + (v_gold_grams * v_gold_rate);
      if v_wealth >= v_nisab then
        v_summary := format(
          'Zakatable wealth AED %s is at or above nisab AED %s; estimated Zakat AED %s (educational estimate, not a fatwa)',
          round(v_wealth, 0), round(v_nisab, 0), round(v_wealth * 0.025, 0)
        );
      else
        v_summary := format(
          'Wealth AED %s is below nisab AED %s; no Zakat is indicated by this educational estimate',
          round(v_wealth, 0), round(v_nisab, 0)
        );
      end if;

    when 'recommend_module' then
      v_module_slug := btrim(coalesce(v_payload->>'module_slug', ''));
      if char_length(v_module_slug) not between 1 and 80
         or v_module_slug !~ '^[a-z0-9]+(?:-[a-z0-9]+)*$' then
        raise exception 'invalid_module_slug';
      end if;
      v_summary := format('Module recommended: %s', v_module_slug);

    when 'set_reminder_time' then
      v_time_text := coalesce(v_payload->>'local_time', '');
      if v_time_text !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$' then
        raise exception 'invalid_reminder_time';
      end if;

      update public.user_preferences
         set reminder_local_time = v_time_text::time
       where sister_id = v_uid;
      get diagnostics v_rows = row_count;
      if v_rows <> 1 then
        raise exception 'user_preferences_not_found';
      end if;
      v_summary := format('Daily reminder set to %s local time', v_time_text);

    when 'escalate_scholar' then
      v_question := btrim(coalesce(v_payload->>'question', ''));
      if char_length(v_question) not between 1 and 500 then
        raise exception 'invalid_scholar_question';
      end if;

      insert into public.admin_review_queue(
        entity_type, entity_id, priority, status, notes
      ) values (
        'sister', v_uid, 'normal', 'pending',
        'Scholar question via Noor: ' || v_question
      );
      v_summary := 'Question routed to the scholar desk for human review.';

    else
      raise exception 'unknown_action_type';
  end case;

  update public.agent_actions
     set status = 'executed',
         executed_at = clock_timestamp(),
         result_summary = v_summary
   where id = v_action.id;

  insert into public.agent_action_execution_log(action_id, sister_id, event, detail)
  values (
    v_action.id,
    v_uid,
    'executed',
    jsonb_build_object('action_type', v_action.action_type, 'summary', v_summary)
  );

  return jsonb_build_object('ok', true, 'status', 'executed', 'summary', v_summary);

exception
  when others then
    -- The inner approval and any domain write are rolled back to the
    -- exception block savepoint. Record a terminal, non-retryable block.
    update public.agent_actions
       set status = 'blocked',
           result_summary = 'Execution rejected by server validation'
     where id = p_action_id
       and sister_id = v_uid
       and status = 'proposed';

    insert into public.agent_action_execution_log(action_id, sister_id, event, detail)
    select p_action_id, v_uid, 'blocked',
           jsonb_build_object('reason', 'server_validation', 'sqlstate', sqlstate)
    where exists (
      select 1 from public.agent_actions
      where id = p_action_id and sister_id = v_uid
    )
    on conflict do nothing;

    return jsonb_build_object('ok', false, 'error', 'execution_rejected', 'status', 'blocked');
end;
$$;

revoke all on function public.decide_and_execute_agent_action(uuid, text)
  from public, anon;
grant execute on function public.decide_and_execute_agent_action(uuid, text)
  to authenticated;

-- ------------------------------------------------------------------
-- C. SECURITY DEFINER hardening.
-- Explicit caller checks prevent arbitrary p_user/p_sister access.
-- ------------------------------------------------------------------
create or replace function public.is_admin(required_role text default null)
returns boolean
language sql
stable
security definer
set search_path = pg_catalog, public
as $$
  select exists (
    select 1
    from public.admin_users
    where id = auth.uid()
      and is_active
      and (required_role is null or role = required_role)
  );
$$;

drop policy if exists "admins read action execution log"
  on public.agent_action_execution_log;
create policy "admins read action execution log"
  on public.agent_action_execution_log
  for select using (public.is_admin());

create or replace function public.local_date_for(p_user uuid)
returns date
language plpgsql
stable
security definer
set search_path = pg_catalog, public
as $$
begin
  if coalesce(auth.role(), '') <> 'service_role'
     and p_user is distinct from auth.uid()
     and not public.is_admin() then
    raise exception 'forbidden';
  end if;

  return (
    now() at time zone coalesce(
      (select timezone from public.user_preferences where sister_id = p_user),
      'Asia/Dubai'
    )
  )::date;
end;
$$;

create or replace function public.submit_checkin(p_user uuid, p_answers jsonb)
returns public.daily_checkins
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_date date;
  v_row public.daily_checkins;
begin
  if coalesce(auth.role(), '') <> 'service_role'
     and p_user is distinct from auth.uid()
     and not public.is_admin() then
    raise exception 'forbidden';
  end if;
  if jsonb_typeof(p_answers) <> 'object' then
    raise exception 'answers must be a JSON object';
  end if;

  v_date := public.local_date_for(p_user);
  insert into public.daily_checkins(sister_id, date, answers)
  values (p_user, v_date, p_answers)
  on conflict (sister_id, date)
  do update set answers = excluded.answers, updated_at = now()
  returning * into v_row;
  return v_row;
end;
$$;

create or replace function public.current_streak(p_user uuid)
returns int
language plpgsql
stable
security definer
set search_path = pg_catalog, public
as $$
declare
  v_today date;
  v_streak int := 0;
  v_cursor date;
begin
  if coalesce(auth.role(), '') <> 'service_role'
     and p_user is distinct from auth.uid()
     and not public.is_admin() then
    raise exception 'forbidden';
  end if;

  v_today := public.local_date_for(p_user);
  select max(date) into v_cursor
  from public.daily_checkins
  where sister_id = p_user and date in (v_today, v_today - 1);

  if v_cursor is null then return 0; end if;
  loop
    exit when not exists (
      select 1 from public.daily_checkins
      where sister_id = p_user and date = v_cursor
    );
    v_streak := v_streak + 1;
    v_cursor := v_cursor - 1;
  end loop;
  return v_streak;
end;
$$;

create or replace function public.seed_kyc_steps(p_sister uuid)
returns void
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
begin
  if coalesce(auth.role(), '') <> 'service_role'
     and p_sister is distinct from auth.uid()
     and not public.is_admin() then
    raise exception 'forbidden';
  end if;

  insert into public.kyc_steps(sister_id, step)
  values
    (p_sister,'attestation'),
    (p_sister,'identity_form'),
    (p_sister,'document_upload'),
    (p_sister,'ai_screening'),
    (p_sister,'human_review'),
    (p_sister,'verified')
  on conflict do nothing;
end;
$$;

create or replace function public.agent_quota_ok(
  p_sister uuid,
  p_daily_limit int default 10
)
returns boolean
language plpgsql
stable
security definer
set search_path = pg_catalog, public
as $$
begin
  if p_daily_limit < 1 or p_daily_limit > 100 then
    raise exception 'invalid daily limit';
  end if;
  if coalesce(auth.role(), '') <> 'service_role'
     and p_sister is distinct from auth.uid()
     and not public.is_admin() then
    raise exception 'forbidden';
  end if;

  return (
    select count(*) < p_daily_limit
    from public.agent_actions
    where sister_id = p_sister
      and created_at > now() - interval '24 hours'
  );
end;
$$;

-- Trigger functions: safe lookup path; no direct client execution.
alter function public.prevent_status_regression()
  set search_path = pg_catalog, public;
alter function public.validate_timezone()
  set search_path = pg_catalog, public;
alter function public.enforce_riba_free()
  set search_path = pg_catalog, public;

-- Default-deny every SECURITY DEFINER function in public. Service role
-- retains server access; selected self-service functions are re-granted.
do $hardening$
declare
  r record;
begin
  for r in
    select n.nspname,
           p.proname,
           pg_get_function_identity_arguments(p.oid) as identity_args
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public'
      and p.prosecdef
  loop
    execute format(
      'alter function %I.%I(%s) set search_path = pg_catalog, public',
      r.nspname, r.proname, r.identity_args
    );
    execute format(
      'revoke all on function %I.%I(%s) from public, anon, authenticated',
      r.nspname, r.proname, r.identity_args
    );
    execute format(
      'grant execute on function %I.%I(%s) to service_role',
      r.nspname, r.proname, r.identity_args
    );
  end loop;
end
$hardening$;

-- Required authenticated entry points after the default-deny pass.
grant execute on function public.is_admin(text) to authenticated;
grant execute on function public.local_date_for(uuid) to authenticated;
grant execute on function public.submit_checkin(uuid, jsonb) to authenticated;
grant execute on function public.current_streak(uuid) to authenticated;
grant execute on function public.seed_kyc_steps(uuid) to authenticated;
grant execute on function public.agent_quota_ok(uuid, int) to authenticated;
grant execute on function public.decide_and_execute_agent_action(uuid, text)
  to authenticated;

-- No client writes to the append-only evidence table.
revoke insert, update, delete on public.agent_action_execution_log
  from public, anon, authenticated;
grant select on public.agent_action_execution_log to authenticated;

-- Trigger functions should never be called directly by clients.
revoke all on function public.protect_agent_action_proposal()
  from public, anon, authenticated;
revoke all on function public.block_agent_execution_log_mutation()
  from public, anon, authenticated;
revoke all on function public.prevent_status_regression()
  from public, anon, authenticated;
revoke all on function public.validate_timezone()
  from public, anon, authenticated;
revoke all on function public.enforce_riba_free()
  from public, anon, authenticated;

commit;
