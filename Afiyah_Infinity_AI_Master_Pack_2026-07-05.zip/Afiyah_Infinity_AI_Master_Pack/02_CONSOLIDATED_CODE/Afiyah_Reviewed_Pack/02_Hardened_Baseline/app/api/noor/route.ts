import { NextRequest, NextResponse } from "next/server";
import { completeNoor } from "../../../lib/llm-gateway";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    // Replace this placeholder with the project's authenticated server client.
    // Reject unauthenticated requests before production deployment.
    const body = await req.json();
    const messages = Array.isArray(body?.messages) ? body.messages.slice(-12) : [];
    const safe = messages
      .filter((m: unknown) => m && typeof m === "object")
      .map((m: any) => ({ role: m.role === "assistant" ? "assistant" : "user", content: String(m.content ?? "").slice(0, 4000) }))
      .filter((m: { content: string }) => m.content.trim());
    if (!safe.length) return NextResponse.json({ error: "No messages supplied" }, { status: 400 });

    const result = await completeNoor(safe);
    return NextResponse.json(result, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    console.error("noor_route_error", error);
    return NextResponse.json({ reply: "Noor is unavailable right now. Please try again later.", actions: [] }, { status: 503 });
  }
}
