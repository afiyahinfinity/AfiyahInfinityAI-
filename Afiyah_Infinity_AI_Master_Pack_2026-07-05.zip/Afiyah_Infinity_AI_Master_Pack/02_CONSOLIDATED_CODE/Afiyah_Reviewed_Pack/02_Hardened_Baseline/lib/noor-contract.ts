export const ALLOWED_ACTIONS = new Set([
  "create_goal",
  "calc_zakat",
  "recommend_module",
  "escalate_human",
]);

export type NoorAction = {
  type: string;
  title?: string;
  target_aed?: number;
  goal_type?: string;
  savings_aed?: number;
  gold_grams?: number;
  slug?: string;
  reason?: string;
};

export type NoorResponse = { reply: string; actions: NoorAction[] };

export function validateNoorResponse(input: unknown): NoorResponse {
  if (!input || typeof input !== "object") throw new Error("Invalid model response");
  const obj = input as Record<string, unknown>;
  if (typeof obj.reply !== "string" || !obj.reply.trim()) throw new Error("Missing reply");

  const rawActions = Array.isArray(obj.actions) ? obj.actions.slice(0, 2) : [];
  const actions = rawActions.filter((item): item is NoorAction => {
    if (!item || typeof item !== "object") return false;
    const action = item as Record<string, unknown>;
    return typeof action.type === "string" && ALLOWED_ACTIONS.has(action.type);
  });
  return { reply: obj.reply.slice(0, 4000), actions };
}
