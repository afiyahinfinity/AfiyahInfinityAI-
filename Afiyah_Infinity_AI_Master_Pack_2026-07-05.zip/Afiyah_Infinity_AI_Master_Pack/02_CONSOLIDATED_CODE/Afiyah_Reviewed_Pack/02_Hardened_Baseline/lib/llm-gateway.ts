import { validateNoorResponse, type NoorResponse } from "./noor-contract";

type ChatMessage = { role: "user" | "assistant"; content: string };

const SYSTEM = `You are Noor, an educational AI assistant for Afiyah Infinity. Provide general educational information only. Do not provide investment, legal, medical, or personalised religious rulings. Present material Shariah differences neutrally and recommend qualified human review. Never claim that an external action has occurred. Return JSON with a reply and no more than two proposed actions.`;

export async function completeNoor(messages: ChatMessage[]): Promise<NoorResponse> {
  if (process.env.AI_ENABLED !== "true") {
    return { reply: "Noor is temporarily unavailable. Please use the learning modules or contact support.", actions: [] };
  }
  const endpoint = process.env.LLM_BASE_URL;
  const apiKey = process.env.LLM_API_KEY;
  const model = process.env.LLM_MODEL_STANDARD;
  if (!endpoint || !apiKey || !model) throw new Error("LLM configuration incomplete");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({ model, system: SYSTEM, messages, response_format: { type: "json_object" } }),
      signal: controller.signal,
      cache: "no-store",
    });
    if (!response.ok) throw new Error(`LLM upstream failed: ${response.status}`);
    const data = await response.json();
    const raw = data.output_text ?? data.content?.[0]?.text ?? data.choices?.[0]?.message?.content;
    if (typeof raw !== "string") throw new Error("Unsupported LLM response shape");
    return validateNoorResponse(JSON.parse(raw));
  } finally {
    clearTimeout(timeout);
  }
}
