BEGIN;

-- Data-integrity constraints
ALTER TABLE sisters.payments
  ADD CONSTRAINT payments_positive_amount CHECK (amount_aed > 0),
  ADD CONSTRAINT payments_aed_only CHECK (currency = 'AED'),
  ADD CONSTRAINT payments_riba_free_required CHECK (is_riba_free IS TRUE);
ALTER TABLE sisters.wealth_goals
  ADD CONSTRAINT goals_positive_target CHECK (target_aed IS NULL OR target_aed > 0),
  ADD CONSTRAINT goals_nonnegative_saved CHECK (saved_aed >= 0);
ALTER TABLE sisters.barakah_scores
  ADD CONSTRAINT barakah_spiritual_range CHECK (spiritual BETWEEN 0 AND 100),
  ADD CONSTRAINT barakah_wellness_range CHECK (wellness BETWEEN 0 AND 100),
  ADD CONSTRAINT barakah_learning_range CHECK (learning BETWEEN 0 AND 100),
  ADD CONSTRAINT barakah_wealth_range CHECK (wealth BETWEEN 0 AND 100),
  ADD CONSTRAINT barakah_giving_range CHECK (giving BETWEEN 0 AND 100),
  ADD CONSTRAINT barakah_sisterhood_range CHECK (sisterhood BETWEEN 0 AND 100);
ALTER TABLE sisters.agent_actions
  ADD CONSTRAINT agent_execution_requires_approval
  CHECK (executed IS NOT TRUE OR (approved_by_user IS TRUE AND shariah_check = 'passed'));

-- Enable RLS everywhere containing personal, tenant, governance, or model data.
ALTER TABLE sisters.kyc_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE sisters.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE sisters.learning_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE sisters.barakah_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE sisters.agent_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE sisters.knowledge_chunks ENABLE ROW LEVEL SECURITY;
ALTER TABLE partners.organisations ENABLE ROW LEVEL SECURITY;
ALTER TABLE partners.campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE governance.shariah_rulings ENABLE ROW LEVEL SECURITY;
ALTER TABLE governance.risk_register ENABLE ROW LEVEL SECURITY;
ALTER TABLE governance.audit_log ENABLE ROW LEVEL SECURITY;

-- Correct existing owner policies: USING controls reads/deletes; WITH CHECK controls inserts/updates.
DROP POLICY IF EXISTS sisters_self ON sisters.users;
CREATE POLICY sisters_self ON sisters.users
  FOR ALL USING (auth_id = auth.uid()) WITH CHECK (auth_id = auth.uid());
DROP POLICY IF EXISTS goals_self ON sisters.wealth_goals;
CREATE POLICY goals_self ON sisters.wealth_goals
  FOR ALL USING (user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid()))
  WITH CHECK (user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid()));
DROP POLICY IF EXISTS sessions_self ON sisters.agent_sessions;
CREATE POLICY sessions_self ON sisters.agent_sessions
  FOR ALL USING (user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid()))
  WITH CHECK (user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid()));
DROP POLICY IF EXISTS actions_self ON sisters.agent_actions;
CREATE POLICY actions_read_own ON sisters.agent_actions
  FOR SELECT USING (user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid()));
-- Sisters cannot directly insert or execute actions; trusted server functions must do so.
DROP POLICY IF EXISTS payments_self ON sisters.payments;
CREATE POLICY payments_read_own ON sisters.payments
  FOR SELECT USING (user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid()));

CREATE POLICY kyc_read_own ON sisters.kyc_records FOR SELECT
  USING (user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid()));
CREATE POLICY subscriptions_read_own ON sisters.subscriptions FOR SELECT
  USING (user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid()));
CREATE POLICY learning_own ON sisters.learning_progress FOR ALL
  USING (user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid()))
  WITH CHECK (user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid()));
CREATE POLICY barakah_read_own ON sisters.barakah_scores FOR SELECT
  USING (user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid()));
CREATE POLICY messages_read_own ON sisters.agent_messages FOR SELECT
  USING (session_id IN (SELECT id FROM sisters.agent_sessions WHERE user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid())));

-- Partner tenant isolation
DROP POLICY IF EXISTS partner_org ON partners.members;
CREATE POLICY partner_member_self ON partners.members FOR SELECT USING (auth_id = auth.uid());
CREATE POLICY partner_org_read ON partners.organisations FOR SELECT
  USING (id IN (SELECT org_id FROM partners.members WHERE auth_id = auth.uid()));
CREATE POLICY partner_campaigns_tenant ON partners.campaigns FOR SELECT
  USING (org_id IN (SELECT org_id FROM partners.members WHERE auth_id = auth.uid()));

-- No direct client policies are created for KYC writes, payments writes, knowledge corpus,
-- governance tables, or audit logs. Those operations must use narrowly scoped server roles/functions.
REVOKE ALL ON ALL TABLES IN SCHEMA governance FROM anon, authenticated;
REVOKE ALL ON sisters.knowledge_chunks FROM anon, authenticated;

-- Stronger append-only protection. The table owner/service migration role can still alter schema.
CREATE OR REPLACE FUNCTION governance.block_audit_mutation()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'governance.audit_log is append-only';
END; $$;
DROP TRIGGER IF EXISTS audit_log_no_update_delete ON governance.audit_log;
CREATE TRIGGER audit_log_no_update_delete
BEFORE UPDATE OR DELETE ON governance.audit_log
FOR EACH ROW EXECUTE FUNCTION governance.block_audit_mutation();

COMMIT;
