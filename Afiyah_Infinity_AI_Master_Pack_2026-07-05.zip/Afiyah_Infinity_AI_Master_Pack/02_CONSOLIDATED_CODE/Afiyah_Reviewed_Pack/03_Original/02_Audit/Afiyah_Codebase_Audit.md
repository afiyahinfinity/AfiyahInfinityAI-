# Afiyah Codebase Audit — vs Sprint 1 Master Document v3.0 (D-Pack)
**Date:** 4 July 2026 · Auditor: engineering + AI-governance + compliance lens

## 1. What is BUILT and matches the blueprint ✅

| Area | Evidence | Verdict |
|---|---|---|
| Core schema (sisters, goals, barakah_scores, daily_checkins, cycle_logs, audit log) | `001_afiyah_core_schema.sql` | ✅ Solid; RLS present |
| Islamic KB seed + approval_status workflow | `002_islamic_kb_seed.sql` | ✅ Matches Gap 18 mitigation |
| Analytics views | `003_analytics_views.sql` | ✅ |
| Signup flow + AI identity check + ID doc check (extract-and-discard, fail-open to human) | Week1 pack, `004_signup_flow.sql`, both Edge Functions | ✅ Confidence routing implemented |
| Admin queue + logged ID-document viewing | `app/admin/queue`, `api/admin/id-document` (inserts admin_action_log) | ✅ Gap 2 partially covered |
| Onboarding 5-screen + Barakah baseline (25/20/15/15/15/10) | Week2 pack, `barakah.ts`, `005_onboarding.sql` | ✅ Weights correct |
| Hash-chained AI audit (prompt_hash, row_hash) | present in 004 + both AI functions | ✅ Gap/B1 items 1–2 |
| Dashboard / check-in / goals UI | App, Check_in_App, GoalsApp, InfinityAppDashboard | ✅ (duplicated across 4 zips — consolidate) |

## 2. In the Master Document D-pack but NOT in the uploaded code 🔴

1. **`002_admin_security_and_recovery.sql`** (admin_users roles/2FA guard trigger) — the doc's SQL is not in any zip. `admin_users` is referenced in 004 but the full roles + `prevent_status_regression()` trigger is absent. **Also: migration numbering collision** — the doc's 002/003 clash with your shipped 002 (KB seed)/003 (analytics). Renumber D-pack files to 006/007.
2. **`003_timezone_streaks_notifications.sql`** — `local_date_for()`, `submit_checkin()`, `current_streak()`, `sisters_due_reminder` view: missing. Streaks will break across Dubai/Dhaka (Gap 4, red).
3. **`nightly-backup` Edge Function** — missing. Free tier = no PITR (Gap 5, red).
4. **`notification-cron`** — missing (Gaps 4+9).
5. **Password reset pages** (`/auth/reset-password`, `/auth/update-password`) — missing (Gap 1, red). Login page links to reset but no page exists.
6. **Admin `middleware.ts` enforcing AAL2/TOTP** — missing (Gap 2, red).
7. **RLS test suite** (`tests/rls.test.ts`) — missing (Gap 8; this is the women-only-space guarantee test).
8. **Sentry / function_errors** — missing (Gap 7).
9. **18+ attestation on signup form** — not found (Gap 11, red).
10. **Crisis-escalation template with UAE Estijaba 800-Hope** — not in coach-response (Gap 17, red — must ship before check-in goes live).

## 3. NEW scope from the seed-round brief, not yet in either codebase 🟡
- Payments & subscription tiers (no payment code anywhere; gateway selection pending — Telr / Network Intl / Tabby, riba-free rails only)
- Women-only KYC hardening beyond plausibility scoring (UAE PASS integration is Phase 2)
- Agentic mode for the AI buddy (proposal → approval → execution loop + `agent_actions` table)
- Partner-facing Shariah/risk/governance dashboards (founder dashboard exists in ceo.js; partner-visible version does not)

## 4. 🔴 AI VENDOR COUPLING — your (B) directive
**Finding:** 5 files hardcode `api.anthropic.com` + model strings (`ai-identity-check`, `id-document-check`, `coach-response`, `barakah-baseline`, plus model names written into audit-log rows). `coach-response` also references an OpenAI key — two vendors, zero abstraction.

**Risk:** vendor lock-in contradicts the corrected investor deck ("leading LLM provider", vendor-neutral); a pricing/policy change forces edits in 5 places; audit rows leak vendor names into what should be a neutral governance record.

**Fix (shipped alongside this report): `_shared/llm-gateway.ts`** — one adapter, provider chosen by env var (`LLM_PROVIDER=anthropic|openai|azure|local`), with:
- Two abstract tiers: `fast` (classification) and `standard` (generation) — functions never name a model
- Uniform `completeJSON()` with fencing, retries, fail-open null
- Audit rows record `provider_tier` + config version, not vendor model strings
- Kill-switch (`AI_ENABLED`) checked centrally — implements B1 item 6 once for all functions
- Swap vendors by changing 2 env vars; zero code edits

**Refactor cost:** ~1–2 hours: replace each inline `fetch` with `llm.completeJSON(tier, prompt)` in the 4 Edge Functions.

## 5. Recommended order (Bismillah sequence)
1. Ship llm-gateway + refactor 4 functions (vendor-neutral before any new AI code)
2. Renumber + apply D-pack migrations as 006 (admin security) / 007 (timezone)
3. Password reset pages + admin middleware + 18+ attestation
4. nightly-backup + restore drill; RLS test suite green on staging
5. Crisis template into coach-response (blocks check-in launch)
6. Then new scope: agent_actions table + approval-gated agentic loop, payments, partner dashboards
