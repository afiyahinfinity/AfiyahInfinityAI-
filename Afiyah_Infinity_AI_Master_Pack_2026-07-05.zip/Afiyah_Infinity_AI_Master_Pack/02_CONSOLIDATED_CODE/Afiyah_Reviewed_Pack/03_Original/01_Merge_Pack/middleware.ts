// Gap 2 — gates every /admin route: active admin_users row, TOTP
// enrolled, AAL2 session. Role gates for super_admin-only areas.
import { createMiddlewareClient } from "@supabase/auth-helpers-nextjs";
import { NextResponse, type NextRequest } from "next/server";

export async function middleware(req: NextRequest) {
  if (!req.nextUrl.pathname.startsWith("/admin")) return NextResponse.next();
  const res = NextResponse.next();
  const supabase = createMiddlewareClient({ req, res });
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) return NextResponse.redirect(new URL("/admin/login", req.url));

  const { data: admin } = await supabase
    .from("admin_users")
    .select("role, is_active, totp_enrolled")
    .eq("id", session.user.id)
    .maybeSingle();
  if (!admin?.is_active) return NextResponse.redirect(new URL("/", req.url));

  const { data: aal } = await supabase.auth.mfa.getAuthenticatorAssuranceLevel();
  if (aal?.currentLevel !== "aal2") {
    const dest = admin.totp_enrolled ? "/admin/verify-2fa" : "/admin/enroll-2fa";
    return NextResponse.redirect(new URL(dest, req.url));
  }
  const superOnly = ["/admin/settings", "/admin/admins", "/admin/governance"];
  if (superOnly.some((p) => req.nextUrl.pathname.startsWith(p)) && admin.role !== "super_admin") {
    return NextResponse.redirect(new URL("/admin/queue", req.url));
  }
  return res;
}
export const config = { matcher: ["/admin/:path*"] };
