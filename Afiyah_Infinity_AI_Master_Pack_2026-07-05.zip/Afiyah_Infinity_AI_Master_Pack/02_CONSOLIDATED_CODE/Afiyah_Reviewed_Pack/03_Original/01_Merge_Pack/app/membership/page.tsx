// Membership tiers + riba-free payment intent. Gateway integration
// (Telr / Network Intl / Tabby Shariah-split) completes server-side;
// this page creates the subscription intent and hands off to the
// gateway's hosted page — no card data ever touches Afiyah.
"use client";
import { useEffect, useState } from "react";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";
const G = "#C9A84C", BG = "#0A1F14", BG2 = "#142D1E", IV = "#EDE6D3", RO = "#D4919F";

export default function MembershipPage() {
  const supabase = createClientComponentClient();
  const [tiers, setTiers] = useState<any[]>([]);
  const [cycle, setCycle] = useState<"monthly" | "annual">("monthly");
  const [msg, setMsg] = useState("");

  useEffect(() => {
    supabase.from("plan_tiers").select("*").eq("is_active", true)
      .then(({ data }) => setTiers(data ?? []));
  }, [supabase]);

  async function choose(tier: string) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setMsg("Please sign in first."); return; }
    // Create the subscription intent; payment capture happens via the
    // gateway webhook (service role) which flips status trial→active.
    const { error } = await supabase.from("subscriptions")
      .insert({ sister_id: user.id, tier, billing_cycle: cycle });
    setMsg(error ? "Could not start checkout — try again." :
      `Bismillah — ${tier} selected. Redirecting to secure riba-free checkout…`);
    // window.location.href = `/api/checkout?tier=${tier}&cycle=${cycle}` (gateway hosted page)
  }

  return (
    <main style={{ minHeight: "100vh", background: BG, color: IV, fontFamily: "Georgia, serif", padding: 24 }}>
      <div style={{ maxWidth: 900, margin: "40px auto" }}>
        <h1 style={{ color: G }}>Membership</h1>
        <p style={{ opacity: 0.8 }}>All payment rails are riba-free — enforced at the database level, not just in policy.</p>
        <div style={{ margin: "12px 0" }}>
          {(["monthly", "annual"] as const).map((c) => (
            <button key={c} onClick={() => setCycle(c)} style={{
              marginRight: 8, padding: "8px 18px", borderRadius: 8, cursor: "pointer",
              background: cycle === c ? G : "transparent", color: cycle === c ? BG : G, border: `1px solid ${G}`,
            }}>{c === "monthly" ? "Monthly" : "Annual (2 months free)"}</button>
          ))}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(240px,1fr))", gap: 16 }}>
          {tiers.map((t) => (
            <div key={t.tier} style={{ background: BG2, border: `1px solid ${t.tier === "legacy" ? G : G + "44"}`, borderRadius: 12, padding: 20 }}>
              <h2 style={{ color: t.tier === "legacy" ? G : IV, textTransform: "capitalize", marginTop: 0 }}>
                {t.tier} {t.tier === "legacy" && <span style={{ fontSize: 12, color: RO }}>· most loved</span>}
              </h2>
              <div style={{ fontSize: 28, color: G }}>
                AED {cycle === "monthly" ? t.price_aed : t.annual_aed}
                <span style={{ fontSize: 13, color: IV }}>/{cycle === "monthly" ? "mo" : "yr"}</span>
              </div>
              <ul style={{ paddingLeft: 18, lineHeight: 1.8, fontSize: 14 }}>
                {(t.features ?? []).map((f: string) => <li key={f}>{f}</li>)}
              </ul>
              <button onClick={() => choose(t.tier)} style={{ width: "100%", background: G, color: BG, border: "none", borderRadius: 8, padding: 12, fontWeight: 700, cursor: "pointer" }}>
                Choose {t.tier}
              </button>
            </div>
          ))}
        </div>
        {msg && <p style={{ color: G, marginTop: 16 }}>{msg}</p>}
        <p style={{ fontSize: 12, opacity: 0.6, marginTop: 20 }}>
          Cards via Telr / Network International · Apple Pay · Tabby Shariah-compliant split · AED bank transfer.
          PCI-DSS handled by the gateway; Afiyah stores references only, never card data.
        </p>
      </div>
    </main>
  );
}
