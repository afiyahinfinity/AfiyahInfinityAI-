// ============================================================
// app/signup/page.tsx — Sisters Portal signup (Week 1)
// 3 steps: Account → Eligibility & Consent → Email sent.
// Gap 11 (18+) and consent capture (B4 items 1–3) built in.
// Brand: dark forest green / gold (Afiyah palette).
// ============================================================
"use client";

import { useState } from "react";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";

const C = {
  bg: "#0A1F14", card: "#142D1E", border: "#1E3D28",
  gold: "#C9A84C", teal: "#2E9E80", text: "#EDE6D3",
  sub: "#A8C0AF", err: "#E07A5F",
};

const COUNTRIES = [
  ["AE", "United Arab Emirates"], ["BD", "Bangladesh"], ["SA", "Saudi Arabia"],
  ["GB", "United Kingdom"], ["US", "United States"], ["PK", "Pakistan"],
  ["IN", "India"], ["MY", "Malaysia"], ["ID", "Indonesia"], ["OTHER", "Other"],
];

export default function SignupPage() {
  const supabase = createClientComponentClient();
  const [attest18, setAttest18] = useState(false);
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const [form, setForm] = useState({
    displayName: "", email: "", password: "", country: "AE",
    dob: "", ageAttested: false, tosAccepted: false, privacyAccepted: false,
  });
  const set = (k: string, v: any) => setForm((f) => ({ ...f, [k]: v }));

  // ── validation ──
  function validateStep1(): string | null {
    if (form.displayName.trim().split(/\s+/).length < 2)
      return "Please enter your full name (first and last).";
    if (!/^\S+@\S+\.\S+$/.test(form.email)) return "Please enter a valid email.";
    if (form.password.length < 10) return "Password must be at least 10 characters.";
    if (!/[0-9]/.test(form.password) || !/[a-zA-Z]/.test(form.password))
      return "Password needs at least one letter and one number.";
    return null;
  }

  function isAdult(dob: string): boolean {
    if (!dob) return false;
    const d = new Date(dob);
    const cutoff = new Date(); cutoff.setFullYear(cutoff.getFullYear() - 18);
    return d <= cutoff;
  }

  function validateStep2(): string | null {
    if (!form.dob) return "Please enter your date of birth.";
    if (!isAdult(form.dob))
      return "Afiyah is for women aged 18 and above. We're not able to open your account yet — we'd love to welcome you when you turn 18, in shā' Allāh.";
    if (!form.ageAttested) return "Please confirm you are 18 or older.";
    if (!form.tosAccepted) return "Please accept the Terms of Service.";
    if (!form.privacyAccepted) return "Please accept the Privacy Policy.";
    return null;
  }

  // ── submit ──
  async function submit() {
    const v = validateStep2();
    if (v) return setErr(v);
    setErr(null); setBusy(true);

    const now = new Date().toISOString();
    const { data, error } = await supabase.auth.signUp({
      email: form.email.trim().toLowerCase(),
      password: form.password,
      options: {
        emailRedirectTo: `${location.origin}/verify-email`,
        data: { display_name: form.displayName.trim() },
      },
    });

    if (error) { setBusy(false); return setErr(friendlyAuthError(error.message)); }

    // Profile row with consent timestamps (RLS: insert own row).
    if (data.user) {
      await supabase.from("sisters").insert({
        id: data.user.id,
        email: form.email.trim().toLowerCase(),
        display_name: form.displayName.trim(),
        country_code: form.country,
        date_of_birth: form.dob,
        age_attested_at: now,
        tos_accepted_at: now,
        privacy_accepted_at: now,
        status: "registered",
      });
    }
    setBusy(false);
    setStep(3);
  }

  // ── UI ──
  return (
    <main style={{ minHeight: "100vh", background: C.bg, color: C.text,
      fontFamily: "'Jost','Segoe UI',sans-serif", display: "flex",
      alignItems: "center", justifyContent: "center", padding: 20 }}>
      <div style={{ width: "100%", maxWidth: 440, background: C.card,
        border: `1px solid ${C.border}`, borderRadius: 14, padding: 28 }}>

        <div style={{ textAlign: "center", marginBottom: 22 }}>
          <div style={{ color: C.gold, fontSize: 24, fontWeight: 800 }}>Afiyah ∞</div>
          <div style={{ color: C.sub, fontSize: 13, marginTop: 4 }}>Sisters Portal — Create your account</div>
        </div>

        {/* progress */}
        <div style={{ display: "flex", gap: 6, marginBottom: 24 }}>
          {[1, 2, 3].map((s) => (
            <div key={s} style={{ flex: 1, height: 3, borderRadius: 2,
              background: step >= s ? C.gold : C.border }} />
          ))}
        </div>

        {err && (
          <div style={{ background: C.err + "18", border: `1px solid ${C.err}55`,
            color: C.err, borderRadius: 8, padding: "10px 14px",
            fontSize: 13, lineHeight: 1.6, marginBottom: 16 }}>{err}</div>
        )}

        {step === 1 && (
          <>
            <Field label="Full name">
              <input value={form.displayName} onChange={(e) => set("displayName", e.target.value)}
                placeholder="e.g. Amina Rahman" style={inp} autoComplete="name" />
            </Field>
            <Field label="Email">
              <input type="email" value={form.email} onChange={(e) => set("email", e.target.value)}
                placeholder="you@example.com" style={inp} autoComplete="email" />
            </Field>
            <Field label="Password" hint="At least 10 characters, with a letter and a number.">
              <input type="password" value={form.password} onChange={(e) => set("password", e.target.value)}
                style={inp} autoComplete="new-password" />
            </Field>
            <Field label="Country">
              <select value={form.country} onChange={(e) => set("country", e.target.value)} style={inp}>
                {COUNTRIES.map(([code, name]) => <option key={code} value={code}>{name}</option>)}
              </select>
            </Field>
            <label style={{ display: "flex", gap: 8, alignItems: "flex-start", fontSize: 13, margin: "12px 0" }}>
          <input type="checkbox" checked={attest18} onChange={(e) => setAttest18(e.target.checked)} />
          <span>I confirm that I am <b>18 years of age or older</b>. Afiyah is for adult women only; accounts for minors are not permitted (Terms of Service, PDPL/GDPR).</span>
        </label>
        <button style={btn} onClick={() => {
              const v = validateStep1(); if (v) return setErr(v);
              setErr(null); setStep(2);
            }}>Continue</button>
            <p style={{ textAlign: "center", fontSize: 13, color: C.sub, marginTop: 14 }}>
              Already a sister? <a href="/login" style={{ color: C.gold }}>Sign in</a>
            </p>
          </>
        )}

        {step === 2 && (
          <>
            <Field label="Date of birth" hint="Afiyah is for women aged 18 and above.">
              <input type="date" value={form.dob} onChange={(e) => set("dob", e.target.value)}
                max={new Date().toISOString().slice(0, 10)} style={inp} />
            </Field>

            <Check checked={form.ageAttested} onChange={(v) => set("ageAttested", v)}
              label="I confirm I am a woman aged 18 or older." />
            <Check checked={form.tosAccepted} onChange={(v) => set("tosAccepted", v)}
              label={<>I accept the <a href="/legal/terms" target="_blank" style={{ color: C.gold }}>Terms of Service</a>.</>} />
            <Check checked={form.privacyAccepted} onChange={(v) => set("privacyAccepted", v)}
              label={<>I accept the <a href="/legal/privacy" target="_blank" style={{ color: C.gold }}>Privacy Policy</a>, including how identity documents are handled and deleted after 60 days.</>} />

            <div style={{ background: C.teal + "12", border: `1px solid ${C.teal}40`,
              borderRadius: 8, padding: "10px 14px", fontSize: 12.5,
              color: C.sub, lineHeight: 1.7, margin: "14px 0" }}>
              An AI assists our team in reviewing applications; a human always makes
              the final decision. Cycle and health features are optional and ask for
              separate consent later — nothing is on by default.
            </div>

            <button style={btn} disabled={busy} onClick={submit}>
              {busy ? "Creating account…" : "Create my account"}
            </button>
            <button style={{ ...btn, background: "transparent", color: C.sub,
              border: `1px solid ${C.border}`, marginTop: 8 }}
              onClick={() => setStep(1)}>Back</button>
          </>
        )}

        {step === 3 && (
          <div style={{ textAlign: "center", padding: "12px 0" }}>
            <div style={{ fontSize: 40, marginBottom: 10 }}>✉️</div>
            <h2 style={{ color: C.gold, margin: "0 0 10px" }}>Check your inbox</h2>
            <p style={{ color: C.sub, fontSize: 14, lineHeight: 1.8 }}>
              We've sent a verification link to <b style={{ color: C.text }}>{form.email}</b>.
              Click it to confirm your email, then we'll guide you through a quick,
              private identity check. Most sisters are verified within 48 hours.
            </p>
          </div>
        )}
      </div>
    </main>
  );
}

// ── small components / styles ──
const inp: React.CSSProperties = {
  width: "100%", padding: "11px 13px", borderRadius: 8,
  border: "1px solid #1E3D28", background: "#0F2519",
  color: "#EDE6D3", fontSize: 14, outline: "none",
};
const btn: React.CSSProperties = {
  width: "100%", padding: "12px", borderRadius: 8, border: "none",
  background: "#C9A84C", color: "#0A1F14", fontWeight: 700,
  fontSize: 14, cursor: "pointer", marginTop: 6,
};
function Field({ label, hint, children }: any) {
  return (
    <label style={{ display: "block", marginBottom: 14 }}>
      <div style={{ fontSize: 12, color: "#A8C0AF", fontWeight: 600,
        letterSpacing: 0.5, marginBottom: 6 }}>{label.toUpperCase()}</div>
      {children}
      {hint && <div style={{ fontSize: 11.5, color: "#5A7A62", marginTop: 5 }}>{hint}</div>}
    </label>
  );
}
function Check({ checked, onChange, label }: any) {
  return (
    <label style={{ display: "flex", gap: 10, alignItems: "flex-start",
      fontSize: 13, color: "#EDE6D3", lineHeight: 1.6, marginBottom: 10, cursor: "pointer" }}>
      <input type="checkbox" checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        style={{ marginTop: 3, accentColor: "#C9A84C" }} />
      <span>{label}</span>
    </label>
  );
}
function friendlyAuthError(msg: string): string {
  if (msg.includes("already registered"))
    return "An account with this email already exists. Try signing in, or reset your password.";
  if (msg.toLowerCase().includes("rate"))
    return "Too many attempts — please wait a minute and try again.";
  return "Something went wrong creating your account. Please try again.";
}
