// Gap 1 — landing page for the reset link. Sets the new password and
// signs her back into her UNCHANGED, still-verified account.
"use client";
import { useEffect, useState } from "react";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";
import { useRouter } from "next/navigation";
const MIN_LEN = 10;

export default function UpdatePasswordPage() {
  const supabase = createClientComponentClient();
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [pw, setPw] = useState(""); const [pw2, setPw2] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY" || event === "SIGNED_IN") setReady(true);
    });
  }, [supabase]);

  async function save() {
    setErr(null);
    if (pw.length < MIN_LEN) return setErr(`Password must be at least ${MIN_LEN} characters.`);
    if (pw !== pw2) return setErr("Passwords don't match.");
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password: pw });
    setBusy(false);
    if (error) return setErr(error.message);
    router.replace("/dashboard?pw_reset=ok");
  }

  if (!ready) return (
    <main style={{ maxWidth: 420, margin: "80px auto", padding: 24 }}>
      <p>Validating your reset link… If this takes more than a few seconds, the link may have expired — <a href="/auth/reset-password">request a new one</a>.</p>
    </main>
  );
  return (
    <main style={{ maxWidth: 420, margin: "80px auto", padding: 24, background: "#0A1F14", color: "#EDE6D3", borderRadius: 12 }}>
      <h1 style={{ color: "#C9A84C", fontFamily: "Georgia, serif" }}>Choose a new password</h1>
      <input type="password" placeholder={`New password (min ${MIN_LEN} chars)`} value={pw}
        onChange={(e) => setPw(e.target.value)} style={{ width: "100%", padding: 12, margin: "8px 0", borderRadius: 8 }} />
      <input type="password" placeholder="Repeat new password" value={pw2}
        onChange={(e) => setPw2(e.target.value)} style={{ width: "100%", padding: 12, margin: "8px 0", borderRadius: 8 }} />
      {err && <p style={{ color: "#E07A5F" }}>{err}</p>}
      <button onClick={save} disabled={busy}
        style={{ background: "#C9A84C", color: "#0A1F14", padding: "12px 28px", borderRadius: 8, fontWeight: 700, border: "none" }}>
        {busy ? "Saving…" : "Save and sign in"}
      </button>
    </main>
  );
}
