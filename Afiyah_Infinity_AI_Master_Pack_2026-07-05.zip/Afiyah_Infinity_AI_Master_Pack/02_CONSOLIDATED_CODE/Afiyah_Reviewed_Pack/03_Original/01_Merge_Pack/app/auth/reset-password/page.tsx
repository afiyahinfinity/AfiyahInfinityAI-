// Gap 1 — "Forgot password". Identical response whether the account
// exists or not (no enumeration). Reset NEVER touches verified status
// (migration 006 trigger trg_sisters_status_guard).
"use client";
import { useState } from "react";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";

export default function ResetPasswordPage() {
  const supabase = createClientComponentClient();
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  async function handleSubmit() {
    if (!email || busy) return;
    setBusy(true);
    await supabase.auth.resetPasswordForEmail(email.trim().toLowerCase(), {
      redirectTo: `${location.origin}/auth/update-password`,
    });
    setSent(true); setBusy(false);
  }
  return (
    <main style={{ maxWidth: 420, margin: "80px auto", padding: 24, background: "#0A1F14", color: "#EDE6D3", borderRadius: 12 }}>
      <h1 style={{ color: "#C9A84C", fontFamily: "Georgia, serif" }}>Reset your password</h1>
      {sent ? (
        <p style={{ lineHeight: 1.7 }}>
          If an account exists for <b>{email}</b>, a reset link is on its way.
          The link is valid for 1 hour. Check your spam folder if you don't see it soon.
        </p>
      ) : (
        <>
          <p style={{ lineHeight: 1.7 }}>
            Enter the email you registered with and we'll send a secure link.<br />
            <small>Resetting your password does <b>not</b> affect your verified status — you will not need to re-verify your ID.</small>
          </p>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
            style={{ width: "100%", padding: 12, margin: "12px 0", borderRadius: 8, border: "1px solid #C9A84C55", background: "#142D1E", color: "#EDE6D3" }} />
          <button onClick={handleSubmit} disabled={busy || !email}
            style={{ background: "#C9A84C", color: "#0A1F14", padding: "12px 28px", borderRadius: 8, fontWeight: 700, border: "none" }}>
            {busy ? "Sending…" : "Send reset link"}
          </button>
        </>
      )}
    </main>
  );
}
