// Partner-facing governance: Shariah rulings registry, risk register
// (partner_visible rows), governance summary, k>=25 audience insights.
"use client";
import { useEffect, useState } from "react";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";
const G = "#C9A84C", BG = "#0A1F14", BG2 = "#142D1E", IV = "#EDE6D3", TE = "#2E9E80", RD = "#E07A5F";

export default function PartnerGovernancePage() {
  const supabase = createClientComponentClient();
  const [tab, setTab] = useState<"shariah" | "risk" | "gov" | "insights">("shariah");
  const [rulings, setRulings] = useState<any[]>([]);
  const [risks, setRisks] = useState<any[]>([]);
  const [insights, setInsights] = useState<any[]>([]);

  useEffect(() => {
    supabase.from("shariah_rulings").select("*").order("effective_from", { ascending: false })
      .then(({ data }) => setRulings(data ?? []));
    supabase.from("risk_register").select("*").order("score", { ascending: false })
      .then(({ data }) => setRisks(data ?? []));
    supabase.from("partner_audience_insights").select("*")
      .then(({ data }) => setInsights(data ?? []));
  }, [supabase]);

  const rulingColor = (r: string) => r === "halal" ? TE : r === "haram" ? RD : G;
  const T = ({ id, label }: any) => (
    <button onClick={() => setTab(id)} style={{
      padding: "8px 18px", borderRadius: 8, marginRight: 8, cursor: "pointer",
      background: tab === id ? G : "transparent", color: tab === id ? BG : G, border: `1px solid ${G}`,
    }}>{label}</button>
  );

  return (
    <main style={{ minHeight: "100vh", background: BG, color: IV, fontFamily: "Georgia, serif", padding: 24 }}>
      <div style={{ maxWidth: 960, margin: "30px auto" }}>
        <h1 style={{ color: G }}>Governance & Compliance</h1>
        <p style={{ opacity: 0.75, fontSize: 14 }}>
          Amanah · Adl · Ihsan · Barakah — sister-level data is never visible to partners; insights are aggregates with k ≥ 25.
        </p>
        <div style={{ margin: "14px 0" }}>
          <T id="shariah" label="Shariah rulings" /><T id="risk" label="Risk register" />
          <T id="gov" label="Governance" /><T id="insights" label="Audience insights" />
        </div>

        {tab === "shariah" && (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead><tr style={{ color: G, textAlign: "left" }}>
              <th style={{ padding: 8 }}>Subject</th><th>Type</th><th>Ruling</th><th>Standard</th><th>Effective</th></tr></thead>
            <tbody>{rulings.map((r) => (
              <tr key={r.id} style={{ borderTop: "1px solid #ffffff15" }}>
                <td style={{ padding: 8 }}>{r.subject}</td>
                <td style={{ fontSize: 12, opacity: 0.7 }}>{r.subject_type}</td>
                <td><span style={{ color: rulingColor(r.ruling), textTransform: "capitalize" }}>{r.ruling}</span></td>
                <td style={{ fontSize: 12 }}>{r.standard_ref}</td>
                <td style={{ fontSize: 12 }}>{r.effective_from}</td>
              </tr>))}</tbody>
          </table>
        )}
        {tab === "risk" && risks.map((r) => (
          <div key={r.id} style={{ background: BG2, borderRadius: 10, padding: 14, marginBottom: 10, display: "flex", justifyContent: "space-between", gap: 12 }}>
            <div>
              <b style={{ textTransform: "capitalize" }}>{r.category.replace(/_/g, " ")}</b>
              <div style={{ fontSize: 13, opacity: 0.8 }}>{r.description}</div>
              <div style={{ fontSize: 12, opacity: 0.6 }}>Mitigation: {r.mitigation} · Owner: {r.owner}</div>
            </div>
            <div style={{ fontSize: 26, color: r.score >= 12 ? RD : G }}>{r.score}</div>
          </div>
        ))}
        {tab === "gov" && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(260px,1fr))", gap: 12 }}>
            {[["Runtime AI governance", "Every AI call writes an immutable, hash-chained audit row before the response is shown. Kill-switch + per-user quotas live."],
              ["Human accountability", "AI scores and flags; two human reviewers approve. 48h SLA. Amanah preserved."],
              ["Data protection", "RLS on every table; cycle data never reaches AI raw; 60-day ID deletion with proof log; PDPL/GDPR consent flows."],
              ["Shariah board", "ADL Advisory quarterly audits; action registry gates every agentic capability; educational-not-fatwa disclosure."],
              ["Security", "Admin 2FA (AAL2) enforced by middleware; nightly encrypted backups; RLS test suite on every migration."],
              ["Vendor neutrality", "AI agents are proprietary orchestration; underlying models are interchangeable providers under no-training terms."],
            ].map(([t, d]) => (
              <div key={t} style={{ background: BG2, borderLeft: `3px solid ${G}`, borderRadius: 8, padding: 14 }}>
                <b style={{ color: G }}>{t}</b>
                <p style={{ fontSize: 13, opacity: 0.85, lineHeight: 1.6 }}>{d}</p>
              </div>
            ))}
          </div>
        )}
        {tab === "insights" && (
          <>
            <p style={{ fontSize: 13, opacity: 0.7 }}>Aggregates only — cohorts under 25 sisters are never shown.</p>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(160px,1fr))", gap: 12 }}>
              {insights.map((i) => (
                <div key={i.emirate} style={{ background: BG2, borderRadius: 10, padding: 16, textAlign: "center" }}>
                  <div style={{ fontSize: 26, color: G }}>{i.sisters}</div>
                  <div style={{ fontSize: 13 }}>{i.emirate}</div>
                  <div style={{ fontSize: 12, opacity: 0.6 }}>avg Barakah {i.avg_barakah}</div>
                </div>
              ))}
              {!insights.length && <p style={{ opacity: 0.6 }}>No cohort has reached the k ≥ 25 threshold yet.</p>}
            </div>
          </>
        )}
      </div>
    </main>
  );
}
