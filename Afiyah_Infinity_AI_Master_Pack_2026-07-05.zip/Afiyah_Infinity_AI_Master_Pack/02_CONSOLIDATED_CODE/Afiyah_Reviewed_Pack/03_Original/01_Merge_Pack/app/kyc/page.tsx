// Women-only KYC stepper — reads kyc_steps (008), reuses existing
// upload-id + verification flow; adds 18+ attestation + screening view.
"use client";
import { useEffect, useState } from "react";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";

const STEPS = [
  ["attestation", "18+ attestation"],
  ["identity_form", "Identity details"],
  ["document_upload", "ID document"],
  ["ai_screening", "Automated screening"],
  ["human_review", "Human review (48h)"],
  ["verified", "Verified"],
] as const;
const G = "#C9A84C", BG = "#0A1F14", BG2 = "#142D1E", IV = "#EDE6D3";

export default function KycPage() {
  const supabase = createClientComponentClient();
  const [steps, setSteps] = useState<Record<string, string>>({});
  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("kyc_steps").select("step, status");
      const map: Record<string, string> = {};
      (data ?? []).forEach((r: any) => (map[r.step] = r.status));
      setSteps(map);
    })();
  }, [supabase]);

  const activeIdx = STEPS.findIndex(([k]) => steps[k] !== "passed");
  return (
    <main style={{ minHeight: "100vh", background: BG, color: IV, fontFamily: "Georgia, serif", padding: 24 }}>
      <div style={{ maxWidth: 560, margin: "40px auto", background: BG2, borderRadius: 12, padding: 28, border: `1px solid ${G}44` }}>
        <h1 style={{ color: G, marginTop: 0 }}>Your verification journey</h1>
        <p style={{ opacity: 0.8, lineHeight: 1.7 }}>
          Afiyah is a women-only space. Verification protects the sisterhood.
          Your ID is reviewed by AI <i>and</i> a human, never AI alone, and the
          document is automatically deleted 60 days after a decision.
        </p>
        <ol style={{ listStyle: "none", padding: 0, margin: "20px 0" }}>
          {STEPS.map(([key, label], i) => {
            const st = steps[key] ?? "pending";
            const done = st === "passed";
            const active = i === activeIdx;
            return (
              <li key={key} style={{ display: "flex", gap: 12, alignItems: "center", padding: "10px 0", borderBottom: "1px solid #ffffff12" }}>
                <span style={{
                  width: 26, height: 26, borderRadius: "50%", display: "grid", placeItems: "center",
                  background: done ? G : "transparent", color: done ? BG : G,
                  border: `2px solid ${done || active ? G : "#ffffff33"}`, fontSize: 13, fontWeight: 700,
                }}>{done ? "✓" : i + 1}</span>
                <span style={{ flex: 1, opacity: done || active ? 1 : 0.55 }}>{label}</span>
                {active && key === "attestation" && <a href="/signup" style={{ color: G }}>Confirm →</a>}
                {active && key === "document_upload" && <a href="/upload-id" style={{ color: G }}>Upload →</a>}
                {active && key === "human_review" && <span style={{ fontSize: 12, opacity: 0.7 }}>in progress</span>}
              </li>
            );
          })}
        </ol>
        <p style={{ fontSize: 12, opacity: 0.6 }}>
          Screening includes sanctions/PEP checks under our AML policy.
          A "potential match" simply means a human takes a careful look — most are cleared quickly.
        </p>
      </div>
    </main>
  );
}
