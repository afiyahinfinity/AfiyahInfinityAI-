# Afiyah Merge Pack — Sequence Executed (4 July 2026)
Single source of truth remains the Sprint 1 Master Document v3.0. This pack implements the founder-approved 6-step sequence.

## 1 ✅ Vendor-neutral AI (founder directive)
`supabase/functions/_shared/llm-gateway.ts` — tiers not models; chat + vision + embeddings; kill-switch; provider via env.
All 4 AI functions refactored IN PLACE (these files REPLACE your existing ones):
- `ai-identity-check` → completeJSON("fast")
- `id-document-check` → completeVisionJSON("standard")
- `barakah-baseline` → completeJSON("standard")
- `coach-response` → complete("standard") + embed() — OpenAI branch deleted
Audit rows now record `provider_tier` (e.g. standard@v1), never vendor names.

Secrets:
  supabase secrets set AI_ENABLED=true LLM_PROVIDER=anthropic LLM_API_KEY=... \
    LLM_MODEL_FAST=<fast-model> LLM_MODEL_STANDARD=<standard-model> \
    LLM_CONFIG_VERSION=v1 EMBED_BASE_URL=... EMBED_API_KEY=... EMBED_MODEL=...

## 2 ✅ D-pack migrations renumbered
- `006_admin_security_and_recovery.sql` (was doc's 002)
- `007_timezone_streaks_notifications.sql` (was doc's 003)
Apply to STAGING first, then production. Order: 006 → 007 → 008 → 009 → 010 → 011.

## 3 ✅ Auth + admin + attestation
- `app/auth/reset-password` + `app/auth/update-password` (Gap 1)
- `middleware.ts` — AAL2/TOTP gate on /admin (Gap 2)
- `app/signup_page_PATCHED.tsx` — diff into your signup page: adds 18+ attestation (Gap 11)

## 4 ✅ Backups + RLS suite
- `supabase/functions/nightly-backup` — cron 0 23 * * *; includes merge-pack tables. RESTORE DRILL required once in staging.
- `tests/rls.test.ts` — extended: agentic tables, payments, plus two new invariants:
  sister cannot self-execute actions; non-riba-free payment rejected at DB level.
  Sprint gate: suite green on staging before deploy.

## 5 ✅ Crisis template (Gap 17 — was blocking check-in launch)
`coach-response` now detects mental-health crisis language BEFORE any generation and returns the human-reviewed template with region-aware helplines (UAE Estijaba 800-HOPE / BD Kaan Pete Roi + emergency numbers) and human follow-up. VERIFY HELPLINE NUMBERS AT DEPLOY TIME and route a copy to the human queue.

## 6 ✅ New scope
- `008_kyc_hardening.sql` — kyc_steps state machine, 18+ column, AML/PEP screening fields
- `009_agentic_noor.sql` — agent_sessions/messages/actions, Shariah action registry, quotas, admin-set nisab rate
- `010_payments.sql` — plan_tiers seeded (AED 49/149/399), subscriptions, payments with DB-level riba-free trigger, webhook idempotency, append-only events
- `011_partner_governance.sql` — shariah_rulings, risk_register (B2 seeded), k≥25 insights view
- Edge: `noor-agent` (proposes) + `agent-execute` (executes only sister-approved actions; deterministic, ownership-checked, registry-gated)
- Pages: `/noor`, `/kyc`, `/membership`, `/partner/governance`

## Deploy order
1. Staging: migrations 006–011 → RLS suite green
2. Deploy _shared + 6 Edge Functions; set secrets; crons (backup 23:00 UTC)
3. Ship pages + middleware; diff signup attestation
4. Insert admin_users (founder super_admin + reviewer, NDA + TOTP) before queue use
5. Seed shariah_rulings with board resolutions; set gold_aed_per_gram
6. Restore drill; then production.

## Open items (unchanged from audit)
Payment gateway contract (Telr/Network Intl/Tabby) + webhook Edge Function · notification-cron deploy (code in Master Doc D4.2) · Sentry wiring · UAE PASS (Phase 2).
