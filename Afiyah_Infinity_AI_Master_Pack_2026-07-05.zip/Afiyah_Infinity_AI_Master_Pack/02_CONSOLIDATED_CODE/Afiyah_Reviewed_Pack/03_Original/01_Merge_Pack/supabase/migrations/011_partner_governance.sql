-- ============================================================
-- 011_partner_governance.sql — Partner-facing Shariah / Risk /
-- Governance dashboards + k-anonymous audience insights.
-- Hard rule: partners NEVER see sister-level rows. Ever.
-- ============================================================

-- Shariah rulings registry (partner-visible; ADL Advisory writes)
create table if not exists shariah_rulings (
  id             uuid primary key default gen_random_uuid(),
  subject        text not null,
  subject_type   text not null check (subject_type in
                 ('feature','agent_action','partner_offering','content','payment_rail')),
  ruling         text not null check (ruling in ('halal','conditional','haram','pending')),
  standard_ref   text,                       -- AAOIFI SS-xx / board resolution
  board_signatory text not null,
  effective_from date not null default current_date,
  notes          text,
  is_public      boolean not null default true   -- visible in partner portal
);
alter table shariah_rulings enable row level security;
create policy "partners read public rulings" on shariah_rulings
  for select using (
    is_public and exists (select 1 from partners p where p.id = auth.uid())
    or is_admin()
  );
create policy "admins manage rulings" on shariah_rulings
  for all using (is_admin('super_admin'));

-- Enterprise risk register (Master Doc B2 made queryable)
create table if not exists risk_register (
  id          uuid primary key default gen_random_uuid(),
  category    text not null check (category in
              ('shariah_non_compliance','aml_cft','data_privacy','ai_model',
               'operational','cyber','regulatory')),
  description text not null,
  likelihood  int not null check (likelihood between 1 and 5),
  impact      int not null check (impact between 1 and 5),
  score       int generated always as (likelihood * impact) stored,
  mitigation  text,
  owner       text,
  review_due  date,
  partner_visible boolean not null default false
);
alter table risk_register enable row level security;
create policy "admins manage risks" on risk_register
  for all using (is_admin());
create policy "partners read flagged risks" on risk_register
  for select using (
    partner_visible and exists (select 1 from partners p where p.id = auth.uid())
  );

-- Seed from Master Document B2 (admin-visible; founder can flip
-- partner_visible per row for diligence rooms)
insert into risk_register (category, description, likelihood, impact, mitigation, owner) values
  ('shariah_non_compliance','Product/feature ships without board ruling',2,5,'agent_action_registry + rulings gate; quarterly audit','Shariah Board'),
  ('aml_cft','Sanctioned/PEP individual onboards',2,5,'Screening at KYC (008); potential_match → human queue','MLRO'),
  ('ai_model','Hallucinated guidance reads as fatwa/medical advice',3,4,'Retrieval-only KB; templates; crisis escalation; report button','CTO'),
  ('data_privacy','Sister PII exposure to partners',1,5,'RLS + k>=25 aggregate views only; RLS test suite','DPO'),
  ('cyber','Account takeover / admin surface breach',3,4,'2FA AAL2 middleware (006); rate limits; audit log','CTO'),
  ('regulatory','DIFC/PDPL evidence request unanswered',2,4,'Hash-chained audit log; monthly archived governance report','Founder')
on conflict do nothing;

-- K-ANONYMOUS audience insights (k >= 25). SECURITY DEFINER view
-- computed over sisters but exposing only aggregates.
create or replace view partner_audience_insights
with (security_invoker = false) as
  select
    coalesce(s.emirate, 'Unknown')        as emirate,
    count(*)                              as sisters,
    round(avg(b.composite_score))         as avg_barakah
  from sisters s
  left join barakah_scores b on b.sister_id = s.id
  where s.status = 'verified'
  group by coalesce(s.emirate, 'Unknown')
  having count(*) >= 25;

comment on view partner_audience_insights is
  'k-anonymity >= 25. The ONLY sister-derived surface partners may query.';

-- Partner portal read grant is via PostgREST role policies on the view;
-- underlying tables remain fully RLS-locked to the sister herself.
