-- ============================================================
-- 007_timezone_streaks_notifications.sql (Master Doc D2.2,
-- renumbered from 003). Solves Gap 4: TZ-correct streaks + reminders.
-- ============================================================
alter table user_preferences
  add column if not exists timezone text not null default 'Asia/Dubai',
  add column if not exists reminder_local_time time not null default '07:30',
  add column if not exists push_enabled boolean not null default false,
  add column if not exists email_reminders boolean not null default true;

create or replace function validate_timezone()
returns trigger language plpgsql as $$
begin
  perform now() at time zone new.timezone;
  return new;
exception when others then
  raise exception 'Invalid IANA timezone: %', new.timezone;
end $$;
drop trigger if exists trg_validate_tz on user_preferences;
create trigger trg_validate_tz before insert or update of timezone on user_preferences
  for each row execute function validate_timezone();

create or replace function local_date_for(p_user uuid)
returns date language sql stable security definer as $$
  select (now() at time zone coalesce(
    (select timezone from user_preferences where sister_id = p_user),'Asia/Dubai'))::date;
$$;

create or replace function submit_checkin(p_user uuid, p_answers jsonb)
returns daily_checkins language plpgsql security definer as $$
declare v_date date := local_date_for(p_user); v_row daily_checkins;
begin
  insert into daily_checkins (sister_id, date, answers)
  values (p_user, v_date, p_answers)
  on conflict (sister_id, date)
  do update set answers = excluded.answers, updated_at = now()
  returning * into v_row;
  return v_row;
end $$;

create or replace function current_streak(p_user uuid)
returns int language plpgsql stable security definer as $$
declare v_today date := local_date_for(p_user); v_streak int := 0; v_cursor date;
begin
  select max(date) into v_cursor from daily_checkins
    where sister_id = p_user and date in (v_today, v_today - 1);
  if v_cursor is null then return 0; end if;
  loop
    exit when not exists (select 1 from daily_checkins
      where sister_id = p_user and date = v_cursor);
    v_streak := v_streak + 1; v_cursor := v_cursor - 1;
  end loop;
  return v_streak;
end $$;

create or replace view sisters_due_reminder as
select s.id as sister_id, s.email, up.timezone, up.push_enabled,
       up.email_reminders, local_date_for(s.id) as her_today
from sisters s join user_preferences up on up.sister_id = s.id
where s.status = 'verified'
  and date_trunc('hour', (now() at time zone up.timezone))::time
      = date_trunc('hour', up.reminder_local_time::interval)::time
  and not exists (select 1 from daily_checkins dc
      where dc.sister_id = s.id and dc.date = local_date_for(s.id))
  and not exists (select 1 from notification_log nl
      where nl.sister_id = s.id and nl.type = 'daily_reminder'
        and (nl.sent_at at time zone up.timezone)::date = local_date_for(s.id));
