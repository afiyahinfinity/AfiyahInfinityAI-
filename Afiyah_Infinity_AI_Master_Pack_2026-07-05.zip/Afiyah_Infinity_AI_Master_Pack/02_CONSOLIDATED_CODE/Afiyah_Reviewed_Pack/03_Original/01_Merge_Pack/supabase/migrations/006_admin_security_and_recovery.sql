-- ============================================================
-- 006_admin_security_and_recovery.sql  (Master Doc D2.1, renumbered
-- from 002 to avoid collision with shipped 002_islamic_kb_seed)
-- Solves: Gap 1 (account recovery rules) + Gap 2 (admin auth & roles)
-- ============================================================
create table if not exists admin_users (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('super_admin','reviewer')),
  display_name text not null,
  nda_signed_at timestamptz,              -- reviewer confidentiality (Gap 20)
  totp_enrolled boolean not null default false,
  is_active boolean not null default true,
  created_at timestamptz default now()
);
alter table admin_users enable row level security;
create policy "admins read admin_users" on admin_users for select
  using (exists (select 1 from admin_users a where a.id = auth.uid() and a.is_active));
create policy "super_admin manages admin_users" on admin_users for all
  using (exists (select 1 from admin_users a
    where a.id = auth.uid() and a.role = 'super_admin' and a.is_active));

create or replace function is_admin(required_role text default null)
returns boolean language sql security definer stable as $$
  select exists (select 1 from admin_users
    where id = auth.uid() and is_active
      and (required_role is null or role = required_role));
$$;

create table if not exists admin_action_log (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid not null references admin_users(id),
  action text not null,
  entity_type text not null check (entity_type in ('sister','partner','kb_entry','system')),
  entity_id uuid,
  detail jsonb default '{}',
  created_at timestamptz default now()
);
alter table admin_action_log enable row level security;
create policy "admins read action log" on admin_action_log for select using (is_admin());
create policy "admins write own actions" on admin_action_log for insert
  with check (auth.uid() = admin_id and is_admin());

alter table admin_review_queue enable row level security;
create policy "admins read queue" on admin_review_queue for select using (is_admin());
create policy "admins claim and update queue" on admin_review_queue for update
  using (is_admin()) with check (assigned_to = auth.uid() or is_admin('super_admin'));

alter table ai_response_audit_log enable row level security;
create policy "admins read ai audit" on ai_response_audit_log for select using (is_admin());
-- deliberately NO update/delete policy: immutable (hash chain + no policy)

-- Gap 1: password reset must never change verification status
create or replace function prevent_status_regression()
returns trigger language plpgsql as $$
begin
  if new.status is distinct from old.status
     and current_setting('request.jwt.claims', true)::jsonb->>'role' <> 'service_role' then
    raise exception 'status may only be changed by the review system';
  end if;
  return new;
end $$;
drop trigger if exists trg_sisters_status_guard on sisters;
create trigger trg_sisters_status_guard before update on sisters
  for each row execute function prevent_status_regression();

-- Vendor-neutral audit note (llm-gateway)
comment on column ai_response_audit_log.model_used is
  'provider tier + config version (vendor-neutral), e.g. standard@v1';
