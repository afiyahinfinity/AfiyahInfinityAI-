-- ============================================================
-- 009_agentic_noor.sql — Noor's approval-gated agentic loop
-- Pattern (Master Document B1): AI proposes, human approves,
-- system executes, everything audited. AI is a reviewer/proposer,
-- never an autonomous actor on her data.
-- ============================================================

create table if not exists agent_sessions (
  id          uuid primary key default gen_random_uuid(),
  sister_id   uuid not null references sisters(id) on delete cascade,
  agent_name  text not null default 'noor',
  started_at  timestamptz default now(),
  ended_at    timestamptz
);
alter table agent_sessions enable row level security;
create policy "sister owns her sessions" on agent_sessions
  for all using (sister_id = auth.uid()) with check (sister_id = auth.uid());

create table if not exists agent_messages (
  id          bigserial primary key,
  session_id  uuid not null references agent_sessions(id) on delete cascade,
  sister_id   uuid not null references sisters(id) on delete cascade,
  role        text not null check (role in ('sister','noor','system')),
  content     text not null,
  created_at  timestamptz default now()
);
alter table agent_messages enable row level security;
create policy "sister owns her messages" on agent_messages
  for select using (sister_id = auth.uid());
-- inserts via service role only (Edge Function writes both sides)

-- The heart of "50% agentic": proposed actions awaiting HER approval.
create table if not exists agent_actions (
  id                uuid primary key default gen_random_uuid(),
  session_id        uuid not null references agent_sessions(id) on delete cascade,
  sister_id         uuid not null references sisters(id) on delete cascade,
  action_type       text not null check (action_type in
    ('create_goal','update_goal_progress','calc_zakat',
     'recommend_module','set_reminder_time','escalate_scholar')),
  payload           jsonb not null default '{}',
  proposal_reason   text,                         -- Noor's stated why (explainability, Gap 21)
  status            text not null default 'proposed'
                    check (status in ('proposed','approved','declined','executed','blocked')),
  shariah_gate      text not null default 'passed'
                    check (shariah_gate in ('passed','blocked','needs_review')),
  approved_at       timestamptz,
  executed_at       timestamptz,
  result_summary    text,
  audit_log_id      uuid,                          -- link to ai_response_audit_log row
  created_at        timestamptz default now()
);
alter table agent_actions enable row level security;
create policy "sister reads own actions" on agent_actions
  for select using (sister_id = auth.uid());
create policy "sister approves or declines own proposals" on agent_actions
  for update using (sister_id = auth.uid() and status = 'proposed')
  with check (status in ('approved','declined'));
-- execution/blocking only via service role; UPDATE policy above cannot
-- set status='executed' — the with-check clause forbids it.

create index if not exists idx_agent_actions_pending
  on agent_actions (sister_id) where status in ('proposed','approved');

-- Per-sister daily agentic quota (extends ai_usage pattern, B1 item 7)
create or replace function agent_quota_ok(p_sister uuid, p_daily_limit int default 10)
returns boolean language sql stable security definer as $$
  select count(*) < p_daily_limit
  from agent_actions
  where sister_id = p_sister
    and created_at > now() - interval '24 hours';
$$;

-- Allowed-action registry: the Shariah board approves the ACTION TYPES,
-- not each instance. Blocking a type here blocks it platform-wide.
create table if not exists agent_action_registry (
  action_type   text primary key,
  enabled       boolean not null default true,
  shariah_ref   text,                 -- board resolution reference
  requires_approval boolean not null default true,
  notes         text
);
insert into agent_action_registry (action_type, shariah_ref, notes) values
  ('create_goal',          'BR-2026-07', 'Wealth/wellness goals; no investment execution'),
  ('update_goal_progress', 'BR-2026-07', 'Progress logging only'),
  ('calc_zakat',           'BR-2026-07', 'Educational calculation; not a fatwa — nisab from admin-set rate'),
  ('recommend_module',     'BR-2026-07', 'Academy navigation'),
  ('set_reminder_time',    'BR-2026-07', 'Updates user_preferences.reminder_local_time'),
  ('escalate_scholar',     'BR-2026-07', 'Routes question to human scholar queue')
on conflict do nothing;

-- Admin-maintained nisab rate (so zakat math never depends on the model)
create table if not exists reference_rates (
  key         text primary key,          -- 'gold_aed_per_gram'
  value       numeric not null,
  updated_by  uuid,
  updated_at  timestamptz default now()
);
insert into reference_rates (key, value) values ('gold_aed_per_gram', 285)
on conflict do nothing;
