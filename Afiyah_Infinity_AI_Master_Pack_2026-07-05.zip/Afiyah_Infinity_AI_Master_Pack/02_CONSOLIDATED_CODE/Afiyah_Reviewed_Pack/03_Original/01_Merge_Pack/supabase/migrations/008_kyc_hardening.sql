-- ============================================================
-- 008_kyc_hardening.sql — Women-only KYC stepper (merge pack)
-- Extends sister_verifications (001/004) — does NOT replace it.
-- Numbering: 006/007 are reserved for the renumbered D-pack
-- migrations (admin security, timezone) from the Master Document.
-- ============================================================

-- 18+ attestation (Gap 11, red) + KYC step tracking
alter table sisters
  add column if not exists attested_18plus_at timestamptz,
  add column if not exists emirate text
    check (emirate in ('Dubai','Abu Dhabi','Sharjah','Ajman',
                       'Umm Al Quwain','Ras Al Khaimah','Fujairah','Outside UAE'));

-- Step-by-step KYC state machine (drives the stepper UI)
create table if not exists kyc_steps (
  id           uuid primary key default gen_random_uuid(),
  sister_id    uuid not null references sisters(id) on delete cascade,
  step         text not null check (step in
               ('attestation','identity_form','document_upload',
                'ai_screening','human_review','verified')),
  status       text not null default 'pending'
               check (status in ('pending','in_progress','passed','failed','skipped')),
  detail       jsonb default '{}',
  completed_at timestamptz,
  unique (sister_id, step)
);
alter table kyc_steps enable row level security;
create policy "sister reads own kyc steps" on kyc_steps
  for select using (sister_id = auth.uid());
-- Writes only via service role (Edge Functions / admin API).

-- AML/CFT screening result (DIFC AML Rulebook readiness).
-- Screening runs server-side against list providers in Phase 2;
-- Sprint stores the outcome + provider ref only. No raw PII beyond
-- what sisters/sister_verifications already hold.
alter table sister_verifications
  add column if not exists pep_screened boolean default false,
  add column if not exists sanctions_screened boolean default false,
  add column if not exists screening_provider text,
  add column if not exists screening_ref text,
  add column if not exists screening_result text
    check (screening_result in ('clear','potential_match','confirmed_match') or screening_result is null);

-- Confirmed sanction match freezes the account via existing status flow.
comment on column sister_verifications.screening_result is
  'clear | potential_match (→ human review queue) | confirmed_match (→ reject + report per AML SOP)';

-- Seed the six steps at signup (call from on_signup trigger/function)
create or replace function seed_kyc_steps(p_sister uuid)
returns void language sql security definer as $$
  insert into kyc_steps (sister_id, step)
  values (p_sister,'attestation'),(p_sister,'identity_form'),
         (p_sister,'document_upload'),(p_sister,'ai_screening'),
         (p_sister,'human_review'),(p_sister,'verified')
  on conflict do nothing;
$$;
