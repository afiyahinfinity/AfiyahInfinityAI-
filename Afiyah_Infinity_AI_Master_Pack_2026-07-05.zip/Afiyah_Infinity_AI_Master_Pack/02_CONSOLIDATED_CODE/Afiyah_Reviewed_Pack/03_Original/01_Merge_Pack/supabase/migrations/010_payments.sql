-- ============================================================
-- 010_payments.sql — Subscription tiers + riba-free payment rails
-- Afiyah does not hold funds; gateways process, we record.
-- PCI scope stays with the gateway; we store refs + last4 only.
-- ============================================================

create table if not exists plan_tiers (
  tier          text primary key,          -- 'growth' | 'legacy' | 'sovereign'
  price_aed     numeric(8,2) not null,
  annual_aed    numeric(8,2),
  features      jsonb not null default '[]',
  is_active     boolean not null default true
);
insert into plan_tiers (tier, price_aed, annual_aed, features) values
  ('growth',    49,  490,  '["Academy full access","Zakat & gold calculators","Noor chat mode"]'),
  ('legacy',    149, 1490, '["Everything in Growth","Noor agentic mode","Goal automation","DIFC wills guidance"]'),
  ('sovereign', 399, 3990, '["Everything in Legacy","Scholar Q&A credits","Family accounts","Priority reviews"]')
on conflict do nothing;

create table if not exists subscriptions (
  id            uuid primary key default gen_random_uuid(),
  sister_id     uuid not null references sisters(id) on delete cascade,
  tier          text not null references plan_tiers(tier),
  billing_cycle text not null default 'monthly' check (billing_cycle in ('monthly','annual')),
  status        text not null default 'trial'
                check (status in ('trial','active','past_due','cancelled')),
  started_at    timestamptz default now(),
  renews_at     timestamptz,
  cancelled_at  timestamptz
);
alter table subscriptions enable row level security;
create policy "sister reads own subscription" on subscriptions
  for select using (sister_id = auth.uid());
-- state changes via service role (payment webhook) only

create table if not exists payments (
  id              uuid primary key default gen_random_uuid(),
  sister_id       uuid not null references sisters(id),
  subscription_id uuid references subscriptions(id),
  gateway         text not null check (gateway in
                  ('telr','network_intl','tabby_shariah','apple_pay','bank_transfer')),
  amount_aed      numeric(10,2) not null check (amount_aed > 0),
  status          text not null default 'initiated'
                  check (status in ('initiated','authorised','captured','failed','refunded')),
  gateway_ref     text,                      -- gateway transaction id
  card_last4      text check (card_last4 ~ '^[0-9]{4}$' or card_last4 is null),
  riba_free_rail  boolean not null default true,
  created_at      timestamptz default now()
);
alter table payments enable row level security;
create policy "sister reads own payments" on payments
  for select using (sister_id = auth.uid());

-- Shariah gate at the DATABASE level: a payment recorded on a
-- non-riba-free rail is rejected outright — code cannot bypass it.
create or replace function enforce_riba_free()
returns trigger language plpgsql as $$
begin
  if new.riba_free_rail is distinct from true then
    raise exception 'Payment rail must be riba-free (Shariah gate)';
  end if;
  return new;
end $$;
drop trigger if exists trg_riba_free on payments;
create trigger trg_riba_free before insert on payments
  for each row execute function enforce_riba_free();

-- Webhook idempotency (gateways retry)
create unique index if not exists uq_payments_gateway_ref
  on payments (gateway, gateway_ref) where gateway_ref is not null;

-- Payment events append-only for reconciliation/audit
create table if not exists payment_events (
  id          bigserial primary key,
  payment_id  uuid references payments(id),
  event       text not null,
  raw         jsonb,
  at          timestamptz default now()
);
revoke update, delete on payment_events from public;
