// Gap 5 — nightly JSONL export to private "backups" bucket, 35-day
// retention, failure alert. Cron: "0 23 * * *". See Master Doc D4.1.
import { createClient } from "jsr:@supabase/supabase-js@2";

const CRITICAL_TABLES = [
  "sisters","sister_verifications","sister_goals","barakah_scores",
  "daily_checkins","amanah_points","user_preferences","cycle_logs",
  "partners","partner_verifications","admin_review_queue","admin_users",
  "admin_action_log","ai_response_audit_log",
  // merge-pack additions:
  "kyc_steps","agent_sessions","agent_actions","subscriptions","payments",
];
const RETENTION_DAYS = 35, PAGE = 1000;

Deno.serve(async (req) => {
  if (req.headers.get("authorization") !== `Bearer ${Deno.env.get("CRON_SECRET")}`)
    return new Response("forbidden", { status: 403 });
  const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const stamp = new Date().toISOString().slice(0, 10);
  const results: Record<string, number> = {}; const errors: string[] = [];

  for (const table of CRITICAL_TABLES) {
    try {
      let from = 0; const lines: string[] = [];
      while (true) {
        const { data, error } = await supabase.from(table).select("*").range(from, from + PAGE - 1);
        if (error) throw error;
        if (!data?.length) break;
        for (const row of data) lines.push(JSON.stringify(row));
        if (data.length < PAGE) break;
        from += PAGE;
      }
      const { error: upErr } = await supabase.storage.from("backups")
        .upload(`${stamp}/${table}.jsonl`, new Blob([lines.join("\n")], { type: "application/x-ndjson" }), { upsert: true });
      if (upErr) throw upErr;
      results[table] = lines.length;
    } catch (e) { errors.push(`${table}: ${e.message}`); }
  }
  const cutoff = new Date(Date.now() - RETENTION_DAYS * 86400_000).toISOString().slice(0, 10);
  const { data: folders } = await supabase.storage.from("backups").list("", { limit: 100 });
  for (const f of folders ?? []) if (f.name < cutoff) {
    const { data: files } = await supabase.storage.from("backups").list(f.name);
    if (files?.length) await supabase.storage.from("backups").remove(files.map((x) => `${f.name}/${x.name}`));
  }
  await supabase.from("admin_action_log").insert({
    admin_id: Deno.env.get("SYSTEM_ADMIN_ID"),
    action: errors.length ? "backup_partial_failure" : "backup_success",
    entity_type: "system", detail: { date: stamp, tables: results, errors },
  });
  if (errors.length) {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${Deno.env.get("RESEND_API_KEY")}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: "Afiyah System <system@afiyahinfinityai.com>",
        to: [Deno.env.get("FOUNDER_EMAIL")],
        subject: `Afiyah nightly backup: ${errors.length} table(s) failed`,
        text: errors.join("\n"),
      }),
    });
  }
  return Response.json({ ok: errors.length === 0, results, errors });
});
