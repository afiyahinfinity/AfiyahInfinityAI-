// ============================================================
// supabase/functions/agent-execute/index.ts
// Executes ONE agent action that the sister has APPROVED.
// The AI never touches this path — deterministic server code only.
// Every execution is validated, bounded, and audited.
// ============================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

Deno.serve(async (req) => {
  const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, content-type" };
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  const authHeader = req.headers.get("Authorization");
  if (!authHeader) return json({ error: "unauthorized" }, 401, cors);
  const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: authHeader } } });
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return json({ error: "unauthorized" }, 401, cors);

  const svc = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { action_id } = await req.json();

  // Load the action; it must be HERS and already APPROVED by her.
  const { data: action } = await svc.from("agent_actions")
    .select("*").eq("id", action_id).eq("sister_id", user.id).single();
  if (!action) return json({ error: "not_found" }, 404, cors);
  if (action.status !== "approved") return json({ error: "not_approved", status: action.status }, 409, cors);
  if (action.shariah_gate !== "passed") return json({ error: "shariah_blocked" }, 403, cors);

  // Re-check the registry at execution time (board can disable types live)
  const { data: reg } = await svc.from("agent_action_registry")
    .select("enabled").eq("action_type", action.action_type).single();
  if (!reg?.enabled) {
    await svc.from("agent_actions").update({ status: "blocked", result_summary: "type disabled by board" }).eq("id", action.id);
    return json({ error: "type_disabled" }, 403, cors);
  }

  const p = action.payload ?? {};
  let summary = "";

  switch (action.action_type) {
    case "create_goal": {
      const dim = String(p.dimension ?? "wellness");
      if (!["spiritual","wellness","learning","wealth","giving","sisterhood"].includes(dim))
        return fail(svc, action.id, "invalid dimension", cors);
      const { error } = await svc.from("sister_goals").insert({
        sister_id: user.id, dimension: dim,
        goal_text: String(p.goal_text ?? "").slice(0, 300),
        target_value: Number(p.target_value ?? 0) || null,
        current_value: 0,
      });
      if (error) return fail(svc, action.id, error.message, cors);
      summary = `Goal created: ${String(p.goal_text ?? "").slice(0, 80)}`;
      break;
    }
    case "update_goal_progress": {
      const { data: goal } = await svc.from("sister_goals")
        .select("id").eq("id", p.goal_id).eq("sister_id", user.id).single(); // ownership check
      if (!goal) return fail(svc, action.id, "goal not found or not yours", cors);
      const { error } = await svc.from("sister_goals")
        .update({ current_value: Number(p.current_value ?? 0) }).eq("id", goal.id);
      if (error) return fail(svc, action.id, error.message, cors);
      summary = `Progress updated to ${p.current_value}`;
      break;
    }
    case "calc_zakat": {
      // Deterministic math; nisab rate from admin-set reference, never the model.
      const { data: rate } = await svc.from("reference_rates").select("value").eq("key", "gold_aed_per_gram").single();
      const goldAed = Number(rate?.value ?? 285);
      const nisab = 85 * goldAed;
      const wealth = (Number(p.savings_aed) || 0) + (Number(p.gold_grams) || 0) * goldAed;
      summary = wealth >= nisab
        ? `Zakatable wealth AED ${wealth.toFixed(0)} ≥ nisab AED ${nisab.toFixed(0)} → Zakat due AED ${(wealth * 0.025).toFixed(0)} (educational estimate, not a fatwa)`
        : `Wealth AED ${wealth.toFixed(0)} below nisab AED ${nisab.toFixed(0)} → no Zakat due (educational estimate)`;
      break;
    }
    case "recommend_module": {
      summary = `Module opened: ${String(p.module_slug ?? "").slice(0, 60)}`;
      break; // navigation happens client-side; recorded for continuity
    }
    case "set_reminder_time": {
      const t = String(p.local_time ?? "");
      if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(t)) return fail(svc, action.id, "invalid time", cors);
      const { error } = await svc.from("user_preferences")
        .update({ reminder_local_time: t }).eq("sister_id", user.id);
      if (error) return fail(svc, action.id, error.message, cors);
      summary = `Daily reminder set to ${t} (her local time)`;
      break;
    }
    case "escalate_scholar": {
      const { error } = await svc.from("admin_review_queue").insert({
        entity_type: "sister", entity_id: user.id, priority: "normal",
        status: "pending",
        notes: `Scholar question via Noor: ${String(p.question ?? "").slice(0, 500)}`,
      });
      if (error) return fail(svc, action.id, error.message, cors);
      summary = "Question routed to the scholar desk — response within 48h, insha'Allah.";
      break;
    }
    default:
      return fail(svc, action.id, "unknown action", cors);
  }

  await svc.from("agent_actions").update({
    status: "executed", executed_at: new Date().toISOString(), result_summary: summary,
  }).eq("id", action.id);

  await svc.from("admin_action_log").insert({
    admin_id: Deno.env.get("SYSTEM_ADMIN_ID"),
    action: "agent_action_executed", entity_type: "sister", entity_id: user.id,
    detail: { action_id: action.id, type: action.action_type, summary },
  });

  return json({ ok: true, summary }, 200, cors);
});

async function fail(svc: any, id: string, msg: string, cors: Record<string, string>) {
  await svc.from("agent_actions").update({ status: "blocked", result_summary: msg }).eq("id", id);
  return json({ error: msg }, 400, cors);
}
function json(payload: unknown, status: number, cors: Record<string, string>) {
  return new Response(JSON.stringify(payload), { status, headers: { ...cors, "Content-Type": "application/json" } });
}
