// Gap 8 Layer 1 — THE security test. Staging only.
// Proves User A can never read/write User B's rows on any RLS table,
// including the merge-pack tables (kyc_steps, agent_*, subscriptions, payments).
import { describe, it, expect, beforeAll } from "vitest";
import { createClient, SupabaseClient } from "@supabase/supabase-js";

const URL = process.env.STAGING_SUPABASE_URL!;
const ANON = process.env.STAGING_SUPABASE_ANON_KEY!;
const SERVICE = process.env.STAGING_SERVICE_ROLE_KEY!;
if (!URL || URL.includes("prod")) throw new Error("RLS tests must NEVER run against production.");
const admin = createClient(URL, SERVICE);

const RLS_TABLES_OWNED = [
  ["sisters", "id"], ["sister_verifications", "sister_id"],
  ["sister_goals", "sister_id"], ["barakah_scores", "sister_id"],
  ["daily_checkins", "sister_id"], ["amanah_points", "sister_id"],
  ["user_preferences", "sister_id"], ["cycle_logs", "sister_id"],
  ["kyc_steps", "sister_id"], ["agent_sessions", "sister_id"],
  ["agent_messages", "sister_id"], ["agent_actions", "sister_id"],
  ["subscriptions", "sister_id"], ["payments", "sister_id"],
] as const;
const ADMIN_ONLY = ["admin_review_queue","ai_response_audit_log","admin_action_log","partner_verifications","risk_register"] as const;

let userA: SupabaseClient, userB: SupabaseClient; let idA: string, idB: string;

beforeAll(async () => {
  const mk = async (tag: string) => {
    const email = `rls-test-${tag}-${Date.now()}@test.afiyah.local`;
    const { data, error } = await admin.auth.admin.createUser({ email, password: "Test-Password-123!", email_confirm: true });
    if (error) throw error; return data.user!;
  };
  const a = await mk("a"), b = await mk("b"); idA = a.id; idB = b.id;
  await admin.from("sisters").insert([{ id: idA, email: "a@x", status: "verified" }, { id: idB, email: "b@x", status: "verified" }]);
  await admin.from("sister_goals").insert({ sister_id: idB, dimension: "wellness", goal_text: "x" });
  await admin.from("daily_checkins").insert({ sister_id: idB, date: "2026-06-01", answers: {} });
  await admin.from("cycle_logs").insert({ sister_id: idB, start_date: "2026-06-01" });
  await admin.from("user_preferences").insert([{ sister_id: idA }, { sister_id: idB }]);
  await admin.from("amanah_points").insert({ sister_id: idB, points: 10, action_type: "test" });
  await admin.from("barakah_scores").insert({ sister_id: idB, composite_score: 50 });
  await admin.from("sister_verifications").insert({ sister_id: idB, decision: "approved" });
  await admin.rpc("seed_kyc_steps", { p_sister: idB });
  const { data: sess } = await admin.from("agent_sessions").insert({ sister_id: idB }).select().single();
  await admin.from("agent_messages").insert({ session_id: sess!.id, sister_id: idB, role: "sister", content: "x" });
  await admin.from("agent_actions").insert({ session_id: sess!.id, sister_id: idB, action_type: "create_goal", payload: {} });
  const { data: sub } = await admin.from("subscriptions").insert({ sister_id: idB, tier: "growth" }).select().single();
  await admin.from("payments").insert({ sister_id: idB, subscription_id: sub!.id, gateway: "telr", amount_aed: 49, riba_free_rail: true });

  const signIn = async (email: string) => {
    const c = createClient(URL, ANON);
    const { error } = await c.auth.signInWithPassword({ email, password: "Test-Password-123!" });
    if (error) throw error; return c;
  };
  userA = await signIn(a.email!); userB = await signIn(b.email!);
});

describe("Cross-user isolation", () => {
  for (const [table, ownerCol] of RLS_TABLES_OWNED) {
    it(`${table}: A cannot SELECT B's rows`, async () => {
      const { data } = await userA.from(table).select("*").eq(ownerCol, idB);
      expect(data ?? []).toHaveLength(0);
    });
    it(`${table}: A cannot UPDATE B's rows`, async () => {
      const { data } = await userA.from(table).update({ updated_at: new Date().toISOString() }).eq(ownerCol, idB).select();
      expect(data ?? []).toHaveLength(0);
    });
  }
});
describe("Agentic guardrail: sister cannot self-execute actions", () => {
  it("B cannot set her own action to 'executed' (service-role only)", async () => {
    const { data } = await userB.from("agent_actions").update({ status: "executed" }).eq("sister_id", idB).select();
    expect(data ?? []).toHaveLength(0); // with-check forbids executed
  });
});
describe("Payments Shariah gate", () => {
  it("non-riba-free payment is rejected at DB level", async () => {
    const { error } = await admin.from("payments").insert({ sister_id: idB, gateway: "telr", amount_aed: 10, riba_free_rail: false });
    expect(error).not.toBeNull();
  });
});
describe("Admin-only tables invisible", () => {
  for (const table of ADMIN_ONLY) {
    it(`${table}: normal user sees nothing`, async () => {
      const { data } = await userA.from(table).select("*").limit(1);
      expect((data ?? []).length).toBe(0);
    });
  }
});
