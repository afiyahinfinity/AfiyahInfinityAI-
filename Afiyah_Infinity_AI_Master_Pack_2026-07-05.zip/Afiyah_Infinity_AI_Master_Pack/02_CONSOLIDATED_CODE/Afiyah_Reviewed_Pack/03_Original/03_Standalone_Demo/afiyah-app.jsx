import React, { useState, useRef, useEffect } from "react";

/* ============================================================
   AFIYAH INFINITY AI — MVP (Dual Portal)
   Sisters Portal (women-only) · Partners Portal (B2B)
   DIFC Innovation Licence · UAE · Shariah-Compliant
   AI Buddy "Noor" — built from scratch, 50% agentic:
   Claude returns JSON actions -> app executes with user approval.
   ============================================================ */

const C = {
  forest: "#1E4D4D", navy: "#2C5F5F", gold: "#C9A96E",
  rose: "#D4919F", ivory: "#F3ECDD", green: "#27AE60", ink: "#12302F",
};

const Fonts = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,600;1,400&family=Jost:wght@300;400;500;600&display=swap');
    .display { font-family: 'Cormorant Garamond', serif; }
    body, .body { font-family: 'Jost', sans-serif; }
    .goldframe { border: 1px solid ${C.gold}; box-shadow: inset 0 0 0 4px ${C.forest}, inset 0 0 0 5px ${C.gold}55; }
    .diamond { width:8px;height:8px;transform:rotate(45deg);background:${C.gold};display:inline-block; }
    ::-webkit-scrollbar{width:6px} ::-webkit-scrollbar-thumb{background:${C.gold}66;border-radius:3px}
  `}</style>
);

/* ---------- CONTENT: Beginner's Islamic Finance, UAE edition ---------- */
const MODULES = [
  { slug: "riba", title: "Riba & Why It Matters", mins: 8, blurb: "What interest-free really means, and how UAE banks structure halal alternatives (Murabaha, Ijarah).", pts: ["Riba = any guaranteed return on a loan — prohibited (Qur'an 2:275)", "UAE alternative: Murabaha (cost-plus sale) for cars & homes", "Check: is the bank licensed under CBUAE Higher Shariah Authority?"] },
  { slug: "zakat", title: "Zakat for Working Women", mins: 10, blurb: "Nisab, gold jewellery rulings, and paying Zakat on your UAE salary savings.", pts: ["Nisab ≈ 85g gold — check today's Dubai gold rate", "2.5% on savings held one lunar year", "Gold jewellery in daily use: scholarly difference — Noor can walk you through both views"] },
  { slug: "takaful", title: "Takaful vs Insurance", mins: 7, blurb: "Cooperative protection without gharar. What DHA-compliant Takaful looks like in Dubai.", pts: ["Takaful pool = mutual donation (tabarru'), not a bet", "Surplus is shared back with participants", "UAE providers must hold a CBUAE Takaful licence"] },
  { slug: "sukuk", title: "Sukuk & Halal Investing", mins: 12, blurb: "Asset-backed certificates, AAOIFI screening, and gold as a Sunnah store of value.", pts: ["Sukuk = ownership share in a real asset, not a debt IOU", "AAOIFI screen: debt <33%, non-halal income <5%", "Physical gold: take possession (qabd) same-session to avoid riba al-nasi'ah"] },
  { slug: "wasiyya", title: "Wills & Inheritance in the UAE", mins: 9, blurb: "DIFC Wills Service, faraid shares, and protecting your children as a Muslim woman.", pts: ["Non-Muslims can register DIFC wills; Muslims follow faraid", "A woman's wealth is hers alone — mahr, salary, gold", "You may bequeath up to 1/3 outside fixed heirs"] },
];

const TIERS = [
  { name: "Growth", aed: 49, per: "/mo", feats: ["Full learning academy", "Zakat & gold calculators", "Noor AI buddy (chat)"] },
  { name: "Legacy", aed: 149, per: "/mo", feats: ["Everything in Growth", "Noor agentic mode (goals, screening)", "Halal portfolio tracking", "DIFC wills guidance"], hot: true },
  { name: "Sovereign", aed: 399, per: "/mo", feats: ["Everything in Legacy", "1:1 scholar Q&A credits", "Family accounts", "Priority Shariah reviews"] },
];

const RISKS = [
  { cat: "Shariah non-compliance", l: 2, i: 5, own: "ADL Advisory Board", mit: "Quarterly product audit; blocked-terms filter on Noor" },
  { cat: "AML / CFT", l: 2, i: 5, own: "MLRO", mit: "UAE PASS KYC, PEP & sanctions screening at onboarding" },
  { cat: "AI model risk", l: 3, i: 4, own: "CTO", mit: "Action approval gates; audit log; RAG limited to board-approved corpus" },
  { cat: "Data privacy (DIFC DP Law 5/2020)", l: 2, i: 4, own: "DPO", mit: "RLS isolation, k-anonymity ≥25 for partner insights" },
  { cat: "Cyber", l: 3, i: 4, own: "CTO", mit: "SOC2 roadmap, encryption at rest, immutable audit log" },
];

/* ---------- AI AGENT (from scratch) ---------- */
const NOOR_SYSTEM = `You are Noor, the AI buddy inside Afiyah Infinity — a Shariah-compliant wealth & learning platform for Muslim women in the UAE (DIFC Innovation Licence). Be warm, precise, sisterly. Ground answers in mainstream Islamic finance (AAOIFI, CBUAE HSA context). Never give haram advice (riba, gharar, maysir). For fiqh differences, present views neutrally and suggest the Shariah board for rulings.

You are 50% AGENTIC. You may propose actions the app will execute AFTER user approval. Respond ONLY with raw JSON (no markdown fences):
{
  "reply": "your conversational message",
  "actions": [ // optional, max 2
    {"type":"create_goal","title":"...","target_aed":number,"goal_type":"emergency_fund|hajj|gold|sukuk|education|zakat_plan"} |
    {"type":"calc_zakat","savings_aed":number,"gold_grams":number} |
    {"type":"recommend_module","slug":"riba|zakat|takaful|sukuk|wasiyya","reason":"..."} |
    {"type":"escalate_human","reason":"..."}
  ]
}`;

async function askNoor(history) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 1000,
      system: NOOR_SYSTEM,
      messages: history.map((m) => ({ role: m.role, content: m.content })),
    }),
  });
  const data = await res.json();
  const text = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("\n");
  try { return JSON.parse(text.replace(/```json|```/g, "").trim()); }
  catch { return { reply: text || "I couldn't reach the knowledge base — try again, habibti.", actions: [] }; }
}

const NISAB_GOLD_G = 85, GOLD_AED_PER_G = 285; // update via feed in prod
const runAction = (a, ctx) => {
  switch (a.type) {
    case "create_goal":
      ctx.setGoals(g => [...g, { id: Date.now(), title: a.title, target: a.target_aed, saved: 0, byAI: true }]);
      return `Goal "${a.title}" created (AED ${a.target_aed?.toLocaleString()}).`;
    case "calc_zakat": {
      const wealth = (a.savings_aed || 0) + (a.gold_grams || 0) * GOLD_AED_PER_G;
      const nisab = NISAB_GOLD_G * GOLD_AED_PER_G;
      return wealth >= nisab
        ? `Zakatable wealth AED ${wealth.toLocaleString()} ≥ nisab (AED ${nisab.toLocaleString()}). Zakat due: AED ${(wealth * 0.025).toFixed(0)}.`
        : `Wealth AED ${wealth.toLocaleString()} is below nisab (AED ${nisab.toLocaleString()}) — no Zakat due.`;
    }
    case "recommend_module":
      ctx.setActiveModule(a.slug);
      return `Opened module: ${MODULES.find(m => m.slug === a.slug)?.title || a.slug}.`;
    case "escalate_human":
      return `Routed to the ADL Shariah desk — a scholar will respond within 48h.`;
    default: return "Unknown action blocked by Shariah gate.";
  }
};

/* ---------- SHARED UI ---------- */
const Diamond = () => <span className="diamond mx-2" />;
const Eyebrow = ({ children }) => (
  <div className="flex items-center text-xs tracking-[0.3em] uppercase" style={{ color: C.gold }}>
    <Diamond />{children}<Diamond />
  </div>
);
const Card = ({ children, className = "", style = {} }) => (
  <div className={`rounded-sm p-5 goldframe ${className}`} style={{ background: C.forest, ...style }}>{children}</div>
);
const Btn = ({ children, onClick, ghost, small }) => (
  <button onClick={onClick}
    className={`rounded-sm tracking-wide ${small ? "px-3 py-1 text-xs" : "px-5 py-2 text-sm"}`}
    style={ghost ? { border: `1px solid ${C.gold}`, color: C.gold } : { background: C.gold, color: C.ink, fontWeight: 600 }}>
    {children}
  </button>
);

/* ---------- SISTERS: KYC ---------- */
function KYC({ onDone }) {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({ name: "", eid: "", emirate: "Dubai" });
  const steps = ["Identity", "Screening", "Verified"];
  return (
    <Card className="max-w-md mx-auto">
      <Eyebrow>KYC · UAE PASS Ready</Eyebrow>
      <h3 className="display text-2xl mt-2" style={{ color: C.ivory }}>Verify your identity</h3>
      <div className="flex gap-2 my-4">{steps.map((s, i) => (
        <div key={s} className="flex-1 text-center text-xs pb-2" style={{ borderBottom: `2px solid ${i <= step ? C.gold : "#ffffff22"}`, color: i <= step ? C.gold : "#ffffff66" }}>{s}</div>
      ))}</div>
      {step === 0 && <div className="space-y-3">
        {[["Full name (as on Emirates ID)", "name"], ["Emirates ID (784-XXXX-XXXXXXX-X)", "eid"]].map(([ph, k]) => (
          <input key={k} placeholder={ph} value={form[k]} onChange={e => setForm({ ...form, [k]: e.target.value })}
            className="w-full p-3 rounded-sm text-sm" style={{ background: "#ffffff10", border: `1px solid ${C.gold}44`, color: C.ivory }} />
        ))}
        <select value={form.emirate} onChange={e => setForm({ ...form, emirate: e.target.value })}
          className="w-full p-3 rounded-sm text-sm" style={{ background: C.navy, border: `1px solid ${C.gold}44`, color: C.ivory }}>
          {["Dubai", "Abu Dhabi", "Sharjah", "Ajman", "Ras Al Khaimah", "Fujairah", "Umm Al Quwain"].map(e => <option key={e}>{e}</option>)}
        </select>
        <Btn onClick={() => form.name && setStep(1)}>Continue</Btn>
      </div>}
      {step === 1 && <div className="space-y-3 text-sm" style={{ color: C.ivory }}>
        {["Sanctions & PEP screening (DIFC AML Rulebook)", "Women-only eligibility check", "Document liveness match"].map(t => (
          <div key={t} className="flex items-center gap-2"><span style={{ color: C.green }}>✓</span>{t}</div>
        ))}
        <p className="text-xs opacity-70">Data processed under DIFC Data Protection Law No. 5 of 2020. Never shared with partners.</p>
        <Btn onClick={() => setStep(2)}>Run screening</Btn>
      </div>}
      {step === 2 && <div className="text-center py-4">
        <div className="display text-3xl" style={{ color: C.gold }}>Verified ✓</div>
        <p className="text-sm my-3" style={{ color: C.ivory }}>Welcome to the sisterhood, {form.name.split(" ")[0] || "sister"}.</p>
        <Btn onClick={onDone}>Enter Sisters Portal</Btn>
      </div>}
    </Card>
  );
}

/* ---------- SISTERS: NOOR CHAT ---------- */
function NoorChat({ ctx }) {
  const [msgs, setMsgs] = useState([{ role: "assistant", content: "As-salamu alaykum, sister 🌙 I'm Noor. Ask me anything about halal money in the UAE — or let me set up a savings goal or Zakat calculation for you." }]);
  const [pending, setPending] = useState([]); // actions awaiting approval
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const endRef = useRef(null);
  useEffect(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), [msgs, pending]);

  const send = async () => {
    if (!input.trim() || busy) return;
    const hist = [...msgs, { role: "user", content: input }];
    setMsgs(hist); setInput(""); setBusy(true);
    try {
      const out = await askNoor(hist.slice(-12));
      setMsgs(m => [...m, { role: "assistant", content: out.reply }]);
      if (out.actions?.length) setPending(p => [...p, ...out.actions.slice(0, 2)]);
    } catch { setMsgs(m => [...m, { role: "assistant", content: "Connection issue — please try again." }]); }
    setBusy(false);
  };
  const approve = (a, ok) => {
    setPending(p => p.filter(x => x !== a));
    if (ok) setMsgs(m => [...m, { role: "assistant", content: "✦ " + runAction(a, ctx) }]);
  };

  return (
    <Card className="flex flex-col h-[520px]">
      <div className="flex items-center justify-between mb-3">
        <div><Eyebrow>Noor · AI Buddy</Eyebrow>
          <div className="text-xs mt-1" style={{ color: "#ffffff88" }}>50% agentic — every action needs your approval · logged to audit trail</div></div>
        <span className="text-xs px-2 py-1 rounded-sm" style={{ border: `1px solid ${C.green}`, color: C.green }}>Shariah gate on</span>
      </div>
      <div className="flex-1 overflow-y-auto space-y-3 pr-1">
        {msgs.map((m, i) => (
          <div key={i} className={`max-w-[85%] p-3 rounded-sm text-sm leading-relaxed ${m.role === "user" ? "ml-auto" : ""}`}
            style={m.role === "user" ? { background: C.gold, color: C.ink } : { background: "#ffffff10", color: C.ivory, borderLeft: `2px solid ${C.gold}` }}>
            {m.content}
          </div>
        ))}
        {pending.map((a, i) => (
          <div key={"a" + i} className="p-3 rounded-sm text-sm" style={{ border: `1px dashed ${C.rose}`, color: C.ivory }}>
            <div className="text-xs uppercase tracking-widest mb-1" style={{ color: C.rose }}>Noor proposes an action</div>
            <div>{a.type.replace(/_/g, " ")} — {a.title || a.reason || (a.slug && MODULES.find(m => m.slug === a.slug)?.title) || `AED ${a.savings_aed || ""}${a.gold_grams ? ` + ${a.gold_grams}g gold` : ""}`}</div>
            <div className="flex gap-2 mt-2">
              <Btn small onClick={() => approve(a, true)}>Approve</Btn>
              <Btn small ghost onClick={() => approve(a, false)}>Decline</Btn>
            </div>
          </div>
        ))}
        {busy && <div className="text-xs animate-pulse" style={{ color: C.gold }}>Noor is thinking…</div>}
        <div ref={endRef} />
      </div>
      <div className="flex gap-2 mt-3">
        <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && send()}
          placeholder='Try: "Set me a Hajj savings goal of 25,000 AED" or "Zakat on 60k savings + 40g gold?"'
          className="flex-1 p-3 rounded-sm text-sm" style={{ background: "#ffffff10", border: `1px solid ${C.gold}44`, color: C.ivory }} />
        <Btn onClick={send}>{busy ? "…" : "Send"}</Btn>
      </div>
    </Card>
  );
}

/* ---------- SISTERS PORTAL ---------- */
function SistersPortal() {
  const [kycDone, setKycDone] = useState(false);
  const [goals, setGoals] = useState([{ id: 1, title: "Emergency fund", target: 30000, saved: 8200, byAI: false }]);
  const [activeModule, setActiveModule] = useState(null);
  const [tier, setTier] = useState(null);
  const [payStep, setPayStep] = useState(null);
  const ctx = { setGoals, setActiveModule };
  if (!kycDone) return <div className="py-10"><KYC onDone={() => setKycDone(true)} /></div>;
  const mod = MODULES.find(m => m.slug === activeModule);

  return (
    <div className="grid lg:grid-cols-3 gap-5 py-6">
      <div className="lg:col-span-2 space-y-5">
        <NoorChat ctx={ctx} />
        <Card>
          <Eyebrow>Academy · Islamic Finance, UAE Edition</Eyebrow>
          <div className="grid sm:grid-cols-2 gap-3 mt-3">
            {MODULES.map(m => (
              <button key={m.slug} onClick={() => setActiveModule(m.slug)} className="text-left p-3 rounded-sm"
                style={{ background: activeModule === m.slug ? C.gold : "#ffffff0d", color: activeModule === m.slug ? C.ink : C.ivory, border: `1px solid ${C.gold}33` }}>
                <div className="display text-lg">{m.title}</div>
                <div className="text-xs opacity-80">{m.mins} min · {m.blurb}</div>
              </button>
            ))}
          </div>
          {mod && <div className="mt-4 p-4 rounded-sm" style={{ background: "#ffffff0d", borderLeft: `3px solid ${C.gold}` }}>
            <div className="display text-xl mb-2" style={{ color: C.gold }}>{mod.title}</div>
            <ul className="space-y-2 text-sm" style={{ color: C.ivory }}>
              {mod.pts.map(p => <li key={p} className="flex gap-2"><span style={{ color: C.gold }}>◆</span>{p}</li>)}
            </ul>
          </div>}
        </Card>
      </div>
      <div className="space-y-5">
        <Card>
          <Eyebrow>My Goals</Eyebrow>
          {goals.map(g => (
            <div key={g.id} className="mt-3">
              <div className="flex justify-between text-sm" style={{ color: C.ivory }}>
                <span>{g.title} {g.byAI && <span className="text-xs" style={{ color: C.rose }}>✦ by Noor</span>}</span>
                <span style={{ color: C.gold }}>{Math.round(g.saved / g.target * 100)}%</span>
              </div>
              <div className="h-1.5 rounded-full mt-1" style={{ background: "#ffffff15" }}>
                <div className="h-1.5 rounded-full" style={{ width: `${Math.min(100, g.saved / g.target * 100)}%`, background: C.gold }} />
              </div>
              <div className="text-xs mt-1" style={{ color: "#ffffff77" }}>AED {g.saved.toLocaleString()} / {g.target.toLocaleString()}</div>
            </div>
          ))}
        </Card>
        <Card>
          <Eyebrow>Membership</Eyebrow>
          <div className="space-y-3 mt-3">
            {TIERS.map(t => (
              <div key={t.name} className="p-3 rounded-sm" style={{ border: `1px solid ${t.hot ? C.gold : C.gold + "33"}`, background: t.hot ? "#ffffff0d" : "transparent" }}>
                <div className="flex justify-between items-baseline">
                  <span className="display text-xl" style={{ color: C.ivory }}>{t.name}</span>
                  <span style={{ color: C.gold }}>AED {t.aed}<span className="text-xs">{t.per}</span></span>
                </div>
                <ul className="text-xs mt-1 space-y-0.5" style={{ color: "#ffffffaa" }}>{t.feats.map(f => <li key={f}>◆ {f}</li>)}</ul>
                <div className="mt-2"><Btn small ghost={!t.hot} onClick={() => { setTier(t); setPayStep("method"); }}>Choose {t.name}</Btn></div>
              </div>
            ))}
          </div>
        </Card>
        {payStep && tier && <Card>
          <Eyebrow>Checkout · {tier.name}</Eyebrow>
          {payStep === "method" ? <div className="mt-3 space-y-2">
            {["Card (Telr / Network Intl)", "Apple Pay", "Tabby — Shariah-compliant split", "Bank transfer (AED)"].map(m => (
              <button key={m} onClick={() => setPayStep("done")} className="w-full text-left p-3 rounded-sm text-sm"
                style={{ background: "#ffffff0d", color: C.ivory, border: `1px solid ${C.gold}33` }}>{m}</button>
            ))}
            <p className="text-xs" style={{ color: "#ffffff77" }}>All rails riba-free · PCI-DSS via gateway · no card data stored.</p>
          </div> : <div className="text-center py-4">
            <div className="display text-2xl" style={{ color: C.green }}>Payment captured ✓</div>
            <p className="text-sm mt-2" style={{ color: C.ivory }}>{tier.name} active — barakallahu feek.</p>
          </div>}
        </Card>}
      </div>
    </div>
  );
}

/* ---------- PARTNERS PORTAL ---------- */
function PartnersPortal() {
  const [tab, setTab] = useState("shariah");
  return (
    <div className="py-6 space-y-5">
      <div className="flex gap-2 flex-wrap">
        {[["shariah", "Shariah Compliance"], ["risk", "Risk Register"], ["gov", "Governance"], ["insights", "Audience Insights"]].map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className="px-4 py-2 text-sm rounded-sm"
            style={tab === k ? { background: C.gold, color: C.ink, fontWeight: 600 } : { border: `1px solid ${C.gold}55`, color: C.gold }}>{l}</button>
        ))}
      </div>
      {tab === "shariah" && <Card>
        <Eyebrow>ADL Advisory · Shariah Board</Eyebrow>
        <table className="w-full text-sm mt-3" style={{ color: C.ivory }}>
          <thead><tr className="text-xs uppercase tracking-widest text-left" style={{ color: C.gold }}>
            <th className="py-2">Subject</th><th>Ruling</th><th>Standard</th><th>Effective</th></tr></thead>
          <tbody>
            {[["Noor AI buddy — chat mode", "Halal", "Internal AI Ethics + AAOIFI GS", "01 Jun 2026"],
              ["Noor agentic actions (approval-gated)", "Conditional", "Board Resolution 07/26", "15 Jun 2026"],
              ["Gold savings goal feature", "Halal", "AAOIFI SS 57 (Gold)", "01 Jun 2026"],
              ["BNPL integration (conventional)", "Haram", "Riba al-nasi'ah", "—"],
              ["Tabby Shariah-split checkout", "Conditional", "Under board review", "Pending"]].map(r => (
              <tr key={r[0]} style={{ borderTop: "1px solid #ffffff15" }}>
                <td className="py-2 pr-2">{r[0]}</td>
                <td><span className="px-2 py-0.5 rounded-sm text-xs" style={{
                  background: r[1] === "Halal" ? C.green + "33" : r[1] === "Haram" ? "#c0392b33" : C.gold + "33",
                  color: r[1] === "Halal" ? C.green : r[1] === "Haram" ? "#e57373" : C.gold }}>{r[1]}</span></td>
                <td className="text-xs">{r[2]}</td><td className="text-xs">{r[3]}</td>
              </tr>))}
          </tbody>
        </table>
      </Card>}
      {tab === "risk" && <Card>
        <Eyebrow>Enterprise Risk Register</Eyebrow>
        <div className="space-y-2 mt-3">
          {RISKS.map(r => (
            <div key={r.cat} className="p-3 rounded-sm flex flex-wrap gap-3 items-center justify-between" style={{ background: "#ffffff0d" }}>
              <div>
                <div className="text-sm" style={{ color: C.ivory }}>{r.cat}</div>
                <div className="text-xs" style={{ color: "#ffffff88" }}>{r.mit} · Owner: {r.own}</div>
              </div>
              <div className="display text-2xl" style={{ color: r.l * r.i >= 12 ? C.rose : C.gold }}>{r.l * r.i}</div>
            </div>
          ))}
        </div>
      </Card>}
      {tab === "gov" && <Card>
        <Eyebrow>Governance · DIFC Innovation Licence</Eyebrow>
        <div className="grid sm:grid-cols-2 gap-3 mt-3 text-sm" style={{ color: C.ivory }}>
          {[["Legal structure", "DIFC Innovation Licence (Ltd) — non-regulated fintech; DFSA sandbox pathway mapped for future regulated activity"],
            ["Data protection", "DIFC DP Law No. 5 of 2020 · DPO appointed · RLS + k-anonymity walls between portals"],
            ["AML / CFT", "KYC via UAE PASS, PEP & sanctions screening, MLRO designated, SAR procedure documented"],
            ["AI governance", "Model risk policy: approval-gated agent actions, immutable audit log, board-approved RAG corpus only"],
            ["Board", "CEO + 2 independents + ADL Shariah Board (standing quarterly audits)"],
            ["Security", "Encryption at rest & transit, least-privilege RLS, SOC 2 Type I roadmap Q1 2027"]].map(([t, d]) => (
            <div key={t} className="p-3 rounded-sm" style={{ background: "#ffffff0d", borderLeft: `3px solid ${C.gold}` }}>
              <div className="display text-lg" style={{ color: C.gold }}>{t}</div>
              <div className="text-xs mt-1" style={{ color: "#ffffffbb" }}>{d}</div>
            </div>))}
        </div>
      </Card>}
      {tab === "insights" && <Card>
        <Eyebrow>Audience Insights · Aggregates Only (k ≥ 25)</Eyebrow>
        <p className="text-xs mt-2 mb-3" style={{ color: "#ffffff88" }}>Partners never see individual sister data — hard privacy wall enforced at database level.</p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[["Dubai", "1,240"], ["Abu Dhabi", "620"], ["Sharjah", "410"], ["Avg Barakah", "68"]].map(([l, v]) => (
            <div key={l} className="p-3 text-center rounded-sm" style={{ background: "#ffffff0d" }}>
              <div className="display text-3xl" style={{ color: C.gold }}>{v}</div>
              <div className="text-xs" style={{ color: C.ivory }}>{l}</div>
            </div>))}
        </div>
      </Card>}
    </div>
  );
}

/* ---------- LANDING + SHELL ---------- */
export default function App() {
  const [portal, setPortal] = useState(null);
  return (
    <div className="min-h-screen body" style={{ background: `linear-gradient(160deg, ${C.ink}, ${C.forest})` }}>
      <Fonts />
      <header className="flex items-center justify-between px-6 py-4" style={{ borderBottom: `1px solid ${C.gold}44` }}>
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => setPortal(null)}>
          <span className="diamond" />
          <span className="display text-2xl" style={{ color: C.ivory }}>Afiyah <span style={{ color: C.gold }}>Infinity</span></span>
        </div>
        <div className="text-xs tracking-widest uppercase hidden sm:block" style={{ color: C.gold }}>DIFC Innovation Licence · Dubai</div>
      </header>
      <main className="max-w-6xl mx-auto px-4">
        {!portal ? (
          <div className="py-16 text-center">
            <Eyebrow>Shariah-Compliant · Women-First · UAE</Eyebrow>
            <h1 className="display text-5xl md:text-6xl mt-4 leading-tight" style={{ color: C.ivory }}>
              Her wealth. Her deen.<br /><em style={{ color: C.gold }}>Her terms.</em>
            </h1>
            <p className="max-w-xl mx-auto mt-4 text-sm" style={{ color: "#ffffffbb" }}>
              The beginner's guide to Islamic finance — rebuilt as a living platform for Muslim women in the UAE,
              with Noor, your approval-gated agentic AI buddy. Seed round: <span style={{ color: C.gold }}>$1,000,000</span>.
            </p>
            <div className="grid sm:grid-cols-2 gap-5 max-w-3xl mx-auto mt-10 text-left">
              <Card>
                <div className="display text-3xl" style={{ color: C.rose }}>Sisters Portal</div>
                <p className="text-sm my-3" style={{ color: C.ivory }}>Women-only. KYC-verified. Learn riba-free wealth, set goals with Noor, pay halal.</p>
                <Btn onClick={() => setPortal("sisters")}>Enter as a Sister</Btn>
              </Card>
              <Card>
                <div className="display text-3xl" style={{ color: C.gold }}>Partners Portal</div>
                <p className="text-sm my-3" style={{ color: C.ivory }}>Islamic banks, takaful & employers. Governance, risk, Shariah dashboards. Aggregate insights only.</p>
                <Btn ghost onClick={() => setPortal("partners")}>Enter as a Partner</Btn>
              </Card>
            </div>
          </div>
        ) : portal === "sisters" ? <SistersPortal /> : <PartnersPortal />}
      </main>
      <footer className="text-center text-xs py-6" style={{ color: "#ffffff66" }}>
        <Diamond /> Afiyah Infinity AI Ltd. · DIFC Innovation Licence · Not investment advice — education only <Diamond />
      </footer>
    </div>
  );
}
