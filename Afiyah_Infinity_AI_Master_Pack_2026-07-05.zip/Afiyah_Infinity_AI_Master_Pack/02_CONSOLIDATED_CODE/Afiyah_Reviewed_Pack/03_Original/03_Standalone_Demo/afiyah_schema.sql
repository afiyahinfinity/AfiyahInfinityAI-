-- ============================================================
-- AFIYAH INFINITY AI — MVP DATABASE SCHEMA (PostgreSQL / Supabase)
-- Dual Portal: Sisters (women-only B2C) + Partners (B2B)
-- DIFC Innovation Licence · UAE · Shariah-Compliant
-- ============================================================

-- Two logical databases via schemas + Row Level Security.
CREATE SCHEMA IF NOT EXISTS sisters;
CREATE SCHEMA IF NOT EXISTS partners;
CREATE SCHEMA IF NOT EXISTS governance;   -- shared: Shariah, risk, audit
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS vector;    -- pgvector for AI knowledge base

-- ------------------------------------------------------------
-- SISTERS PORTAL
-- ------------------------------------------------------------
CREATE TABLE sisters.users (
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  auth_id         uuid UNIQUE NOT NULL,            -- Supabase auth.users
  full_name       text NOT NULL,
  email           text UNIQUE NOT NULL,
  phone_e164      text,
  emirate         text CHECK (emirate IN ('Abu Dhabi','Dubai','Sharjah','Ajman','Umm Al Quwain','Ras Al Khaimah','Fujairah','Other')),
  gender_verified boolean DEFAULT false,           -- women-only gate (KYC-backed)
  preferred_lang  text DEFAULT 'en' CHECK (preferred_lang IN ('en','ar','bn','ur')),
  hijri_dob       text,
  created_at      timestamptz DEFAULT now()
);

CREATE TABLE sisters.kyc_records (
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         uuid NOT NULL REFERENCES sisters.users(id) ON DELETE CASCADE,
  provider        text NOT NULL DEFAULT 'uae_pass',  -- UAE PASS / EmiratesID / manual
  id_type         text CHECK (id_type IN ('emirates_id','passport','uae_pass')),
  id_last4        text,
  status          text NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending','in_review','verified','rejected','expired')),
  risk_rating     text DEFAULT 'low' CHECK (risk_rating IN ('low','medium','high')),
  pep_screened    boolean DEFAULT false,             -- AML/CFT (DIFC AML Rulebook)
  sanctions_hit   boolean DEFAULT false,
  verified_at     timestamptz,
  expires_at      timestamptz,
  created_at      timestamptz DEFAULT now()
);

CREATE TABLE sisters.subscriptions (
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         uuid NOT NULL REFERENCES sisters.users(id) ON DELETE CASCADE,
  tier            text NOT NULL CHECK (tier IN ('growth','legacy','sovereign')),
  price_aed       numeric(8,2) NOT NULL,             -- 49 / 149 / 399
  billing_cycle   text DEFAULT 'monthly' CHECK (billing_cycle IN ('monthly','annual')),
  status          text DEFAULT 'active' CHECK (status IN ('trial','active','past_due','cancelled')),
  started_at      timestamptz DEFAULT now(),
  renews_at       timestamptz
);

CREATE TABLE sisters.payments (
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         uuid NOT NULL REFERENCES sisters.users(id),
  subscription_id uuid REFERENCES sisters.subscriptions(id),
  gateway         text NOT NULL CHECK (gateway IN ('stripe_uae','telr','tabby_shariah','network_intl','apple_pay','bank_transfer')),
  amount_aed      numeric(10,2) NOT NULL,
  currency        text DEFAULT 'AED',
  status          text DEFAULT 'initiated' CHECK (status IN ('initiated','authorised','captured','failed','refunded')),
  gateway_ref     text,
  is_riba_free    boolean DEFAULT true,              -- Shariah gate: no credit-interest rails
  created_at      timestamptz DEFAULT now()
);

CREATE TABLE sisters.wealth_goals (
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         uuid NOT NULL REFERENCES sisters.users(id) ON DELETE CASCADE,
  goal_type       text CHECK (goal_type IN ('emergency_fund','hajj','gold','sukuk','education','business','waqf','zakat_plan')),
  title           text NOT NULL,
  target_aed      numeric(12,2),
  saved_aed       numeric(12,2) DEFAULT 0,
  target_date     date,
  created_by      text DEFAULT 'user' CHECK (created_by IN ('user','ai_agent')),  -- agentic provenance
  created_at      timestamptz DEFAULT now()
);

CREATE TABLE sisters.learning_progress (
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         uuid NOT NULL REFERENCES sisters.users(id) ON DELETE CASCADE,
  module_slug     text NOT NULL,                     -- e.g. 'riba-basics','takaful','sukuk-101'
  pct_complete    int DEFAULT 0 CHECK (pct_complete BETWEEN 0 AND 100),
  quiz_score      int,
  completed_at    timestamptz,
  UNIQUE (user_id, module_slug)
);

CREATE TABLE sisters.barakah_scores (
  user_id         uuid PRIMARY KEY REFERENCES sisters.users(id) ON DELETE CASCADE,
  spiritual       int DEFAULT 0, wellness int DEFAULT 0, learning int DEFAULT 0,
  wealth          int DEFAULT 0, giving   int DEFAULT 0, sisterhood int DEFAULT 0,
  composite       int GENERATED ALWAYS AS (
                    (spiritual*25 + wellness*20 + learning*15 + wealth*15 + giving*15 + sisterhood*10)/100
                  ) STORED,
  updated_at      timestamptz DEFAULT now()
);

-- ------------------------------------------------------------
-- AI AGENTS (built from scratch — no framework)
-- ------------------------------------------------------------
CREATE TABLE sisters.agent_sessions (
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         uuid NOT NULL REFERENCES sisters.users(id) ON DELETE CASCADE,
  agent_name      text NOT NULL DEFAULT 'noor',      -- Noor = AI buddy
  mode            text DEFAULT 'hybrid' CHECK (mode IN ('chat','agentic','hybrid')), -- 50% agentic
  started_at      timestamptz DEFAULT now(),
  ended_at        timestamptz
);

CREATE TABLE sisters.agent_messages (
  id              bigserial PRIMARY KEY,
  session_id      uuid NOT NULL REFERENCES sisters.agent_sessions(id) ON DELETE CASCADE,
  role            text NOT NULL CHECK (role IN ('user','assistant','tool')),
  content         text NOT NULL,
  created_at      timestamptz DEFAULT now()
);

-- Every autonomous action the agent takes is logged, human-approvable, reversible.
CREATE TABLE sisters.agent_actions (
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id      uuid NOT NULL REFERENCES sisters.agent_sessions(id),
  user_id         uuid NOT NULL REFERENCES sisters.users(id),
  action_type     text NOT NULL CHECK (action_type IN
                   ('create_goal','update_goal','calc_zakat','recommend_module',
                    'schedule_reminder','portfolio_screen','flag_compliance','escalate_human')),
  payload         jsonb NOT NULL,
  requires_approval boolean DEFAULT true,            -- guardrail: money-adjacent = approve first
  approved_by_user  boolean,
  executed        boolean DEFAULT false,
  shariah_check   text DEFAULT 'passed' CHECK (shariah_check IN ('passed','blocked','review')),
  created_at      timestamptz DEFAULT now()
);

CREATE TABLE sisters.knowledge_chunks (        -- RAG: Islamic finance corpus
  id              bigserial PRIMARY KEY,
  source          text NOT NULL,               -- 'AAOIFI','fatwa_board','module:riba-basics'
  lang            text DEFAULT 'en',
  content         text NOT NULL,
  embedding       vector(1536),
  shariah_approved boolean DEFAULT false,      -- only board-approved chunks retrievable
  approved_by     text
);
CREATE INDEX ON sisters.knowledge_chunks USING ivfflat (embedding vector_cosine_ops);

-- ------------------------------------------------------------
-- PARTNERS PORTAL (B2B: banks, takaful, employers, DIFC entities)
-- ------------------------------------------------------------
CREATE TABLE partners.organisations (
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  legal_name      text NOT NULL,
  licence_no      text,                               -- DIFC / DED / ADGM
  org_type        text CHECK (org_type IN ('islamic_bank','takaful','asset_manager','employer','ngo','fintech')),
  kyb_status      text DEFAULT 'pending' CHECK (kyb_status IN ('pending','verified','rejected')),
  contract_tier   text CHECK (contract_tier IN ('pilot','standard','enterprise')),
  created_at      timestamptz DEFAULT now()
);

CREATE TABLE partners.members (
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  org_id          uuid NOT NULL REFERENCES partners.organisations(id) ON DELETE CASCADE,
  auth_id         uuid UNIQUE NOT NULL,
  role            text DEFAULT 'analyst' CHECK (role IN ('owner','admin','compliance','analyst')),
  email           text NOT NULL
);

CREATE TABLE partners.campaigns (                     -- anonymised, aggregate-only reach
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  org_id          uuid NOT NULL REFERENCES partners.organisations(id),
  title           text NOT NULL,
  product_type    text CHECK (product_type IN ('sukuk','gold_savings','takaful','murabaha_alt','waqf','education')),
  shariah_cert_ref text,                              -- must hold certificate before live
  status          text DEFAULT 'draft' CHECK (status IN ('draft','shariah_review','live','paused','ended')),
  created_at      timestamptz DEFAULT now()
);

-- Hard privacy wall: partners never see sisters PII. Aggregates only.
CREATE VIEW partners.audience_insights AS
  SELECT emirate, count(*) AS sisters, avg(bs.composite) AS avg_barakah
  FROM sisters.users u JOIN sisters.barakah_scores bs ON bs.user_id = u.id
  GROUP BY emirate HAVING count(*) >= 25;             -- k-anonymity threshold

-- ------------------------------------------------------------
-- GOVERNANCE · RISK · SHARIAH · SECURITY (shared)
-- ------------------------------------------------------------
CREATE TABLE governance.shariah_rulings (
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  subject         text NOT NULL,                      -- product, feature, content, agent tool
  ruling          text NOT NULL CHECK (ruling IN ('halal','conditional','haram','pending')),
  standard_ref    text,                               -- AAOIFI SS-xx, DIFC ref
  board_member    text NOT NULL,                      -- ADL Advisory signatory
  effective_from  date NOT NULL,
  notes           text
);

CREATE TABLE governance.risk_register (
  id              uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  category        text CHECK (category IN ('shariah_non_compliance','aml_cft','data_privacy','ai_model','operational','cyber','regulatory')),
  description     text NOT NULL,
  likelihood      int CHECK (likelihood BETWEEN 1 AND 5),
  impact          int CHECK (impact BETWEEN 1 AND 5),
  score           int GENERATED ALWAYS AS (likelihood*impact) STORED,
  mitigation      text,
  owner           text,
  review_due      date
);

CREATE TABLE governance.audit_log (                   -- immutable, append-only
  id              bigserial PRIMARY KEY,
  actor_type      text CHECK (actor_type IN ('sister','partner','admin','ai_agent','system')),
  actor_id        uuid,
  event           text NOT NULL,
  detail          jsonb,
  ip_hash         text,
  at              timestamptz DEFAULT now()
);
REVOKE UPDATE, DELETE ON governance.audit_log FROM PUBLIC;

-- ------------------------------------------------------------
-- ROW LEVEL SECURITY (women-only wall + tenant isolation)
-- ------------------------------------------------------------
ALTER TABLE sisters.users            ENABLE ROW LEVEL SECURITY;
ALTER TABLE sisters.wealth_goals     ENABLE ROW LEVEL SECURITY;
ALTER TABLE sisters.agent_sessions   ENABLE ROW LEVEL SECURITY;
ALTER TABLE sisters.agent_actions    ENABLE ROW LEVEL SECURITY;
ALTER TABLE sisters.payments         ENABLE ROW LEVEL SECURITY;
ALTER TABLE partners.members         ENABLE ROW LEVEL SECURITY;

CREATE POLICY sisters_self ON sisters.users
  USING (auth_id = auth.uid());
CREATE POLICY goals_self ON sisters.wealth_goals
  USING (user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid()));
CREATE POLICY sessions_self ON sisters.agent_sessions
  USING (user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid()));
CREATE POLICY actions_self ON sisters.agent_actions
  USING (user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid()));
CREATE POLICY payments_self ON sisters.payments
  USING (user_id = (SELECT id FROM sisters.users WHERE auth_id = auth.uid()));
CREATE POLICY partner_org ON partners.members
  USING (auth_id = auth.uid());
