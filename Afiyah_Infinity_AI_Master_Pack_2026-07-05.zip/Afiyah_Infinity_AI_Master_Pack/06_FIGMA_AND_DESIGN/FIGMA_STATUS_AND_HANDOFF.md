# Figma and Design Asset Status

## Status

No actual Figma design URL, file key, node-specific URL, `.fig` export, design-token export, component library, image export, or prototype link was supplied in this chat. Therefore none can truthfully be embedded in this master ZIP.

## What is represented in the software pack

The code and prior project context reference Afiyah's visual identity and application screens, but code is not a substitute for an editable Figma source file.

Known brand direction from project materials:

- Deep green: `#003629`
- Gold: `#AD8633`
- Ivory: `#F8F3E9`
- Charcoal: `#181715`
- Typography direction: Playfair Display with Montserrat/Lato; Arabic support through Amiri/Scheherazade.
- Product surfaces include Sisters, Partners, Admin, Noor, onboarding, Barakah baseline, check-in, KYC/verification, membership, and governance.

## Required exports for a design-inclusive master pack

Provide either:

1. A Figma `/design/` URL with edit access, or
2. A `.fig` file export.

Recommended additional exports:

- Design tokens as JSON.
- Local styles/variables documentation.
- Component and variant inventory.
- SVG logo and icon set.
- PNG/WebP screen previews at 1x and 2x.
- Prototype flow map.
- Accessibility/contrast report.
- Developer handoff annotations.
- Font-family names and licensing notes; do not redistribute proprietary font files.

## Suggested Figma page structure

```text
00 Cover & Read Me
01 Foundations
02 Variables & Tokens
03 Components
04 Sisters Web
05 Sisters Mobile
06 Noor AI
07 Partners
08 Admin & Governance
09 Verification & KYC
10 Empty, Loading, Error & Offline States
11 Prototype Flows
12 Developer Handoff
13 Archive
```

## Design-to-code acceptance criteria

- Every coded screen maps to a named Figma frame.
- Components and variants match implementation states.
- Responsive breakpoints are specified.
- Error, permission, loading, offline, and AI-disabled states are included.
- Sensitive identity/cycle/health screens have privacy-safe prototypes.
- Text claims are legally and Shariah reviewed before production.
- WCAG contrast and keyboard/focus states are documented.
