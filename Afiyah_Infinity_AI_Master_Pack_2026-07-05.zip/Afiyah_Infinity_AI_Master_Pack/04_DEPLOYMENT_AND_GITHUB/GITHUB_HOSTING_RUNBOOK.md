# GitHub, Supabase and Frontend Hosting Runbook

## Target repository

```text
https://github.com/afiyahinfinity/mtbdiaries1-afiyah-infinity.git
```

Recommended protected branch:

```text
security/noor-stage-1
```

## Repository merge scope

Merge these files from:

```text
02_CONSOLIDATED_CODE/Afiyah_Reviewed_Pack/04_Remediation_Stage_1/
```

into the matching paths in the real repository:

```text
supabase/migrations/012_noor_atomic_security.sql
supabase/functions/noor-agent/index.ts
supabase/functions/agent-execute/index.ts
app/noor/page.tsx
tests/noor-security.test.ts
```

Do not overwrite the full repository without comparing the current source tree and migration history.

## Git workflow

```bash
git clone https://github.com/afiyahinfinity/mtbdiaries1-afiyah-infinity.git
cd mtbdiaries1-afiyah-infinity
git checkout -b security/noor-stage-1

# Copy and review the five Stage 1 files.
git status
git diff --check

git add supabase/migrations/012_noor_atomic_security.sql \
        supabase/functions/noor-agent/index.ts \
        supabase/functions/agent-execute/index.ts \
        app/noor/page.tsx \
        tests/noor-security.test.ts

git commit -m "security: harden Noor sessions and atomic execution"
git push -u origin security/noor-stage-1
```

Open a pull request into the protected staging/development branch. Do not merge directly into production before staging evidence is recorded.

## Supabase staging deployment

```bash
supabase login
supabase link --project-ref "$AFIYAH_STAGING_PROJECT_REF"
supabase db push

supabase secrets set \
  ALLOWED_ORIGINS="https://afiyahinfinityai.com,https://www.afiyahinfinityai.com" \
  AI_ENABLED="false" \
  --project-ref "$AFIYAH_STAGING_PROJECT_REF"

supabase functions deploy noor-agent --project-ref "$AFIYAH_STAGING_PROJECT_REF"
supabase functions deploy agent-execute --project-ref "$AFIYAH_STAGING_PROJECT_REF"
```

Set the remaining Edge Function secrets using `05_ENVIRONMENT_KEYS/supabase-secrets.example` as the checklist.

## Test gate

```bash
pnpm install
pnpm lint
pnpm typecheck
pnpm vitest run tests/noor-security.test.ts tests/rls.test.ts
pnpm build
```

Required evidence:

- A foreign session ID is rejected and creates no row.
- A mismatched `(session_id, sister_id)` insert fails.
- Sisters cannot directly mutate proposal status.
- Concurrent approvals create one domain write and one terminal execution record.
- Cross-user RPC calls are rejected.
- Existing RLS and core flows remain green.
- A restore point exists before migration 012.

## Frontend hosting

The project documents mention both Hostinger and Vercel. Confirm which system currently deploys `afiyahinfinityai.com` before merging to the production branch.

### Vercel
- Connect the correct GitHub repository and production branch.
- Add variables from `.env.production.example` in Project Settings → Environment Variables.
- Configure Preview, Development, and Production values separately.
- Never expose variables without the `NEXT_PUBLIC_` prefix to the browser.

### Hostinger
- Use Hostinger's Node.js/Git deployment only if the plan supports the project's Next.js server requirements.
- Add server environment variables in the hosting control panel, not in committed files.
- Confirm build command, output/runtime mode, Node version, startup command, and domain mapping.
- Do not treat a static upload as equivalent to a full Next.js server deployment.

## DNS

Do not alter DNS until the current provider and deployment target are confirmed. Preserve working email records. Validate:

- `A`/`AAAA` or `CNAME` for the website.
- SPF.
- DKIM.
- DMARC.
- Resend domain verification.
- Supabase Auth SMTP configuration.

## Production promotion

1. Record current migration head and backup/restore point.
2. Apply migration 012.
3. Deploy the two Edge Functions.
4. Deploy the updated Noor page.
5. Run test-sister decline, approve, and retry flows.
6. Keep `AI_ENABLED=false` until smoke tests pass.
7. Monitor function errors, database logs, and action execution logs.
8. Roll back or disable AI immediately if ownership or duplicate-execution evidence fails.
