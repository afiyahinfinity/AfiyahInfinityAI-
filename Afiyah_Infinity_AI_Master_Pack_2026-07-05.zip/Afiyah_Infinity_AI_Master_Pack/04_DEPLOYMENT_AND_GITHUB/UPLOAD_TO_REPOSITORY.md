# Afiyah Infinity — Stage 1 Security Remediation

Target repository: `afiyahinfinity/mtbdiaries1-afiyah-infinity`
Target domain: `https://afiyahinfinityai.com`

## Package contents

- `supabase/migrations/012_noor_atomic_security.sql`
- `supabase/functions/noor-agent/index.ts`
- `supabase/functions/agent-execute/index.ts`
- `app/noor/page.tsx`
- `tests/noor-security.test.ts`
- `README_DEPLOYMENT.md`

## Manual upload order

1. Create a branch such as `security/noor-stage-1`.
2. Copy the folders from this ZIP into the repository root, preserving paths.
3. Review environment variables and production CORS values.
4. Run migration `012_noor_atomic_security.sql` on staging first.
5. Deploy the two Supabase Edge Functions.
6. Run the Noor security test suite.
7. Build and test the Next.js application.
8. Deploy staging, complete smoke tests, then promote to production.

Do not apply this package directly to production without staging validation and a database backup.
