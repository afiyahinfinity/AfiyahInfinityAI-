# Keys, Environment Variables and Secret Handling

## Golden rule

This pack deliberately contains **no live credentials**. Use the templates only as a variable checklist. Store real values in Supabase secrets, Vercel/Hostinger environment settings, GitHub Actions secrets, or an approved password/secret manager.

Never commit:

- Supabase service-role key.
- Database password or connection URI containing a password.
- Anthropic API key.
- Resend API key.
- Sentry auth token.
- Vercel, Hostinger, GitHub, Cloudflare, or registrar access tokens.
- OAuth client secret.
- FCM service-account JSON.
- Private signing/encryption keys.
- Production webhook signing secrets.

## Key map

| Variable | Classification | Used by | Storage location |
|---|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Public configuration | Browser/Next.js | Hosting environment |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Public client key protected by RLS | Browser/Next.js | Hosting environment |
| `SUPABASE_SERVICE_ROLE_KEY` | Critical secret | Server/admin backend only | Hosting secret manager; never browser |
| `ANTHROPIC_API_KEY` | Critical secret | Supabase Edge Functions/server AI gateway | Supabase Edge secrets |
| `RESEND_API_KEY` | Critical secret | Email worker/server | Supabase or hosting secret manager |
| `CRON_SECRET` | Critical secret | Scheduled endpoints/functions | Supabase Edge secrets |
| `SYSTEM_ADMIN_ID` | Sensitive identifier | Audit/automation functions | Supabase Edge secrets |
| `SENTRY_DSN` | Server configuration | Error telemetry | Hosting/Supabase secrets |
| `NEXT_PUBLIC_SENTRY_DSN` | Public telemetry endpoint | Browser | Hosting environment |
| `ALLOWED_ORIGINS` | Security configuration | Edge Functions | Supabase Edge secrets |
| `AI_ENABLED` | Operational kill switch | AI functions | Supabase Edge secrets and server env |
| `FOUNDER_EMAIL` | Operational PII | Alerts | Supabase Edge secrets |
| `CALENDLY_ONBOARDING_URL` | Public/operational | Partner onboarding | Hosting environment |
| `FCM_SERVICE_ACCOUNT` | Critical secret | Future push worker | Secret manager only |

## Obtaining each value

### Supabase
In each separate staging and production project:

- Project URL and anon key: Project Settings → API.
- Service-role key: Project Settings → API. Treat as root-level backend access.
- Project reference: visible in project URL/settings; use for CLI deployment.
- Database password: Database Settings; use only for migration/administration tooling.

Use separate projects and keys for staging and production. Never use production keys locally unless explicitly authorised.

### Anthropic
Create a dedicated project/workspace API key with spend limits. Use separate staging and production keys when possible. Do not call Anthropic directly from the browser.

### Resend
Verify `afiyahinfinityai.com`, configure SPF/DKIM/DMARC, create a restricted sending API key, and use a verified sender such as `noreply@afiyahinfinityai.com`.

### Sentry
Create separate staging/production projects. The DSN can be configured in runtime; any Sentry organisation auth token used for source-map upload is a secret and must not be committed.

### GitHub
Use repository permissions and protected branches. Prefer GitHub App/OIDC integrations over long-lived personal access tokens. Store any unavoidable token in GitHub Actions Secrets.

### Vercel or Hostinger
Add variables in the provider's encrypted environment settings. Do not upload `.env.local` or `.env.production` containing real values.

## Creating strong secrets

Example local commands:

```bash
openssl rand -base64 48
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

Generate different values for staging and production.

## Rotation schedule

Rotate immediately after suspected exposure, staff/vendor offboarding, accidental commit, or environment transfer. At minimum review critical keys quarterly. Document owner, creation date, last rotation, permitted services, and emergency revocation procedure.

## Git protection

Add to `.gitignore`:

```gitignore
.env
.env.*
!.env.example
!.env.local.example
!.env.production.example
*.pem
*.key
*.p12
service-account*.json
```

Enable secret scanning and push protection. If a real secret was ever committed, deleting the file is insufficient: revoke/rotate the credential and purge history as required.
